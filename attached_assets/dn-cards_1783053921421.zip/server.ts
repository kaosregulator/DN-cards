import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";

// Load environment variables immediately
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

/**
 * Endpoint to construct and return the Discord login popup URL.
 * The client passes its current origin so we can bake it into the OAuth 'state' parameter.
 */
app.get("/api/auth/discord/url", (req, res) => {
  const clientOrigin = (req.query.origin as string) || "http://localhost:3000";
  
  const clientId = process.env.DISCORD_CLIENT_ID;
  if (!clientId) {
    // If client ID is missing, tell the client it needs config, or let it know it should fallback
    return res.status(400).json({ 
      error: "DISCORD_CLIENT_ID not configured",
      message: "Please set DISCORD_CLIENT_ID in your environment variables."
    });
  }

  // Construct dynamic redirect URI using the client's origin of the runtime session
  const redirectUri = `${clientOrigin}/auth/callback`;
  
  // Use 'state' parameter to securely carry the client's origin back to our callback route
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "identify",
    state: clientOrigin
  });

  const discordAuthUrl = `https://discord.com/api/oauth2/authorize?${params.toString()}`;
  res.json({ url: discordAuthUrl });
});

/**
 * Callback endpoint where Discord redirects the popup.
 * It exchanges the code for tokens, retrieves user identifying information, and completes the handshake.
 */
app.get(["/auth/callback", "/auth/callback/"], async (req, res) => {
  const { code, state, error } = req.query;

  // Handle errors or user cancellations gracefully
  if (error) {
    return res.send(`
      <html>
        <body style="background: #0f172a; color: #f1f5f9; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0;">
          <div style="text-align: center; border: 1px solid #ef4444; padding: 24px; border-radius: 12px; background: rgba(239, 68, 68, 0.1);">
            <h1 style="color: #ef4444; font-size: 1.5rem; margin-top: 0;">Authorization Cancelled</h1>
            <p style="color: #cbd5e1; font-size: 0.875rem;">Discord returned: ${error}</p>
            <button onclick="window.close()" style="background: #3b82f6; border: none; color: white; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: bold; margin-top: 12px;">Close Window</button>
          </div>
        </body>
      </html>
    `);
  }

  if (!code) {
    return res.status(400).send("Authorization code is missing.");
  }

  const parentOrigin = (state as string) || "http://localhost:3000";

  try {
    const clientId = process.env.DISCORD_CLIENT_ID;
    const clientSecret = process.env.DISCORD_CLIENT_SECRET;

    if (!clientId || !clientSecret) {
      throw new Error("Local environment is missing Discord developer configurations (Client ID or Secret).");
    }

    // Dynamic redirect URI reconstruction using parentOrigin stored in state
    const redirectUri = `${parentOrigin}/auth/callback`;

    // 1. Exchange OAuth code for an Access Token
    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: "authorization_code",
        code: code as string,
        redirect_uri: redirectUri
      }).toString()
    });

    if (!tokenResponse.ok) {
      const errorData = await tokenResponse.json();
      throw new Error(`Token exchange failed: ${JSON.stringify(errorData)}`);
    }

    const tokenData = await tokenResponse.json();
    const accessToken = tokenData.access_token;

    // 2. Fetch authenticated user profile details from Discord API
    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    });

    if (!userResponse.ok) {
      throw new Error("Failed to retrieve user profile from Discord @me endpoint");
    }

    const userData = await userResponse.json();

    // 3. Complete authentication by posting success payload back to main app in iframe, then close window
    res.send(`
      <html>
        <body style="background: #0f172a; color: #f1f5f9; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0;">
          <div style="text-align: center; padding: 24px;">
            <div style="width: 50px; height: 50px; border: 4px solid #3b82f6; border-top-color: transparent; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 16px;"></div>
            <h1 style="font-size: 1.25rem;">Completing Sync...</h1>
            <p style="color: #94a3b8; font-size: 0.875rem;">Connected as <b style="color: #3b82f6;">${userData.username}</b>. Synchronizing card ledger with Discord client.</p>
          </div>
          <script>
            if (window.opener) {
              window.opener.postMessage({
                type: 'DISCORD_OAUTH_SUCCESS',
                user: {
                  id: 'dsc_' + '${userData.id}',
                  username: '${userData.username}',
                  avatar: '${userData.avatar || ""}',
                  isSynced: true
                }
              }, '${parentOrigin}');
              window.close();
            } else {
              window.location.href = '${parentOrigin}';
            }
          </script>
          <style>
            @keyframes spin {
              to { transform: rotate(360deg); }
            }
          </style>
        </body>
      </html>
    `);
  } catch (err: any) {
    console.error("OAuth Exchange Failure:", err);
    res.send(`
      <html>
        <body style="background: #0f172a; color: #f1f5f9; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0;">
          <div style="text-align: center; border: 1px solid #ef4444; padding: 24px; border-radius: 12px; background: rgba(239, 68, 68, 0.1); max-width: 450px;">
            <h1 style="color: #ef4444; font-size: 1.3rem; margin-top: 0;">Handshake Sync Failed</h1>
            <p style="color: #cbd5e1; font-size: 0.85rem; line-height: 1.5; text-align: left; background: #020617; padding: 12px; border-radius: 6px; font-family: monospace;">
              ${err.message || err}
            </p>
            <p style="color: #94a3b8; font-size: 0.75rem; margin-top: 14px;">If hosting in sandbox preview, ensure DISCORD_CLIENT_ID and DISCORD_CLIENT_SECRET are declared in your env.example and saved in the Settings menu.</p>
            <button onclick="window.close()" style="background: #ef4444; border: none; color: white; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: bold; margin-top: 8px;">Close Window</button>
          </div>
        </body>
      </html>
    `);
  }
});

// Configure Vite middleware in development or direct static serving in production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // Serve index.html as fallback for index files / SPA client routes
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[DN Full-Stack Server] Active on port ${PORT}`);
  });
}

startServer();
