/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Rarity = 'Common' | 'Uncommon' | 'Gold Legendary' | 'Exotic' | 'Limited Edition';

export type CardCategory =
  | 'Infantry'
  | 'Vehicles'
  | 'Aircraft'
  | 'Naval'
  | 'Mechs'
  | 'Bosses'
  | 'Support'
  | 'Event';

export interface Card {
  id: string;
  name: string;
  rarity: Rarity;
  category: CardCategory;
  cost: number; // deployment cost (supply points)
  attack: number;
  health: number;
  maxHealth: number;
  abilityName?: string;
  abilityDescription?: string;
  imageUrl?: string;
  flavorText?: string;
  isStarter?: boolean; // Starter Deck indicator
  set: 'Set 1' | 'Set 2';
  
  // Dynamic progression and evolutions
  level?: number;             // Current card level (1-10, defaults to 1)
  xp?: number;                // Current card XP (0-100)
  stage?: 1 | 2 | 3;          // Current evolution stage (1, 2, or 3)
  ability1Name?: string;      // Move set stage 1
  ability1Desc?: string;      // Move set description stage 1
  ability2Name?: string;      // Move set stage 2
  ability2Desc?: string;      // Move set description stage 2
  ability3Name?: string;      // Move set stage 3
  ability3Desc?: string;      // Move set description stage 3
}

export interface PlayerInventory {
  ownedCardIds: string[]; // Cards unlocked/collected (simulating Discord collection)
  dnShards: number; // Progression currency
  level: number;
  xp: number;
  xpToNextLevel: number;
  rank: GameRank;
  rankXp: number; // Rank rating / MMR
  customDecks: { [deckId: string]: string[] }; // deckId -> cardIds
  activeDeckId: string;
}

export interface DiscordUser {
  id: string;
  username: string;
  avatar?: string;
  isSynced: boolean;
}

export type GameRank =
  | 'Recruit'
  | 'Corporal'
  | 'Sergeant'
  | 'Lieutenant'
  | 'Captain'
  | 'Major'
  | 'Colonel'
  | 'General of the Army';

export interface MatchHistoryEntry {
  id: string;
  mode: 'Ranked' | 'Casual';
  opponentName: string;
  opponentRank: GameRank;
  result: 'Victory' | 'Defeat';
  xpEarned: number;
  shardsEarned: number;
  date: string;
  turnsPlayed: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  unlocked: boolean;
  rewardShards: number;
  progressMax: number;
  progressCurrent: number;
  icon: string;
}

export interface LeaderboardUser {
  rank: number;
  name: string;
  title: GameRank;
  rating: number;
  winRate: string;
  activeDeck: string;
  shards: number;
}

// Battle Board Representation
export interface BattleUnit {
  id: string; // unique instance id
  cardId: string;
  name: string;
  rarity: Rarity;
  category: CardCategory;
  attack: number;
  health: number;
  maxHealth: number;
  abilityName?: string;
  abilityDescription?: string;
  hasAttacked: boolean;
  isStunned?: boolean;
}

export interface BattleState {
  playerHP: number;
  enemyHP: number;
  playerMaxHP: number;
  enemyMaxHP: number;
  playerSupply: number;
  playerMaxSupply: number;
  enemySupply: number;
  enemyMaxSupply: number;
  playerHand: Card[];
  enemyHandSize: number;
  playerField: BattleUnit[];
  enemyField: BattleUnit[];
  playerDeckIds: string[];
  enemyDeckIds: string[];
  playerDiscardIds: string[];
  enemyDiscardIds: string[];
  turn: 'player' | 'enemy';
  turnNumber: number;
  activeEventEffect: {
    title: string;
    description: string;
    side: 'player' | 'enemy';
    type: 'anniversary' | 'holiday' | 'community' | 'partner';
  } | null;
  battleLog: string[];
  status: 'searching' | 'active' | 'victory' | 'defeat';
}
