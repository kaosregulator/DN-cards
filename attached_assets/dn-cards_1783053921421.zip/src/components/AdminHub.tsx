/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Database, Plus, Save, RotateCcw, Shield, Layers, Zap, Info, 
  ChevronRight, Edit3, Trash2, Sliders, Play, Sparkles, Check, RefreshCw
} from 'lucide-react';
import { Card, Rarity, CardCategory } from '../types';
import { 
  CARD_DATABASE, 
  rebuildCardDatabase, 
  saveCardOverrides, 
  getRawBaseStats, 
  getLevelStatMultiplier, 
  getStageFromLevel 
} from '../data/cards';

interface AdminHubProps {
  onRefreshDatabase: () => void;
  ownedCardIds: string[];
  addShards: (amount: number) => void;
}

const DEFAULT_RARITY_SETTINGS: Record<Rarity, { cost: number; baseAttack: number; baseHealth: number }> = {
  'Common': { cost: 3, baseAttack: 3, baseHealth: 4 },
  'Uncommon': { cost: 4, baseAttack: 4, baseHealth: 6 },
  'Gold Legendary': { cost: 5, baseAttack: 6, baseHealth: 9 },
  'Exotic': { cost: 7, baseAttack: 8, baseHealth: 12 },
  'Limited Edition': { cost: 6, baseAttack: 7, baseHealth: 10 }
};

export default function AdminHub({ onRefreshDatabase, ownedCardIds, addShards }: AdminHubProps) {
  // State for active category
  const [activeSubTab, setActiveSubTab] = useState<'edit' | 'create'>('edit');
  const [selectedCardId, setSelectedCardId] = useState<string>(CARD_DATABASE[0]?.id || '');
  
  // Edit Form State
  const [editName, setEditName] = useState('');
  const [editRarity, setEditRarity] = useState<Rarity>('Common');
  const [editCategory, setEditCategory] = useState<CardCategory>('Infantry');
  const [editCost, setEditCost] = useState(3);
  const [editBaseAttack, setEditBaseAttack] = useState(3);
  const [editBaseHealth, setEditBaseHealth] = useState(4);
  const [editLevel, setEditLevel] = useState(1);
  const [editXp, setEditXp] = useState(0);
  const [editImageUrl, setEditImageUrl] = useState('');
  const [editFlavorText, setEditFlavorText] = useState('');
  
  // Custom move sets
  const [editAbility1Name, setEditAbility1Name] = useState('');
  const [editAbility1Desc, setEditAbility1Desc] = useState('');
  const [editAbility2Name, setEditAbility2Name] = useState('');
  const [editAbility2Desc, setEditAbility2Desc] = useState('');
  const [editAbility3Name, setEditAbility3Name] = useState('');
  const [editAbility3Desc, setEditAbility3Desc] = useState('');

  // Create Form State
  const [createId, setCreateId] = useState(() => `custom_${Date.now()}`);
  const [createName, setCreateName] = useState('');
  const [createRarity, setCreateRarity] = useState<Rarity>('Common');
  const [createCategory, setCreateCategory] = useState<CardCategory>('Infantry');
  const [createCost, setCreateCost] = useState(3);
  const [createBaseAttack, setCreateBaseAttack] = useState(3);
  const [createBaseHealth, setCreateBaseHealth] = useState(4);
  const [createImageUrl, setCreateImageUrl] = useState('');
  const [createFlavorText, setCreateFlavorText] = useState('');
  
  // Create state moves
  const [createAbility1Name, setCreateAbility1Name] = useState('');
  const [createAbility1Desc, setCreateAbility1Desc] = useState('');
  const [createAbility2Name, setCreateAbility2Name] = useState('');
  const [createAbility2Desc, setCreateAbility2Desc] = useState('');
  const [createAbility3Name, setCreateAbility3Name] = useState('');
  const [createAbility3Desc, setCreateAbility3Desc] = useState('');

  // Feedback Messages
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [createSuccess, setCreateSuccess] = useState(false);
  const [massActionSuccess, setMassActionSuccess] = useState('');

  // Rarity change custom preset triggering
  const handleEditRarityChange = (newRarity: Rarity) => {
    setEditRarity(newRarity);
    const defaults = DEFAULT_RARITY_SETTINGS[newRarity];
    if (defaults) {
      setEditCost(defaults.cost);
      setEditBaseAttack(defaults.baseAttack);
      setEditBaseHealth(defaults.baseHealth);
    }
  };

  const handleCreateRarityChange = (newRarity: Rarity) => {
    setCreateRarity(newRarity);
    const defaults = DEFAULT_RARITY_SETTINGS[newRarity];
    if (defaults) {
      setCreateCost(defaults.cost);
      setCreateBaseAttack(defaults.baseAttack);
      setCreateBaseHealth(defaults.baseHealth);
    }
  };

  // Load selected card parameters into edit state
  React.useEffect(() => {
    const card = CARD_DATABASE.find(c => c.id === selectedCardId);
    if (card) {
      const bases = getRawBaseStats(card.id);
      setEditName(card.name);
      setEditRarity(card.rarity);
      setEditCategory(card.category);
      setEditCost(card.cost);
      setEditBaseAttack(bases.attack);
      setEditBaseHealth(bases.health);
      setEditLevel(card.level ?? 1);
      setEditXp(card.xp ?? 0);
      setEditImageUrl(card.imageUrl || '');
      setEditFlavorText(card.flavorText || '');
      
      setEditAbility1Name(card.ability1Name || card.abilityName || 'Rapid Shells');
      setEditAbility1Desc(card.ability1Desc || card.abilityDescription || 'Fires light automatic energy cartridges.');
      
      setEditAbility2Name(card.ability2Name || `[Evolved] ${card.ability1Name || card.abilityName || 'Rapid Shells'}`);
      setEditAbility2Desc(card.ability2Desc || `Augmented multi-payload output: ${card.ability1Desc || card.abilityDescription || 'Fires energy cartridges.'}`);
      
      setEditAbility3Name(card.ability3Name || `[Ultimate] ${card.ability1Name || card.abilityName || 'Rapid Shells'}`);
      setEditAbility3Desc(card.ability3Desc || `Ultimate burst parameters: Bypasses target defensive armor and delivers devastating damage.`);
    }
  }, [selectedCardId]);

  // Handle Save Overrides
  const handleSaveCardEdits = () => {
    if (!selectedCardId) return;
    
    saveCardOverrides(selectedCardId, {
      name: editName,
      rarity: editRarity,
      category: editCategory,
      cost: editCost,
      baseAttack: editBaseAttack,
      baseHealth: editBaseHealth,
      level: editLevel,
      xp: editXp,
      imageUrl: editImageUrl,
      flavorText: editFlavorText,
      ability1Name: editAbility1Name,
      ability1Desc: editAbility1Desc,
      ability2Name: editAbility2Name,
      ability2Desc: editAbility2Desc,
      ability3Name: editAbility3Name,
      ability3Desc: editAbility3Desc
    });

    setSaveSuccess(true);
    onRefreshDatabase();
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  // Handle Create New Custom Card
  const handleCreateNewCard = () => {
    if (!createName.trim()) return;

    const newId = `custom_${Date.now()}`;
    saveCardOverrides(newId, {
      id: newId,
      name: createName,
      rarity: createRarity,
      category: createCategory,
      cost: createCost,
      baseAttack: createBaseAttack,
      baseHealth: createBaseHealth,
      level: 1,
      xp: 0,
      imageUrl: createImageUrl || 'https://misu.nephbox.net/card_image/1363917781355069761/master_reaper_00018112.png',
      flavorText: createFlavorText || 'An experimental blueprint configured in the Admin Operations desk.',
      set: 'Set 2',
      isStarter: false,
      ability1Name: createAbility1Name || 'Plasma Barrage',
      ability1Desc: createAbility1Desc || 'Deals standard damage output to front line combatants.',
      ability2Name: createAbility2Name || `[Evolved] ${createAbility1Name || 'Plasma Barrage'}`,
      ability2Desc: createAbility2Desc || 'Flashes electromagnetic waves dealing increased splash damage.',
      ability3Name: createAbility3Name || `[Ultimate] ${createAbility1Name || 'Plasma Barrage'}`,
      ability3Desc: createAbility3Desc || 'Extreme tactical fusion blast which dissolves target defensive systems completely.'
    });

    setCreateSuccess(true);
    
    // Auto-select the newly created card
    setSelectedCardId(newId);
    setCreateName('');
    setCreateImageUrl('');
    setCreateFlavorText('');
    setCreateAbility1Name('');
    setCreateAbility1Desc('');
    setCreateAbility2Name('');
    setCreateAbility2Desc('');
    setCreateAbility3Name('');
    setCreateAbility3Desc('');
    
    onRefreshDatabase();
    setActiveSubTab('edit');
    setTimeout(() => setCreateSuccess(false), 2000);
  };

  // Mass Updates for QA testing (Evolve everything to max)
  const handleMassLevelMax = () => {
    const customConfigsRaw = localStorage.getItem('dn_custom_card_configs') || '{}';
    const configs = JSON.parse(customConfigsRaw);

    CARD_DATABASE.forEach(card => {
      configs[card.id] = {
        ...(configs[card.id] || { id: card.id }),
        level: 10,
        xp: 0
      };
    });

    localStorage.setItem('dn_custom_card_configs', JSON.stringify(configs));
    rebuildCardDatabase();
    onRefreshDatabase();
    
    // Trigger update on fields
    setSelectedCardId(prev => prev);
    
    setMassActionSuccess('All catalog cards elevated to MAXIMUM LEVEL 10 [Stage 3 Ultimate]!');
    setTimeout(() => setMassActionSuccess(''), 4000);
  };

  // Reset database completely
  const handleResetToBaseline = () => {
    localStorage.removeItem('dn_custom_card_configs');
    rebuildCardDatabase();
    onRefreshDatabase();
    if (CARD_DATABASE[0]) {
      setSelectedCardId(CARD_DATABASE[0].id);
    }
    setMassActionSuccess('All custom card modifications and levels restored to default sandbox baseline.');
    setTimeout(() => setMassActionSuccess(''), 4000);
  };

  // Get active stats display for previewing inside edit panel
  const getLevelCorrectedStats = () => {
    const rawMultiplier = getLevelStatMultiplier(editLevel);
    const activeAttack = Math.round(editBaseAttack * rawMultiplier);
    const activeHealth = Math.round(editBaseHealth * rawMultiplier);
    const activeStage = getStageFromLevel(editLevel);
    
    let activeMoveName = editAbility1Name;
    let activeMoveDesc = editAbility1Desc;
    if (activeStage === 2) {
      activeMoveName = editAbility2Name;
      activeMoveDesc = editAbility2Desc;
    } else if (activeStage === 3) {
      activeMoveName = editAbility3Name;
      activeMoveDesc = editAbility3Desc;
    }

    return {
      activeAttack,
      activeHealth,
      activeStage,
      activeMoveName,
      activeMoveDesc,
      rawMultiplier
    };
  };

  const preview = getLevelCorrectedStats();

  return (
    <div className="space-y-6 animate-fadeIn" id="admin-operations-panel">
      {/* HEADER OPERATIONS BAR */}
      <div className="bg-[#0F0F13] border border-orange-900/30 p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] uppercase font-mono tracking-widest text-orange-500 font-extrabold flex items-center gap-1">
            <Shield className="w-3.5 h-3.5 text-orange-500" />
            OPERATIONS DESK SERVER SECURE
          </span>
          <h2 className="text-xl font-sans font-black text-white tracking-tight mt-1 uppercase">DN Cards Developer Registry</h2>
          <p className="text-xs text-zinc-400 max-w-2xl mt-0.5 leading-relaxed">
            Modify card stat profiles, assign custom multi-stage evolution movesets, and generate experimental battle cards. Card level status modifies damage and health, unlocking heavier tactical move presets at Stage 2 and Stage 3.
          </p>
        </div>
        
        {/* Actions Button Bar */}
        <div className="flex flex-wrap gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleMassLevelMax}
            className="text-[10px] font-mono font-bold uppercase border border-amber-500/50 hover:bg-amber-500/10 text-amber-400 px-3 py-2 rounded-lg cursor-pointer transition-colors active:scale-95"
          >
            🚀 Max Level All (Stage 3)
          </button>
          
          <button
            type="button"
            onClick={handleResetToBaseline}
            className="text-[10px] font-mono font-bold uppercase border border-red-900/50 hover:bg-red-500/10 text-red-400 px-3 py-2 rounded-lg cursor-pointer transition-colors active:scale-95"
          >
            <RotateCcw className="w-3.5 h-3.5 inline mr-1" />
            Restore Standard
          </button>
        </div>
      </div>

      {massActionSuccess && (
        <div className="bg-emerald-950/20 border border-emerald-900 p-3.5 rounded-xl text-xs font-mono text-emerald-400 flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4" />
          <span>{massActionSuccess}</span>
        </div>
      )}

      {/* TABS */}
      <div className="flex border-b border-zinc-850 gap-2">
        <button
          type="button"
          onClick={() => setActiveSubTab('edit')}
          className={`px-5 py-3 text-xs font-mono font-extrabold tracking-wider transition-colors border-b-2 ${activeSubTab === 'edit' ? 'border-orange-500 text-orange-400' : 'border-transparent text-zinc-400 hover:text-white'}`}
        >
          <Sliders className="w-4 h-4 inline mr-1.5" />
          [EDIT CURRENT CARDS]
        </button>
        
        <button
          type="button"
          onClick={() => setActiveSubTab('create')}
          className={`px-5 py-3 text-xs font-mono font-extrabold tracking-wider transition-colors border-b-2 ${activeSubTab === 'create' ? 'border-orange-500 text-orange-400' : 'border-transparent text-zinc-400 hover:text-white'}`}
        >
          <Plus className="w-4 h-4 inline mr-1.5" />
          [CREATE NEW TACTICAL CARD]
        </button>
      </div>

      {activeSubTab === 'edit' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* LEFT SELECTOR RAILS */}
          <div className="lg:col-span-4 bg-zinc-950 border border-zinc-850 p-4 rounded-2xl flex flex-col h-[650px]">
            <h3 className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-850 pb-2 mb-3">
              SELECT CARD TO RECONFIGURE ({CARD_DATABASE.length})
            </h3>
            
            {/* Scrollable list */}
            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1" id="admin-card-rails">
              {CARD_DATABASE.map(card => {
                const isSelected = card.id === selectedCardId;
                const isCustom = card.id.startsWith('custom_');
                return (
                  <button
                    key={card.id}
                    type="button"
                    onClick={() => setSelectedCardId(card.id)}
                    className={`w-full text-left p-2.5 rounded-lg border flex items-center justify-between transition-all ${
                      isSelected 
                        ? 'bg-orange-950/20 border-orange-500 text-white font-extrabold' 
                        : 'bg-zinc-900/40 border-zinc-850 text-zinc-400 hover:bg-zinc-900 hover:text-white hover:border-zinc-800'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-sans font-black truncate">{card.name}</span>
                        {isCustom && (
                          <span className="bg-blue-900/80 text-blue-100 text-[6px] px-1 rounded font-mono uppercase">
                            NEW
                          </span>
                        )}
                      </div>
                      <div className="text-[7.5px] font-mono text-zinc-500 mt-0.5 flex gap-2">
                        <span>ID: {card.id}</span>
                        <span>•</span>
                        <span>LV. {card.level ?? 1} [STAGE {card.stage ?? 1}]</span>
                      </div>
                    </div>
                    <ChevronRight className={`w-3.5 h-3.5 text-zinc-650 shrink-0 ${isSelected ? 'text-orange-500' : 'text-zinc-600'}`} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* MAIN CONFIGURATION STAGE */}
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-[#090d22]/40 border border-zinc-850 p-6 rounded-2xl grid grid-cols-1 md:grid-cols-2 gap-6 relative">
              
              {/* Form Input Variables */}
              <div className="space-y-4">
                <h3 className="text-xs font-mono font-black text-orange-400 uppercase tracking-widest border-b border-zinc-850 pb-2 flex justify-between items-center">
                  <span>Card Identity Parameters</span>
                  <span className="text-zinc-400 font-normal">BASE VALUES</span>
                </h3>

                <div>
                  <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Name</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-zinc-950 text-xs font-mono border border-zinc-800 px-3.5 py-2 rounded-lg text-white outline-none focus:border-orange-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Base Rarity</label>
                    <select
                      value={editRarity}
                      onChange={(e) => handleEditRarityChange(e.target.value as Rarity)}
                      className="w-full bg-zinc-950 text-xs font-mono border border-zinc-800 px-3 py-2 rounded-lg text-white outline-none focus:border-orange-500 cursor-pointer"
                    >
                      <option value="Common">Common</option>
                      <option value="Uncommon">Uncommon</option>
                      <option value="Gold Legendary">Gold Legendary</option>
                      <option value="Exotic">Exotic</option>
                      <option value="Limited Edition">Limited Edition</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Category</label>
                    <select
                      value={editCategory}
                      onChange={(e) => setEditCategory(e.target.value as CardCategory)}
                      className="w-full bg-zinc-950 text-xs font-mono border border-zinc-800 px-3 py-2 rounded-lg text-white outline-none focus:border-orange-500 cursor-pointer"
                    >
                      <option value="Infantry">Infantry</option>
                      <option value="Vehicles">Vehicles</option>
                      <option value="Aircraft">Aircraft</option>
                      <option value="Naval">Naval</option>
                      <option value="Mechs">Mechs</option>
                      <option value="Bosses">Bosses</option>
                      <option value="Support">Support</option>
                      <option value="Event">Event</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Deploy Cost</label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      value={editCost}
                      onChange={(e) => setEditCost(parseInt(e.target.value) || 1)}
                      className="w-full bg-zinc-950 text-xs font-mono border border-zinc-800 px-3 py-2 rounded-lg text-white text-center outline-none focus:border-orange-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Base ATK</label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      value={editBaseAttack}
                      onChange={(e) => setEditBaseAttack(parseInt(e.target.value) || 1)}
                      className="w-full bg-zinc-950 text-xs font-mono border border-zinc-800 px-3 py-2 rounded-lg text-white text-center outline-none focus:border-orange-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Base HP</label>
                    <input
                      type="number"
                      min="1"
                      max="20"
                      value={editBaseHealth}
                      onChange={(e) => setEditBaseHealth(parseInt(e.target.value) || 1)}
                      className="w-full bg-zinc-950 text-xs font-mono border border-zinc-800 px-3 py-2 rounded-lg text-white text-center outline-none focus:border-orange-500"
                    />
                  </div>
                </div>

                {/* Progression training simulator */}
                <div className="bg-zinc-900/60 p-4 rounded-xl border border-zinc-850 space-y-2">
                  <div className="flex justify-between text-[10px] font-mono text-zinc-400">
                    <span className="font-extrabold text-orange-400">CARD LEVEL & XP TESTING</span>
                    <span>LEVEL: <b className="text-white text-xs">{editLevel}/10</b></span>
                  </div>
                  
                  {/* Slider to easily edit level to see card staging evolve visual feedback instantly */}
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={editLevel}
                    onChange={(e) => setEditLevel(parseInt(e.target.value))}
                    className="w-full accent-orange-500 cursor-pointer py-1"
                  />
                  <div className="flex justify-between text-[8px] font-mono text-zinc-500">
                    <span>Lv.1 (Stage 1)</span>
                    <span>Lv.4 (Stage 2)</span>
                    <span>Lv.8 (Stage 3 Max)</span>
                  </div>
                  
                  <div className="pt-1.5 grid grid-cols-2 gap-2">
                    <div className="text-[9px] font-mono text-zinc-400">
                      XP PROGRESS: 
                      <input 
                        type="number" 
                        min="0" 
                        max="99" 
                        value={editXp} 
                        onChange={(e) => setEditXp(Math.min(99, Math.max(0, parseInt(e.target.value) || 0)))}
                        className="bg-black border border-zinc-800 px-1 ml-1 text-center w-12 text-white font-bold"
                      />
                    </div>
                    <button 
                      type="button"
                      onClick={() => {
                        setEditLevel(1);
                        setEditXp(0);
                      }}
                      className="text-[8px] font-mono text-red-400 hover:underline text-right"
                    >
                      [Reset Progress]
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Image URL</label>
                  <input
                    type="text"
                    value={editImageUrl}
                    onChange={(e) => setEditImageUrl(e.target.value)}
                    className="w-full bg-zinc-950 text-xs font-mono border border-zinc-800 px-3.5 py-2 rounded-lg text-white outline-none focus:border-orange-500"
                    placeholder="Vector image link"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Flavor Text</label>
                  <textarea
                    rows={2}
                    value={editFlavorText}
                    onChange={(e) => setEditFlavorText(e.target.value)}
                    className="w-full bg-zinc-950 text-xs font-sans border border-zinc-800 px-3.5 py-2 rounded-lg text-white outline-none focus:border-orange-500 resize-none"
                  />
                </div>
              </div>

              {/* Evolution Stage Custom Moves Grid */}
              <div className="space-y-4">
                <h3 className="text-xs font-mono font-black text-orange-400 uppercase tracking-widest border-b border-zinc-850 pb-2 flex justify-between items-center">
                  <span>Evolution Stage Moveset</span>
                  <span className="text-[10px] text-green-400 font-extrabold font-mono">3 LEVELS OF SKILL</span>
                </h3>

                {/* Stage 1 Move */}
                <div className={`p-3 rounded-xl border transition-colors ${preview.activeStage === 1 ? 'bg-orange-950/10 border-orange-500/70' : 'bg-zinc-900/30 border-zinc-850'}`}>
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[10px] font-mono font-black text-zinc-400 uppercase tracking-wide">
                      ⚡ STAGE 1 (Lv. 1-3)
                    </span>
                    {preview.activeStage === 1 && <span className="bg-orange-500 text-black font-extrabold text-[7px] px-1.5 py-0.5 rounded uppercase">ACTIVE</span>}
                  </div>
                  <div className="space-y-2">
                    <input
                      type="text"
                      value={editAbility1Name}
                      onChange={(e) => setEditAbility1Name(e.target.value)}
                      placeholder="Stage 1 Move Name"
                      className="w-full bg-zinc-950 text-xs font-sans font-bold border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500"
                    />
                    <textarea
                      rows={1.5}
                      value={editAbility1Desc}
                      onChange={(e) => setEditAbility1Desc(e.target.value)}
                      placeholder="Stage 1 Move Effect description"
                      className="w-full bg-zinc-950 text-[10px] font-sans border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500 resize-none"
                    />
                  </div>
                </div>

                {/* Stage 2 Move */}
                <div className={`p-3 rounded-xl border transition-colors ${preview.activeStage === 2 ? 'bg-orange-950/10 border-orange-500/70' : 'bg-zinc-900/30 border-zinc-850'}`}>
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[10px] font-mono font-black text-zinc-400 uppercase tracking-wide">
                      🔥 STAGE 2 (Lv. 4-7)
                    </span>
                    {preview.activeStage === 2 && <span className="bg-orange-500 text-black font-extrabold text-[7px] px-1.5 py-0.5 rounded uppercase">ACTIVE</span>}
                  </div>
                  <div className="space-y-2">
                    <input
                      type="text"
                      value={editAbility2Name}
                      onChange={(e) => setEditAbility2Name(e.target.value)}
                      placeholder="Stage 2 Move Name"
                      className="w-full bg-zinc-950 text-xs font-sans font-bold border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500"
                    />
                    <textarea
                      rows={1.5}
                      value={editAbility2Desc}
                      onChange={(e) => setEditAbility2Desc(e.target.value)}
                      placeholder="Stage 2 Move Effect description"
                      className="w-full bg-zinc-950 text-[10px] font-sans border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500 resize-none"
                    />
                  </div>
                </div>

                {/* Stage 3 Move */}
                <div className={`p-3 rounded-xl border transition-colors ${preview.activeStage === 3 ? 'bg-[#1e152a] border-purple-500/50' : 'bg-zinc-900/30 border-zinc-850'}`}>
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[10px] font-mono font-black text-purple-400 uppercase tracking-wide">
                      👑 STAGE 3 (ULTIMATE Lv. 8-10)
                    </span>
                    {preview.activeStage === 3 && <span className="bg-purple-500 text-white font-extrabold text-[7px] px-1.5 py-0.5 rounded uppercase">ACTIVE</span>}
                  </div>
                  <div className="space-y-2">
                    <input
                      type="text"
                      value={editAbility3Name}
                      onChange={(e) => setEditAbility3Name(e.target.value)}
                      placeholder="Stage 3 Move Name"
                      className="w-full bg-zinc-950 text-xs font-sans font-bold border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500"
                    />
                    <textarea
                      rows={1.5}
                      value={editAbility3Desc}
                      onChange={(e) => setEditAbility3Desc(e.target.value)}
                      placeholder="Stage 3 Move Effect description"
                      className="w-full bg-zinc-950 text-[10px] font-sans border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500 resize-none"
                    />
                  </div>
                </div>
              </div>

              {/* CARD PREVIEW STRIP / LOWER HERO ROW */}
              <div className="md:col-span-2 border-t border-zinc-850 pt-5 mt-3 flex flex-col md:flex-row items-center justify-between gap-4">
                
                {/* Dynamically Calibrated Stat Preview Details */}
                <div className="flex flex-col sm:flex-row gap-5 text-left border-l-2 border-orange-500/50 pl-4">
                  <div>
                    <span className="text-[9px] font-mono text-zinc-500 block uppercase font-bold">Multiplied ATK</span>
                    <span className="text-xl font-sans font-black text-yellow-400">
                      {Math.round(preview.activeAttack * 10)}
                    </span>
                    <span className="text-[8px] font-mono text-zinc-450 ml-1.5">(Base {editBaseAttack} * {preview.rawMultiplier.toFixed(2)}x)</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-zinc-500 block uppercase font-bold">Multiplied HP</span>
                    <span className="text-xl font-sans font-black text-emerald-400">
                      {Math.round(preview.activeHealth * 10)}
                    </span>
                    <span className="text-[8px] font-mono text-zinc-450 ml-1.5">(Base {editBaseHealth} * {preview.rawMultiplier.toFixed(2)}x)</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-zinc-500 block uppercase font-bold">Evolution Form</span>
                    <span className="text-xs font-mono font-bold text-purple-400 uppercase">
                      Stage {preview.activeStage}
                    </span>
                    <p className="text-[8.5px] font-sans font-black text-indigo-200 mt-1 uppercase max-w-[200px] truncate">
                      ⚡ Active: {preview.activeMoveName}
                    </p>
                  </div>
                </div>

                {/* Action trigger button */}
                <div className="flex gap-2.5 w-full md:w-auto justify-end">
                  <button
                    type="button"
                    onClick={handleSaveCardEdits}
                    className="w-full md:w-auto bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-black text-xs font-mono font-bold tracking-wider px-6 py-3 rounded-xl uppercase flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    {saveSuccess ? (
                      <>
                        <Check className="w-4 h-4 text-black animate-scaleIn" />
                        Card Modified!
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 text-black" />
                        Apply Custom Configuration
                      </>
                    )}
                  </button>
                </div>

              </div>

            </div>
          </div>
        </div>
      ) : (
        /* CREATE CARD MODULE STAGE */
        <div className="bg-[#0b0c16]/30 border border-zinc-850 p-6 rounded-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-6">
            
            {/* Identity variables inputs */}
            <div className="space-y-4">
              <h3 className="text-xs font-mono font-black text-orange-400 uppercase tracking-widest border-b border-zinc-850 pb-2">
                EXPERIMENTAL PROTOTYPE DESIGN LAB
              </h3>

              <div>
                <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Card Name / Title</label>
                <input
                  type="text"
                  value={createName}
                  onChange={(e) => setCreateName(e.target.value)}
                  placeholder="e.g. Master Dread-Mech"
                  className="w-full bg-zinc-950 text-xs font-sans border border-zinc-850 px-3.5 py-2.5 rounded-lg text-white outline-none focus:border-orange-500 placeholder-zinc-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Starting Rarity</label>
                  <select
                    value={createRarity}
                    onChange={(e) => handleCreateRarityChange(e.target.value as Rarity)}
                    className="w-full bg-zinc-950 text-xs font-mono border border-zinc-850 px-3 py-2.5 rounded-lg text-white outline-none focus:border-orange-500 cursor-pointer"
                  >
                    <option value="Common">Common</option>
                    <option value="Uncommon">Uncommon</option>
                    <option value="Gold Legendary">Gold Legendary</option>
                    <option value="Exotic">Exotic</option>
                    <option value="Limited Edition">Limited Edition</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Faction Category</label>
                  <select
                    value={createCategory}
                    onChange={(e) => setCreateCategory(e.target.value as CardCategory)}
                    className="w-full bg-zinc-950 text-xs font-mono border border-zinc-850 px-3 py-2.5 rounded-lg text-white outline-none focus:border-orange-500 cursor-pointer"
                  >
                    <option value="Infantry">Infantry</option>
                    <option value="Vehicles">Vehicles</option>
                    <option value="Aircraft">Aircraft</option>
                    <option value="Naval">Naval</option>
                    <option value="Mechs">Mechs</option>
                    <option value="Bosses">Bosses</option>
                    <option value="Support">Support</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Deploy Cost</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={createCost}
                    onChange={(e) => setCreateCost(parseInt(e.target.value) || 1)}
                    className="w-full bg-zinc-950 text-xs font-mono border border-zinc-850 px-3 py-2.5 rounded-lg text-white text-center outline-none focus:border-orange-500"
                  />
                </div>
                
                <div>
                  <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Base ATK</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={createBaseAttack}
                    onChange={(e) => setCreateBaseAttack(parseInt(e.target.value) || 1)}
                    className="w-full bg-zinc-950 text-xs font-mono border border-zinc-850 px-3 py-2.5 rounded-lg text-white text-center outline-none focus:border-orange-500"
                  />
                </div>
                
                <div>
                  <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Base HP</label>
                  <input
                    type="number"
                    min="1"
                    max="20"
                    value={createBaseHealth}
                    onChange={(e) => setCreateBaseHealth(parseInt(e.target.value) || 1)}
                    className="w-full bg-zinc-950 text-xs font-mono border border-zinc-850 px-3 py-2.5 text-white text-center rounded-lg outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Vector Art URL</label>
                <input
                  type="text"
                  value={createImageUrl}
                  onChange={(e) => setCreateImageUrl(e.target.value)}
                  placeholder="e.g. https://misu.nephbox.net/card_image/..."
                  className="w-full bg-zinc-950 text-xs font-mono border border-zinc-850 px-3.5 py-2.5 rounded-lg text-white outline-none focus:border-orange-500 placeholder-zinc-700"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase mb-1.5">Card Flavor / Description</label>
                <textarea
                  rows={2}
                  value={createFlavorText}
                  onChange={(e) => setCreateFlavorText(e.target.value)}
                  placeholder="Enter futuristic weapon description parameters..."
                  className="w-full bg-zinc-950 text-xs font-sans border border-zinc-850 px-3.5 py-2.5 rounded-lg text-white outline-none focus:border-orange-500 resize-none placeholder-zinc-700"
                />
              </div>
            </div>

            {/* Stage movesets configuration */}
            <div className="space-y-4">
              <h3 className="text-xs font-mono font-black text-orange-400 uppercase tracking-widest border-b border-zinc-850 pb-2 flex justify-between items-center">
                <span>Evolving Move Matrix (3 Tiers)</span>
                <span className="text-[10px] text-zinc-500 font-mono font-bold">STARTING MOVES</span>
              </h3>

              {/* Tier 1 Level up move */}
              <div className="p-3 bg-zinc-900/40 rounded-xl border border-zinc-850 space-y-2">
                <span className="text-[10px] font-mono font-black text-zinc-400 uppercase tracking-wide">
                  ⚡ Move Tier 1 (Stage 1 / Level 1-3)
                </span>
                <input
                  type="text"
                  value={createAbility1Name}
                  onChange={(e) => setCreateAbility1Name(e.target.value)}
                  placeholder="Primary Move Name (e.g. Laser Assault)"
                  className="w-full bg-zinc-950 text-xs font-sans font-bold border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500 placeholder-zinc-600"
                />
                <textarea
                  rows={1.2}
                  value={createAbility1Desc}
                  onChange={(e) => setCreateAbility1Desc(e.target.value)}
                  placeholder="Primary Move descriptions of mechanics"
                  className="w-full bg-zinc-950 text-[10px] font-sans border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500 resize-none placeholder-zinc-600"
                />
              </div>

              {/* Tier 2 Level up move */}
              <div className="p-3 bg-zinc-900/40 rounded-xl border border-zinc-850 space-y-2">
                <span className="text-[10px] font-mono font-black text-zinc-400 uppercase tracking-wide">
                  🔥 Move Tier 2 (Stage 2 / Level 4-7)
                </span>
                <input
                  type="text"
                  value={createAbility2Name}
                  onChange={(e) => setCreateAbility2Name(e.target.value)}
                  placeholder="Evolved Move Name (e.g. Nova Overdrive)"
                  className="w-full bg-zinc-950 text-xs font-sans font-bold border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500 placeholder-zinc-600"
                />
                <textarea
                  rows={1.2}
                  value={createAbility2Desc}
                  onChange={(e) => setCreateAbility2Desc(e.target.value)}
                  placeholder="Evolved Move power effect specifications"
                  className="w-full bg-zinc-950 text-[10px] font-sans border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500 resize-none placeholder-zinc-600"
                />
              </div>

              {/* Tier 3 Level up move */}
              <div className="p-3 bg-[#1e152a]/20 rounded-xl border border-[#4c1d95]/40 space-y-2">
                <span className="text-[10px] font-mono font-black text-purple-400 uppercase tracking-wide">
                  👑 Move Tier 3 (Stage 3 Ultimate / Level 8-10)
                </span>
                <input
                  type="text"
                  value={createAbility3Name}
                  onChange={(e) => setCreateAbility3Name(e.target.value)}
                  placeholder="Ultimate Move Name"
                  className="w-full bg-zinc-950 text-xs font-sans font-bold border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500 placeholder-zinc-600"
                />
                <textarea
                  rows={1.2}
                  value={createAbility3Desc}
                  onChange={(e) => setCreateAbility3Desc(e.target.value)}
                  placeholder="Ultimate Move power description parameter"
                  className="w-full bg-zinc-950 text-[10px] font-sans border border-zinc-850 px-2.5 py-1.5 rounded-md text-white outline-none focus:border-orange-500 resize-none placeholder-zinc-600"
                />
              </div>
            </div>

          </div>

          <div className="border-t border-zinc-850 pt-5 mt-4 flex justify-between items-center">
            <p className="text-[10px] font-mono text-zinc-500 max-w-lg">
              Newly designed prototypes will automatically spawn in card listings. By default, custom designed cards will instantly start at **Level 1** on the first stage, progressing up to **Stage 3** as they level up.
            </p>
            <button
              type="button"
              onClick={handleCreateNewCard}
              disabled={!createName.trim()}
              className="bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-400 hover:to-amber-300 disabled:opacity-50 text-black text-xs font-mono font-bold tracking-wider px-8 py-3 rounded-xl uppercase flex items-center gap-2 shadow-lg transition-all active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4 text-black" />
              Build Experimental Card
            </button>
          </div>
        </div>
      )}

      {/* FOOTER INFO STRIP */}
      <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl flex gap-3 text-xs text-zinc-400">
        <Info className="w-5 h-5 text-orange-500 shrink-0" />
        <p className="leading-relaxed font-mono text-[10px]">
          <b>EVOLUTION SPECIFICATION SHEETS:</b> Stage 1 (Lv.1 to Lv.3) scales attack and health to 100% - 120%. Stage 2 (Lv.4 to Lv.7) grants 135% - 170% stats and evolves the move. Stage 3 (Lv.8 to Lv.10) scales to 185% - 225% stats of standard baseline, transforming the unit into its ultimate combat module. Try setting card levels above to see live multi-stage moves change dynamically!
        </p>
      </div>
    </div>
  );
}
