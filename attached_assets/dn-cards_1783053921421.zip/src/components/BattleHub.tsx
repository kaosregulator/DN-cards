/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sword, Shield, RefreshCw, Zap, Trophy, Play, Award, 
  ChevronRight, Sparkles, User, HelpCircle, ArrowRight, CornerDownLeft, Volume2, VolumeX
} from 'lucide-react';
import { Card, GameRank } from '../types';
import { CARD_DATABASE, addCardXp } from '../data/cards';

interface BattleHubProps {
  playerDeckIds: string[]; // custom selected or unlocked deck
  dnShards: number;
  playerRank: GameRank;
  addXp: (amount: number) => void;
  addShards: (amount: number) => void;
  addMatchHistory: (opponent: string, rank: GameRank, mode: 'Ranked' | 'Casual', result: 'Victory' | 'Defeat', xp: number, shards: number, turns: number) => void;
  ownedCardIds: string[]; // full inventory of owned cards
}

interface CombatCard extends Card {
  currentHealth: number;
  maxHealth: number;
  instanceId: string;
}

export default function BattleHub({
  playerDeckIds,
  dnShards,
  playerRank,
  addXp,
  addShards,
  addMatchHistory,
  ownedCardIds = []
}: BattleHubProps) {
  // Sound controls
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Matchmaking / setup state
  const [gameMode, setGameMode] = useState<'Ranked' | 'Casual' | null>(null);
  const [searchTimer, setSearchTimer] = useState(0);
  const [opponentName, setOpponentName] = useState('Opponent Player');
  const [opponentRank, setOpponentRank] = useState<GameRank>('Recruit');
  
  // Game states
  const [battleState, setBattleState] = useState<'setup' | 'searching' | 'active' | 'resolved'>('setup');
  const [winner, setWinner] = useState<'player' | 'enemy' | null>(null);
  const [turn, setTurn] = useState<'player' | 'enemy'>('player');
  const [turnNumber, setTurnNumber] = useState(1);
  const [battleLog, setBattleLog] = useState<string[]>([]);
  
  // Commander hit points
  const [playerHP, setPlayerHP] = useState(30);
  const [enemyHP, setEnemyHP] = useState(30);

  // Deck, Hands & Active Battle slots
  const [playerDeck, setPlayerDeck] = useState<Card[]>([]);
  const [enemyDeck, setEnemyDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<CombatCard[]>([]);
  const [enemyHand, setEnemyHand] = useState<CombatCard[]>([]);
  
  const [playerActive, setPlayerActive] = useState<CombatCard | null>(null);
  const [enemyActive, setEnemyActive] = useState<CombatCard | null>(null);

  // Attack animations / Damage numbers popup overlays
  const [isPlayerAttacking, setIsPlayerAttacking] = useState(false);
  const [isEnemyAttacking, setIsEnemyAttacking] = useState(false);
  const [playerDamagePopup, setPlayerDamagePopup] = useState<{ amount: number; type: 'damage' | 'heal' | 'ability' } | null>(null);
  const [enemyDamagePopup, setEnemyDamagePopup] = useState<{ amount: number; type: 'damage' | 'heal' | 'ability' } | null>(null);

  // Scroll ref for Combat logs
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logEndRef.current) {
      logEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [battleLog]);

  // Matchmaking simulation
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (battleState === 'searching') {
      const opponents = [
        'SniperAce_DN', 'Chrono_Warden', 'Kowalski_Collector', 'ApexTactician', 
        'Zev_Mech', 'Overlord_Cards', 'Viper_Master', 'Iron_Vanguard'
      ];
      const ranks: GameRank[] = ['Recruit', 'Corporal', 'Sergeant', 'Lieutenant', 'Captain', 'Major', 'Colonel'];
      setOpponentName(opponents[Math.floor(Math.random() * opponents.length)]);
      setOpponentRank(ranks[Math.floor(Math.random() * ranks.length)]);

      interval = setInterval(() => {
        setSearchTimer(prev => {
          if (prev >= 3) {
            clearInterval(interval);
            startBattle();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [battleState]);

  // Initiate Combat
  const startBattle = () => {
    // Collect player's true current inventory cards
    // Filter against CARD_DATABASE to match owned card ids
    let playerSourceCards = CARD_DATABASE.filter(c => c.isStarter || ownedCardIds.includes(c.id));
    
    // In case player deck has custom list, we prefer using that!
    if (playerDeckIds && playerDeckIds.length > 0) {
      const customMatches = playerDeckIds
        .map(id => CARD_DATABASE.find(c => c.id === id))
        .filter(Boolean) as Card[];
      if (customMatches.length > 0) {
        playerSourceCards = customMatches;
      }
    }

    // Fallback: If no cards, take full database starter cards
    if (playerSourceCards.length === 0) {
      playerSourceCards = CARD_DATABASE.filter(c => c.isStarter);
    }

    // Build player deck (at least 12 cards by duplicating if needed)
    let finalPlayerDeck = [...playerSourceCards];
    while (finalPlayerDeck.length < 12) {
      finalPlayerDeck = [...finalPlayerDeck, ...playerSourceCards];
    }
    
    // Shuffle player deck
    finalPlayerDeck = finalPlayerDeck.sort(() => Math.random() - 0.5);

    // Build opponent deck (random selection from CARD_DATABASE)
    const enemySourceCards = [...CARD_DATABASE].sort(() => Math.random() - 0.5).slice(0, 8);
    let finalEnemyDeck = [...enemySourceCards, ...enemySourceCards];
    finalEnemyDeck = finalEnemyDeck.sort(() => Math.random() - 0.5);

    // Initial draw: 6 cards each!
    const initialPlayerHand = finalPlayerDeck.slice(0, 6).map((c, i) => ({
      ...c,
      currentHealth: c.health,
      maxHealth: c.health,
      instanceId: `p_${c.id}_${i}_${Date.now()}`
    }));

    const initialEnemyHand = finalEnemyDeck.slice(0, 6).map((c, i) => ({
      ...c,
      currentHealth: c.health,
      maxHealth: c.health,
      instanceId: `e_${c.id}_${i}_${Date.now()}`
    }));

    setPlayerDeck(finalPlayerDeck.slice(6));
    setEnemyDeck(finalEnemyDeck.slice(6));
    setPlayerHand(initialPlayerHand);
    setEnemyHand(initialEnemyHand);
    setPlayerActive(null);
    setEnemyActive(null);
    setPlayerHP(30);
    setEnemyHP(30);
    setTurn('player');
    setTurnNumber(1);
    setWinner(null);
    setBattleLog([
      `Battle commenced vs ${opponentName} (${opponentRank})!`,
      `Both players deploy combat units with 6-card starting hands drawn from active card collections.`,
      `Deploy an active combat card from your hand to take the frontline!`
    ]);
    setBattleState('active');
  };

  // Play card from player hand to active zone
  const deployPlayerCard = (instanceId: string) => {
    if (battleState !== 'active' || turn !== 'player') return;
    
    const cardToDeploy = playerHand.find(c => c.instanceId === instanceId);
    if (!cardToDeploy) return;

    // Handle Event Assist Cards differently: they play instantly, trigger their effect, and are discarded!
    if (cardToDeploy.category === 'Event') {
      triggerEventEffect(cardToDeploy, 'player');
      setPlayerHand(prev => prev.filter(c => c.instanceId !== instanceId));
      return;
    }

    // Deploy to active slot
    if (playerActive) {
      // Return previous active to hand or prevent deployment
      setBattleLog(prev => [...prev, `Frontline occupied! Deploy [${cardToDeploy.name}] once active slot becomes compromised.`]);
      return;
    }

    setPlayerActive(cardToDeploy);
    setPlayerHand(prev => prev.filter(c => c.instanceId !== instanceId));
    setBattleLog(prev => [...prev, `You deployed [${cardToDeploy.name}] (${cardToDeploy.rarity}) to the Frontline Active slot!`]);
    
    // Play ability immediately on enter if exists
    if (cardToDeploy.abilityName && cardToDeploy.abilityDescription) {
      setBattleLog(prev => [...prev, `-> TRIGGER [${cardToDeploy.abilityName}]: ${cardToDeploy.abilityDescription}`]);
      applyDeployAbility(cardToDeploy, 'player');
    }
  };

  // Event Assist instant spells
  const triggerEventEffect = (card: CombatCard, side: 'player' | 'enemy') => {
    setBattleLog(prev => [...prev, `[EVENT INITIATED] ${card.name}: ${card.abilityDescription}`]);
    
    if (side === 'player') {
      setEnemyDamagePopup({ amount: 4, type: 'ability' });
      // Event logic
      if (card.id === 'event_anniversary') { // All allies heal, enemies take hit
        if (playerActive) {
          setPlayerActive(prev => prev ? { ...prev, currentHealth: Math.min(prev.maxHealth, prev.currentHealth + 3) } : null);
        }
        setEnemyHP(prev => Math.max(0, prev - 3));
        setBattleLog(prev => [...prev, `-> Fireworks burst: Healed Active Card +3 HP and dealt 3 shock damage to Opponent commander!`]);
      } else if (card.id === 'event_holiday') { // Deep freeze enemy active
        if (enemyActive) {
          setEnemyActive(prev => prev ? { ...prev, isStunned: true } : null);
          setBattleLog(prev => [...prev, `-> Blizzard blast: Frozen and stunned Enemy active unit!`]);
        } else {
          setEnemyHP(prev => Math.max(0, prev - 4));
          setBattleLog(prev => [...prev, `-> Cold front: Dealt 4 freezing damage to Enemy commander!`]);
        }
      } else if (card.id === 'event_partner') { // supply details / draw cards
        drawPlayerCards(2);
        setPlayerHP(prev => Math.min(30, prev + 5));
        setBattleLog(prev => [...prev, `-> Partner drop: Drew 2 extra cards and repaired Commander armor (+5 HP)!`]);
      } else { // Global Discord Rally: Double active attack
        if (playerActive) {
          setPlayerActive(p => p ? { ...p, attack: p.attack * 2 } : null);
          setBattleLog(prev => [...prev, `-> Global rally: [${playerActive?.name}] Attack power doubled to ${playerActive ? playerActive.attack * 2 : 0}!`]);
        } else {
          setEnemyHP(prev => Math.max(0, prev - 5));
          setBattleLog(prev => [...prev, `-> Community uproar: Dealt 5 direct damage to Enemy player!`]);
        }
      }
    } else {
      // Enemy events
      setPlayerDamagePopup({ amount: 4, type: 'ability' });
      if (card.id === 'event_anniversary') {
        if (enemyActive) {
          setEnemyActive(p => p ? { ...p, currentHealth: Math.min(p.maxHealth, p.currentHealth + 3) } : null);
        }
        setPlayerHP(p => Math.max(0, p - 3));
      } else if (card.id === 'event_holiday') {
        if (playerActive) {
          setPlayerActive(p => p ? { ...p, isStunned: true } : null);
        }
      } else {
        setEnemyHP(p => Math.min(30, p + 5));
        drawEnemyCards(2);
      }
    }

    checkGameSurvival();
  };

  // Immediate unit battle entry abilities
  const applyDeployAbility = (unit: CombatCard, side: 'player' | 'enemy') => {
    if (side === 'player') {
      if (unit.id === 'starter_scout') { // Deals 1 instant damage to enemy active
        if (enemyActive) {
          setEnemyActive(prev => prev ? { ...prev, currentHealth: Math.max(0, prev.currentHealth - 2) } : null);
          setEnemyDamagePopup({ amount: 2, type: 'ability' });
          setBattleLog(prev => [...prev, `-> Scout radar targets Enemy [${enemyActive?.name}] for 2 instant ambush damage!`]);
        } else {
          setEnemyHP(prev => Math.max(0, prev - 2));
          setBattleLog(prev => [...prev, `-> Scout radar delivers 2 direct damage to Opponent player!`]);
        }
      } else if (unit.id === 'starter_medic') { // heal player
        setPlayerHP(prev => Math.min(30, prev + 4));
        setPlayerDamagePopup({ amount: 4, type: 'heal' });
        setBattleLog(prev => [...prev, `-> Medic drone repair: Player recovers +4 HP!`]);
      } else if (unit.id === 'coll_apc') { // Draw a card
        drawPlayerCards(1);
      } else if (unit.id === 'coll_stealth_bomber') { // Stun strongest
        if (enemyActive) {
          setEnemyActive(p => p ? { ...p, isStunned: true } : null);
          setBattleLog(prev => [...prev, `-> Stealth lock: Enemy active unit was stunned!`]);
        }
      }
    } else {
      // Enemy deployment abilities
      if (unit.id === 'starter_scout') {
        if (playerActive) {
          setPlayerActive(prev => prev ? { ...prev, currentHealth: Math.max(0, prev.currentHealth - 2) } : null);
          setPlayerDamagePopup({ amount: 2, type: 'ability' });
        } else {
          setPlayerHP(prev => Math.max(0, prev - 2));
        }
      } else if (unit.id === 'starter_medic') {
        setEnemyHP(prev => Math.min(30, prev + 4));
      }
    }
    checkGameSurvival();
  };

  // Draw card mechanics
  const drawPlayerCards = (count: number) => {
    if (playerDeck.length === 0) {
      setBattleLog(prev => [...prev, `No cards remaining in your tactical supply pile!`]);
      return;
    }
    const drawn = playerDeck.slice(0, count).map((c, i) => ({
      ...c,
      currentHealth: c.health,
      maxHealth: c.health,
      instanceId: `p_${c.id}_${i}_${Date.now()}`
    }));
    setPlayerDeck(prev => prev.slice(count));
    setPlayerHand(prev => [...prev, ...drawn].slice(0, 8)); // lock hand max size at 8
    setBattleLog(prev => [...prev, `You drew ${drawn.length} card(s) from your collection deck.`]);
  };

  const drawEnemyCards = (count: number) => {
    if (enemyDeck.length === 0) return;
    const drawn = enemyDeck.slice(0, count).map((c, i) => ({
      ...c,
      currentHealth: c.health,
      maxHealth: c.health,
      instanceId: `e_${c.id}_${i}_${Date.now()}`
    }));
    setEnemyDeck(prev => prev.slice(count));
    setEnemyHand(prev => [...prev, ...drawn].slice(0, 8));
  };

  // Perform active turn attack sequence
  const executeAttack = () => {
    if (battleState !== 'active' || turn !== 'player') return;

    if (!playerActive) {
      setBattleLog(prev => [...prev, `Deploy an active combat card from your hand first before attacking!`]);
      return;
    }

    if (playerActive.isStunned) {
      setBattleLog(prev => [...prev, `Your current active card [${playerActive.name}] is frozen and cannot strike this turn.`]);
      return;
    }

    if (playerActive.hasAttacked) {
      setBattleLog(prev => [...prev, `[${playerActive.name}] already locked other targets this turn!`]);
      return;
    }

    // Initiate attacking animations
    setIsPlayerAttacking(true);
    setTimeout(() => setIsPlayerAttacking(false), 600);

    // Target Resolve
    if (enemyActive) {
      // Active unit vs Active unit combat!
      const damageToEnemy = playerActive.attack;
      const damageToPlayer = enemyActive.attack;

      setEnemyDamagePopup({ amount: damageToEnemy, type: 'damage' });
      setPlayerDamagePopup({ amount: damageToPlayer, type: 'damage' });

      const newEnemyHP = Math.max(0, enemyActive.currentHealth - damageToEnemy);
      const newPlayerHP = Math.max(0, playerActive.currentHealth - damageToPlayer);

      setBattleLog(prev => [
        ...prev,
        `Combat Strike! Your [${playerActive.name}] assaults hostile [${enemyActive.name}]:`,
        `-> Dealt ${damageToEnemy} damage to Enemy unit (remains: ${newEnemyHP}/${enemyActive.maxHealth} HP)`,
        `-> Enemy countered, dealing ${damageToPlayer} clash damage to your unit (remains: ${newPlayerHP}/${playerActive.maxHealth} HP)`
      ]);

      // Update Health
      setPlayerActive(prev => {
        if (!prev) return null;
        if (newPlayerHP <= 0) {
          setBattleLog(p => [...p, `Your frontline active trooper [${prev.name}] was neutralized!`]);
          return null;
        }
        return { ...prev, currentHealth: newPlayerHP, hasAttacked: true };
      });

      setEnemyActive(prev => {
        if (!prev) return null;
        if (newEnemyHP <= 0) {
          setBattleLog(p => [...p, `Hostile front [${prev.name}] was shattered and discarded!`]);
          return null;
        }
        return { ...prev, currentHealth: newEnemyHP };
      });

    } else {
      // Direct hit against the enemy Player!
      const directDmg = playerActive.attack;
      setEnemyDamagePopup({ amount: directDmg, type: 'damage' });
      setEnemyHP(prev => {
        const next = Math.max(0, prev - directDmg);
        setBattleLog(p => [...p, `Direct Strike! Your [${playerActive.name}] bypasses defenses, delivering ${directDmg} damage to Opponent Player (HP: ${next}/30)!`]);
        if (next <= 0) {
          triggerWin('player');
        }
        return next;
      });

      setPlayerActive(p => p ? { ...p, hasAttacked: true } : null);
    }
  };

  // End player turn and start opponent AI decisions
  const endTurn = () => {
    if (battleState !== 'active') return;
    
    // Clear attack flag on active
    if (playerActive) {
      setPlayerActive(p => p ? { ...p, hasAttacked: false, isStunned: false } : null);
    }

    setTurn('enemy');
    setBattleLog(prev => [...prev, `--- Opponent Turn Begun ---`]);

    // Draw cards for player automatically as they keep inventory flowing
    if (playerHand.length < 6) {
      drawPlayerCards(1);
    }

    // Run AI opponent gameplay loop
    setTimeout(() => {
      runAITurn();
    }, 1200);
  };

  // AI Logic Game Loop
  const runAITurn = () => {
    setGameStateAndReact(prevLog => {
      // Make internal copies
      let currentEnemyHP = enemyHP;
      let currentPlayerHP = playerHP;
      let activeEnemy = enemyActive;
      let activePlayer = playerActive;
      let enemyH = [...enemyHand];
      let enemyD = [...enemyDeck];
      const logs: string[] = [];

      // 1. Draw a card if hand is low
      if (enemyH.length < 6 && enemyD.length > 0) {
        const nextCard = enemyD[0];
        enemyD.shift();
        enemyH.push({
          ...nextCard,
          currentHealth: nextCard.health,
          maxHealth: nextCard.health,
          instanceId: `e_${nextCard.id}_${Date.now()}`
        });
        logs.push(`Opponent draws 1 card from their collection deck.`);
      }

      // 2. Deploy a unit if active slot is empty
      if (!activeEnemy) {
        // Find first playable unit (non-event) in hand
        const playableUnitIndex = enemyH.findIndex(c => c.category !== 'Event');
        if (playableUnitIndex !== -1) {
          activeEnemy = enemyH[playableUnitIndex];
          enemyH.splice(playableUnitIndex, 1);
          logs.push(`Opponent deploys active unit [${activeEnemy.name}] (${activeEnemy.rarity}) to secure defenses!`);

          // Execute enter play ability
          if (activeEnemy.id === 'starter_scout') {
            if (activePlayer) {
              activePlayer = { ...activePlayer, currentHealth: Math.max(0, activePlayer.currentHealth - 2) };
              logs.push(`-> Enemy scout radar targets [${activePlayer.name}] for 2 ambush damage!`);
            } else {
              currentPlayerHP = Math.max(0, currentPlayerHP - 2);
              logs.push(`-> Enemy scout radar inflicts 2 damage directly to you!`);
            }
          } else if (activeEnemy.id === 'starter_medic') {
            currentEnemyHP = Math.min(30, currentEnemyHP + 4);
            logs.push(`-> Enemy medic repair restores +4 Hostile Player HP.`);
          }
        } else {
          // Play Event if only event cards left
          const eventIndex = enemyH.findIndex(c => c.category === 'Event');
          if (eventIndex !== -1) {
            const eventCard = enemyH[eventIndex];
            enemyH.splice(eventIndex, 1);
            logs.push(`Opponent initiates Event Card: [${eventCard.name}]`);
            
            if (eventCard.id === 'event_anniversary') {
              currentPlayerHP = Math.max(0, currentPlayerHP - 3);
            } else if (eventCard.id === 'event_holiday') {
              if (activePlayer) activePlayer.isStunned = true;
            } else {
              currentEnemyHP = Math.min(30, currentEnemyHP + 5);
            }
          }
        }
      } else if (Math.random() > 0.4) {
        // Maybe play event to change outcome
        const eventIndex = enemyH.findIndex(c => c.category === 'Event');
        if (eventIndex !== -1) {
          const eventCard = enemyH[eventIndex];
          enemyH.splice(eventIndex, 1);
          logs.push(`Opponent coordinates Event Card: [${eventCard.name}]`);
          if (eventCard.id === 'event_anniversary') {
            currentPlayerHP = Math.max(0, currentPlayerHP - 3);
          } else if (eventCard.id === 'event_holiday') {
            if (activePlayer) activePlayer.isStunned = true;
          } else {
            currentEnemyHP = Math.min(30, currentEnemyHP + 5);
          }
        }
      }

      // Check immediate death in combat
      if (activePlayer && activePlayer.currentHealth <= 0) {
        logs.push(`Your frontline active trooper [${activePlayer.name}] collapsed!`);
        activePlayer = null;
      }

      // 3. Attack if unit is active
      if (activeEnemy && !activeEnemy.isStunned) {
        setIsEnemyAttacking(true);
        setTimeout(() => setIsEnemyAttacking(false), 600);

        if (activePlayer) {
          const dmgToPlayer = activeEnemy.attack;
          const dmgToEnemy = activePlayer.attack;

          const playerNewHP = Math.max(0, activePlayer.currentHealth - dmgToPlayer);
          const enemyNewHP = Math.max(0, activeEnemy.currentHealth - dmgToEnemy);

          logs.push(`Hostile Attack! Opponent's [${activeEnemy.name}] assaults your [${activePlayer.name}]:`);
          logs.push(`-> Dealt ${dmgToPlayer} damage to your active unit.`);
          logs.push(`-> Counters strike deals ${dmgToEnemy} damage to incoming hostile.`);

          if (playerNewHP <= 0) {
            logs.push(`Your frontline active trooper [${activePlayer.name}] collapsed!`);
            activePlayer = null;
          } else {
            activePlayer = { ...activePlayer, currentHealth: playerNewHP };
          }

          if (enemyNewHP <= 0) {
            logs.push(`Hostile frontline combatant [${activeEnemy.name}] neutralized!`);
            activeEnemy = null;
          } else {
            activeEnemy = { ...activeEnemy, currentHealth: enemyNewHP };
          }
        } else {
          // Direct hit commander
          const incomingDmg = activeEnemy.attack;
          currentPlayerHP = Math.max(0, currentPlayerHP - incomingDmg);
          logs.push(`Direct Strike! Guest unit [${activeEnemy.name}] breaches defenses, inflicting ${incomingDmg} damage directly to you!`);
        }
      }

      // Update external structures
      setEnemyHP(currentEnemyHP);
      setPlayerHP(currentPlayerHP);
      setPlayerActive(activePlayer);
      setEnemyActive(activeEnemy);
      setEnemyHand(enemyH);
      setEnemyDeck(enemyD);

      setBattleLog(p => [...p, ...logs, `Your Turn Begun. Strategy phase active.`]);
      setTurn('player');
      setTurnNumber(prev => prev + 1);

      // Check victory
      if (currentPlayerHP <= 0) {
        triggerWin('enemy');
      } else if (currentEnemyHP <= 0) {
        triggerWin('player');
      }
    });
  };

  const setGameStateAndReact = (action: (log: string[]) => void) => {
    action(battleLog);
  };

  // Run survival checker on active spells
  const checkGameSurvival = () => {
    if (playerHP <= 0) triggerWin('enemy');
    if (enemyHP <= 0) triggerWin('player');
    if (playerActive && playerActive.currentHealth <= 0) setPlayerActive(null);
    if (enemyActive && enemyActive.currentHealth <= 0) setEnemyActive(null);
  };

  const triggerWin = (victor: 'player' | 'enemy') => {
    setWinner(victor);
    setBattleState('resolved');
    
    // Distribute Card Level XP to all cards in the active deck!
    const activeDeckCardIds = playerDeckIds && playerDeckIds.length > 0 ? playerDeckIds : ['298', '274', '261', '267', '314'];
    const cardXpAmount = victor === 'player' ? 50 : 25;
    const levelUpMessages: string[] = [];

    activeDeckCardIds.forEach(id => {
      const res = addCardXp(id, cardXpAmount);
      if (res.leveledUp) {
        const card = CARD_DATABASE.find(c => c.id === id);
        if (card) {
          levelUpMessages.push(`📈 ${card.name} reached Lv. ${res.newLevel} & EVOLVED Stage ${card.stage || 1}!`);
        }
      }
    });
    
    if (victor === 'player') {
      const earnedXp = 120;
      const earnedShards = 45;
      addXp(earnedXp);
      addShards(earnedShards);
      addMatchHistory(opponentName, opponentRank, gameMode || 'Casual', 'Victory', earnedXp, earnedShards, turnNumber);
      setBattleLog(prev => [
        ...prev, 
        `🏅 BATTLE VICTORY! You defeated ${opponentName}. Earned +${earnedShards} DN Shards and +${earnedXp} XP!`,
        `⭐ Cards in your active deck gained (+${cardXpAmount} Card XP!)`,
        ...levelUpMessages
      ]);
    } else {
      const earnedXp = 40;
      const earnedShards = 15;
      addXp(earnedXp);
      addShards(earnedShards);
      addMatchHistory(opponentName, opponentRank, gameMode || 'Casual', 'Defeat', earnedXp, earnedShards, turnNumber);
      setBattleLog(prev => [
        ...prev, 
        `💀 DEFEAT. Opponent won the card battle. Earned +${earnedShards} Shards, +${earnedXp} XP.`,
        `⭐ Cards in your active deck gained (+${cardXpAmount} Card XP!)`,
        ...levelUpMessages
      ]);
    }
  };

  return (
    <div className="space-y-6" id="card-battle-arena-wrapper">
      
      {/* ARENA HEAD OVERLAY */}
      <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl flex items-center justify-between">
        <div>
          <h2 className="text-lg italic font-serif text-white tracking-wide">1v1 Card Battle Arena</h2>
          <p className="text-[10px] font-mono text-zinc-500">Pokémon & Yu-Gi-Oh style card battle system. Take control of your real Discord bot card catches!</p>
        </div>
        <div className="flex gap-2.5">
          <button 
            type="button" 
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 border border-zinc-800 text-zinc-400 hover:text-white"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-orange-500" /> : <VolumeX className="w-4 h-4" />}
          </button>
          
          {battleState !== 'setup' && (
            <button 
              type="button" 
              onClick={() => setBattleState('setup')}
              className="px-4 py-1.5 border border-red-900 bg-red-950/20 text-red-400 text-[10.5px] font-mono tracking-wider hover:bg-red-950/40 uppercase"
            >
              Surrender Match
            </button>
          )}
        </div>
      </div>

      {/* SETUP SELECTION GAME MODE */}
      {battleState === 'setup' && (
        <div className="bg-zinc-900 border border-zinc-850 p-8 rounded-xl max-w-2xl mx-auto text-center space-y-6">
          <div className="mx-auto w-16 h-16 bg-orange-950/30 border border-orange-500 flex items-center justify-center text-orange-500 rounded-full animate-pulse">
            <Sword className="w-7 h-7" />
          </div>
          
          <div className="space-y-2">
            <h3 className="text-xl italic font-serif text-white">Commence Card Battle Match</h3>
            <p className="text-xs text-zinc-400 max-w-lg mx-auto">
              Test your custom Discord inventory collection against smart AI players. Draw up to 6 playable cards, summon active frontline combatants, and direct them to secure direct victories!
            </p>
          </div>

          <div className="bg-zinc-955 bg-zinc-950 p-4 border border-zinc-850 rounded text-left space-y-2.5 max-w-md mx-auto font-mono text-xs">
            <h4 className="text-[11px] text-orange-500 uppercase tracking-widest font-bold">Your Core Deck Status</h4>
            <div className="flex justify-between items-center text-xs">
              <span className="text-zinc-500">Unlocks Synchronized:</span>
              <span className="text-zinc-300 font-bold">{ownedCardIds.length > 0 ? ownedCardIds.length + 6 : 6} Cards Total</span>
            </div>
            <p className="text-[10px] text-zinc-500 italic leading-normal">
              Go to "Collectibles" to link your real stock catches from the Discord Bot, or check cards manually! All synced catches will carry over here.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-md mx-auto pt-2">
            <button
              onClick={() => { setGameMode('Casual'); setBattleState('searching'); }}
              className="py-4 bg-zinc-950 hover:bg-zinc-850 border border-zinc-800 text-zinc-200 hover:text-white transition-all text-xs font-mono tracking-wider uppercase font-bold flex flex-col items-center gap-1 cursor-pointer"
            >
              <span>[01] Casual Arena</span>
              <span className="text-[9px] text-zinc-500 font-normal">Train strategies & test catches</span>
            </button>
            <button
              onClick={() => { setGameMode('Ranked'); setBattleState('searching'); }}
              className="py-4 bg-orange-600 hover:bg-orange-500 border border-orange-500 text-black transition-all text-xs font-mono tracking-wider uppercase font-bold flex flex-col items-center gap-1 cursor-pointer"
            >
              <span>[02] Ranked Ladder</span>
              <span className="text-[9px] text-black/70 font-bold">Earn dual MMR ratings & shards</span>
            </button>
          </div>
        </div>
      )}

      {/* MATCHMAKING RADAR SEARCH */}
      {battleState === 'searching' && (
        <div className="bg-zinc-900 border border-zinc-850 p-12 rounded-xl text-center space-y-6 max-w-md mx-auto">
          <div className="relative mx-auto w-24 h-24 border-4 border-orange-500/10 rounded-full flex items-center justify-center">
            <div className="absolute inset-0 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
            <Zap className="w-8 h-8 text-orange-500 animate-pulse" />
          </div>
          
          <div className="space-y-1.5">
            <h3 className="text-sm font-sans font-extrabold uppercase text-zinc-150 tracking-wider">Connecting to Match...</h3>
            <p className="text-[11px] font-mono text-zinc-500">Searching active players in matchmaking tier {playerRank} MMR...</p>
          </div>

          <div className="bg-zinc-950 p-4 border border-zinc-855 border-zinc-800 rounded font-mono text-xs space-y-1 text-left">
            <div className="flex justify-between">
              <span className="text-zinc-500">Selected Arena:</span>
              <span className="text-zinc-200 uppercase font-bold">{gameMode} Battle</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Match status:</span>
              <span className="text-orange-500 animate-pulse">Searching...</span>
            </div>
          </div>
        </div>
      )}

      {/* REAL GAME ARENA SYSTEM */}
      {battleState === 'active' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* LEFT COMMANDERS STATUS PANEL */}
          <div className="lg:col-span-1 space-y-4">
            
            {/* OPPONENT PROFILE */}
            <div className={`p-4 rounded-xl border transition-all ${turn === 'enemy' ? 'bg-orange-950/15 border-orange-600/50' : 'bg-zinc-950 border-zinc-850'}`}>
              <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-ping"></div>
                  <span className="text-[10px] font-mono text-zinc-400">OPPONENT PLAYER</span>
                </div>
                <span className="text-[9px] font-mono bg-zinc-900 px-1.5 py-0.2 uppercase border border-zinc-800">{opponentRank}</span>
              </div>
              <div className="py-3">
                <p className="text-sm italic font-serif text-white">{opponentName}</p>
                
                {/* Custom Health stats */}
                <div className="mt-3 space-y-1">
                  <div className="flex justify-between text-[10px] font-mono">
                    <span className="text-zinc-500">Operational HP:</span>
                    <span className="text-red-400 font-bold">{enemyHP} / 30</span>
                  </div>
                  <div className="w-full bg-zinc-900 h-2 border border-zinc-800 rounded-sm overflow-hidden">
                    <div 
                      className="bg-red-500 h-full transition-all duration-300"
                      style={{ width: `${(enemyHP / 30) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* PLAYER PROFILE */}
            <div className={`p-4 rounded-xl border transition-all ${turn === 'player' ? 'bg-orange-950/15 border-orange-600/50' : 'bg-zinc-950 border-zinc-850'}`}>
              <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full"></div>
                  <span className="text-[10px] font-mono text-zinc-400">COLLECTED DECK</span>
                </div>
                <span className="text-[9px] font-mono bg-zinc-900 px-1.5 py-0.2 uppercase border border-zinc-800">{playerRank}</span>
              </div>
              <div className="py-3">
                <p className="text-sm italic font-serif text-white">Active Player</p>
                
                <div className="mt-3 space-y-1">
                  <div className="flex justify-between text-[10px] font-mono">
                    <span className="text-zinc-500">Operational HP:</span>
                    <span className="text-emerald-400 font-bold">{playerHP} / 30</span>
                  </div>
                  <div className="w-full bg-zinc-900 h-2 border border-zinc-800 rounded-sm overflow-hidden">
                    <div 
                      className="bg-emerald-500 h-full transition-all duration-300"
                      style={{ width: `${(playerHP / 30) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* LIVE COMBAT LOG */}
            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl h-[240px] flex flex-col justify-between">
              <span className="text-[9.5px] font-mono text-zinc-500 uppercase tracking-widest pb-1 border-b border-zinc-900">1v1 BATTLE COMBAT LOGS</span>
              <div className="flex-1 overflow-y-auto mt-2 space-y-2 pr-1 text-[10.5px] font-mono leading-relaxed text-zinc-400 scrollbar-thin">
                {battleLog.map((log, index) => (
                  <p key={index} className={`border-b border-zinc-950/40 pb-0.5 ${
                    log.includes('Strike') || log.includes('assaults') ? 'text-orange-400' :
                    log.includes('neutralized') || log.includes('collapsed') ? 'text-red-400' :
                    log.includes('deployed') ? 'text-emerald-350' : 'text-zinc-450'
                  }`}>
                    {log}
                  </p>
                ))}
                <div ref={logEndRef} />
              </div>
            </div>

          </div>

          {/* MAIN FRONT TACTICAL PLAYMAT BOARD */}
          <div className="lg:col-span-3 space-y-6 flex flex-col justify-between h-full min-h-[580px]">
            
            {/* ENEMY BACKFIELD GRID (Hand size details) */}
            <div className="flex justify-between items-center bg-zinc-950 p-2.5 rounded-lg border border-zinc-900 px-6">
              <div className="flex items-center gap-4">
                <span className="text-[10px] font-mono text-zinc-500">Opponent Cards Remaining:</span>
                <span className="font-sans font-bold text-red-400">{enemyHand.length} Cards in reserve</span>
              </div>
              <div className="flex gap-1.5">
                {enemyHand.map((_, i) => (
                  <div key={i} className="w-4 h-6 border border-zinc-800 bg-red-950/20 rounded-xs"></div>
                ))}
              </div>
            </div>

            {/* COMBAT FRONT PLAZA ZONES */}
            <div className="my-4 grid grid-cols-1 md:grid-cols-2 gap-8 bg-zinc-900/40 p-8 rounded-2xl border border-zinc-850/60 relative overflow-hidden">
              <div className="absolute inset-x-0 h-[1.5px] bg-red-900/20 top-1/2 -translate-y-1/2"></div>
                      {/* ENEMY COMBAT ZONE ACTIVE SLOT */}
              <div className="flex flex-col items-center justify-center space-y-3 p-4 border border-blue-900/40 rounded-xl relative bg-[#090d24]/65 min-h-[240px] shadow-inner">
                <span className="text-[8px] font-mono text-cyan-400 font-bold uppercase tracking-widest absolute top-2 animate-pulse">// HOSTILE FIGHTER ACTIVE CARD</span>
                
                <AnimatePresence mode="wait">
                  {enemyActive ? (
                    <motion.div 
                      key={enemyActive.instanceId}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ 
                        scale: 1, 
                        opacity: 1,
                        x: isEnemyAttacking ? [0, -30, 0] : 0,
                        y: isEnemyAttacking ? [0, 40, 0] : 0
                      }}
                      className="relative pt-4"
                    >
                      {/* Floating Damage Text Popup overlay */}
                      {enemyDamagePopup && (
                        <div className={`absolute -top-12 z-50 text-center w-full font-sans font-black text-2xl uppercase tracking-tighter drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)] animate-bounce ${
                          enemyDamagePopup.type === 'heal' ? 'text-emerald-400' : 'text-red-500'
                        }`}>
                          {enemyDamagePopup.type === 'heal' ? `+${enemyDamagePopup.amount * 10}` : `-${enemyDamagePopup.amount * 10}`}
                        </div>
                      )}
                      
                      {/* Custom Render Card */}
                      <div className={`pokecard-tilt holo-shine relative w-40 h-56 rounded-2xl flex flex-col p-1 bg-slate-705 ${
                        enemyActive.rarity === 'Gold Legendary' ? 'bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-600 shadow-[0_0_15px_rgba(234,179,8,0.3)]' :
                        enemyActive.rarity === 'Exotic' ? 'bg-gradient-to-r from-purple-600 via-fuchsia-400 to-indigo-700 shadow-[0_0_15px_rgba(168,85,247,0.3)]' :
                        enemyActive.rarity === 'Limited Edition' ? 'bg-gradient-to-r from-rose-600 via-pink-400 to-red-700 shadow-[0_0_20px_rgba(244,63,94,0.3)] animate-pulse' :
                        'bg-slate-700 border border-slate-500'
                      }`}>
                        
                        {/* Core card body */}
                        <div className="flex-1 rounded-xl bg-gradient-to-b from-[#090d22] to-[#12183c] p-2 flex flex-col justify-between overflow-hidden relative">
                          <div className="flex justify-between items-center z-10 border-b border-blue-900/40 pb-0.5">
                            <h4 className="text-[10px] font-sans font-black text-white truncate max-w-[85px] leading-none">{enemyActive.name}</h4>
                            <span className="text-[9px] font-sans font-extrabold text-red-400 shrink-0">{enemyActive.currentHealth * 10} HP</span>
                          </div>

                          {/* Image Box */}
                          <div className="my-1 h-28 rounded-md bg-[#04081c] border border-blue-950 overflow-hidden relative">
                            <img 
                              src={enemyActive.imageUrl || `https://dncards.com/images/cards/${enemyActive.id}.png`}
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = `https://dncards.com/assets/${enemyActive.id}.png`;
                              }}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover rounded-xs"
                              alt={enemyActive.name}
                            />
                            {enemyActive.isStunned && (
                              <div className="absolute inset-0 bg-blue-900/70 flex flex-col items-center justify-center font-mono text-[9px] uppercase tracking-wider font-black text-cyan-200 animate-pulse">
                                <span>❄ FROZEN STUN</span>
                              </div>
                            )}
                          </div>

                          {/* Stats and stats triggers */}
                          <div className="text-[7.5px] font-mono text-zinc-300">
                            <p className="truncate text-white font-sans font-black"><span className="text-yellow-400">⚡</span> {enemyActive.abilityName || 'Raw Combat Force'}</p>
                          </div>

                          <div className="border-t border-blue-950 pt-1 flex justify-between text-[8px] font-mono text-slate-400">
                            <span className="text-yellow-400 font-bold">ATK: {enemyActive.attack * 10}</span>
                            <span>COST: {enemyActive.cost}</span>
                          </div>
                        </div>

                      </div>
                    </motion.div>
                  ) : (
                    <div className="text-center p-8 border-2 border-dashed border-zinc-850 rounded text-zinc-500 text-[10.5px] font-mono italic">
                      Frontline unguarded. Direct strikes available!
                    </div>
                  )}
                </AnimatePresence>
              </div>              {/* PLAYER COMBAT ZONE ACTIVE SLOT */}
              <div className="flex flex-col items-center justify-center space-y-3 p-4 border border-blue-900/40 rounded-xl relative bg-[#090d24]/65 min-h-[240px] shadow-inner">
                <span className="text-[8px] font-mono text-blue-400 font-bold uppercase tracking-widest absolute top-2 animate-pulse">// YOUR ACTIVE DEFENDER UNIT</span>
                
                <AnimatePresence mode="wait">
                  {playerActive ? (
                    <motion.div 
                      key={playerActive.instanceId}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ 
                        scale: 1, 
                        opacity: 1,
                        x: isPlayerAttacking ? [0, 30, 0] : 0,
                        y: isPlayerAttacking ? [0, -40, 0] : 0
                      }}
                      className="relative pt-4"
                    >
                      {/* Floating Damage Text Popup overlay */}
                      {playerDamagePopup && (
                        <div className={`absolute -top-12 z-50 text-center w-full font-sans font-black text-3xl uppercase tracking-tighter drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)] animate-bounce ${
                          playerDamagePopup.type === 'heal' ? 'text-emerald-400' : 'text-red-500'
                        }`}>
                          {playerDamagePopup.type === 'heal' ? `+${playerDamagePopup.amount * 10}` : `-${playerDamagePopup.amount * 10}`}
                        </div>
                      )}
                      
                      {/* Custom Render Card */}
                      <div className={`pokecard-tilt holo-shine relative w-40 h-56 rounded-2xl flex flex-col p-1 bg-slate-705 ${
                        playerActive.rarity === 'Gold Legendary' ? 'bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-600 shadow-[0_0_15px_rgba(234,179,8,0.3)]' :
                        playerActive.rarity === 'Exotic' ? 'bg-gradient-to-r from-purple-600 via-fuchsia-400 to-indigo-700 shadow-[0_0_15px_rgba(168,85,247,0.3)]' :
                        playerActive.rarity === 'Limited Edition' ? 'bg-gradient-to-r from-rose-600 via-pink-400 to-red-700 shadow-[0_0_20px_rgba(244,63,94,0.3)] animate-pulse' :
                        'bg-slate-700 border border-slate-500'
                      }`}>
                        
                        {/* Core card body */}
                        <div className="flex-1 rounded-xl bg-gradient-to-b from-[#090d22] to-[#12183c] p-2 flex flex-col justify-between overflow-hidden relative">
                          <div className="flex justify-between items-center z-10 border-b border-blue-900/40 pb-0.5">
                            <h4 className="text-[10px] font-sans font-black text-white truncate max-w-[85px] leading-none">{playerActive.name}</h4>
                            <span className="text-[9px] font-sans font-extrabold text-emerald-400 shrink-0">{playerActive.currentHealth * 10} HP</span>
                          </div>

                          {/* Image Box */}
                          <div className="my-1 h-28 rounded-md bg-[#04081c] border border-blue-950 overflow-hidden relative">
                            <img 
                              src={playerActive.imageUrl || `https://dncards.com/images/cards/${playerActive.id}.png`}
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = `https://dncards.com/assets/${playerActive.id}.png`;
                              }}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover rounded-xs"
                              alt={playerActive.name}
                            />
                            {playerActive.isStunned && (
                              <div className="absolute inset-0 bg-blue-900/70 flex flex-col items-center justify-center font-mono text-[9px] uppercase tracking-wider font-black text-cyan-200 animate-pulse">
                                <span>❄ FROZEN STUN</span>
                              </div>
                            )}
                          </div>

                          {/* Stats and stats triggers */}
                          <div className="text-[7.5px] font-mono text-zinc-300">
                            <p className="truncate text-white font-sans font-black"><span className="text-yellow-400">⚡</span> {playerActive.abilityName || 'Heavy Mech Cannons'}</p>
                          </div>

                          <div className="border-t border-blue-950 pt-1 flex justify-between text-[8px] font-mono text-slate-400">
                            <span className="text-yellow-400 font-bold">ATK: {playerActive.attack * 10}</span>
                            <span>COST: {playerActive.cost}</span>
                          </div>

                          {/* Striked sticker */}
                          {playerActive.hasAttacked && (
                            <div className="absolute top-2 left-2 bg-yellow-500 text-black text-[6.5px] font-mono px-1 py-0.2 rounded font-black z-30 uppercase tracking-widest pointer-events-none">
                              Drained
                            </div>
                          )}
                        </div>

                      </div>
                    </motion.div>
                  ) : (
                    <div className="text-center p-8 border-2 border-dashed border-blue-900/20 rounded-2xl text-blue-400/50 text-xs font-mono leading-relaxed max-w-sm">
                      Front defense emptied! Select a card from your 6-card hand below and click to deploy to active guard.
                    </div>
                  )}
                </AnimatePresence>
              </div>

            </div>

            {/* ACTION TRIGGERS & ATTACK PANEL */}
            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="space-y-1 text-center sm:text-left">
                <span className="text-[9px] font-mono text-zinc-550 text-zinc-500 uppercase tracking-widest block">COMMENCE ACTION PROTOCOLS</span>
                <span className="text-xs font-mono font-bold">
                  {turn === 'player' ? (
                    <span className="text-orange-500 animate-pulse">// Your turn active. Choose your play.</span>
                  ) : (
                    <span className="text-red-500 animate-pulse">// Opponent turn in progress... Wait for response.</span>
                  )}
                </span>
              </div>
              
              <div className="flex gap-2 w-full sm:w-auto shrink-0">
                <button
                  type="button"
                  disabled={turn !== 'player' || !playerActive || playerActive.hasAttacked || playerActive.isStunned}
                  onClick={executeAttack}
                  className="flex-1 sm:flex-none px-6 py-3 bg-orange-600 hover:bg-orange-500 disabled:bg-zinc-900 disabled:text-zinc-500 disabled:border-zinc-800 disabled:cursor-not-allowed border border-orange-500 text-black font-extrabold text-[11px] font-mono tracking-wider uppercase flex items-center justify-center gap-2"
                >
                  <Sword className="w-4 h-4 text-black" />
                  STRIKE FRONTLINE
                </button>
                <button
                  type="button"
                  disabled={turn !== 'player'}
                  onClick={endTurn}
                  className="flex-1 sm:flex-none px-6 py-3 bg-zinc-900 hover:bg-zinc-800 disabled:text-zinc-650 border border-zinc-800 text-zinc-100 font-bold text-[11px] font-mono tracking-wider uppercase flex items-center justify-center gap-2"
                >
                  <span>END MY TURN</span>
                  <ArrowRight className="w-4 h-4 text-orange-500" />
                </button>
              </div>
            </div>

            {/* INTERACTIVE 6-CARD HAND LIST */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[10px] font-mono uppercase text-zinc-500 border-b border-zinc-900 pb-1.5">
                <span>Active 6-Card Hand // Select any card to deploy / execute</span>
                <span>Deck Remaining: {playerDeck.length} cards</span>
              </div>
              
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
                {playerHand.map((card) => {
                  const getMiniCategoryEmoji = (category: string) => {
                    switch (category) {
                      case 'Vehicles': return '⚙️';
                      case 'Infantry': return '✊';
                      case 'Aircraft': return '💨';
                      case 'Naval': return '💧';
                      case 'Mechs': return '🔮';
                      case 'Bosses': return '🔥';
                      case 'Support': return '🛡️';
                      default: return '⭐';
                    }
                  };

                  return (
                    <div 
                      key={card.instanceId}
                      onClick={() => deployPlayerCard(card.instanceId)}
                      className={`pokecard-tilt holo-shine relative cursor-pointer select-none transition-all duration-300 hover:-translate-y-3 shadow-lg rounded-2xl flex flex-col p-1 bg-slate-705 ${
                        card.rarity === 'Gold Legendary' ? 'bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-600 hover:shadow-[0_0_12px_rgba(234,179,8,0.25)]' :
                        card.rarity === 'Exotic' ? 'bg-gradient-to-r from-purple-600 via-fuchsia-400 to-indigo-700 hover:shadow-[0_0_12px_rgba(168,85,247,0.25)]' :
                        card.rarity === 'Limited Edition' ? 'bg-gradient-to-r from-rose-600 via-pink-400 to-red-700 hover:shadow-[0_0_15px_rgba(244,63,94,0.25)] animate-pulse' :
                        'bg-slate-700 border border-slate-500'
                      }`}
                      style={{ height: '175px' }}
                    >
                      {/* Inner Container */}
                      <div className="flex-1 rounded-xl bg-gradient-to-b from-[#090d22] to-[#12183c] p-1.5 flex flex-col justify-between overflow-hidden relative">
                        
                        <div className="flex justify-between items-center z-10 border-b border-blue-900/40 pb-0.5">
                          <h5 className="text-[8.5px] font-sans font-black text-white truncate max-w-[45px] leading-none">{card.name}</h5>
                          <span className="text-[7.5px] font-sans font-black text-emerald-400 shrink-0">{card.health * 10} HP</span>
                        </div>

                        {/* Image Frame */}
                        <div className="my-1 h-16 rounded bg-[#04081c] border border-blue-950 overflow-hidden relative">
                          <img 
                            src={card.imageUrl || `https://dncards.com/images/cards/${card.id}.png`}
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = `https://dncards.com/assets/${card.id}.png`;
                            }}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover rounded-xs"
                            alt={card.name}
                          />
                          <span className="absolute top-0.5 right-0.5 text-[6px] font-mono bg-slate-950/85 px-1 rounded-sm text-yellow-400">
                            {getMiniCategoryEmoji(card.category)}
                          </span>
                        </div>

                        {/* Skills / Atk info */}
                        <div className="text-[6.5px] font-sans font-bold text-slate-300 leading-tight">
                          <span className="text-yellow-400 font-black">⚡</span> {card.abilityName || 'Rapid Shells'}
                        </div>

                        <div className="border-t border-blue-950 pt-1 flex justify-between text-[7px] font-mono text-slate-400">
                          <span className="font-extrabold text-yellow-400">ATK: {card.attack * 10}</span>
                          <span>COST: {card.cost}</span>
                        </div>

                      </div>
                    </div>
                  );
                })}
                {playerHand.length === 0 && (
                  <div className="col-span-full py-8 text-center text-zinc-500 font-mono text-xs italic bg-zinc-950/30 border border-dashed border-zinc-800 rounded">
                    All hand cards deployed or expended! End turn to draw new cards.
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* COMPLETED COMBAT RESOLVED PORTION */}
      {battleState === 'resolved' && (
        <div className="bg-zinc-900 border border-zinc-850 p-8 rounded-xl text-center space-y-6 max-w-lg mx-auto">
          <div className="mx-auto w-16 h-16 bg-zinc-950 border border-zinc-800 flex items-center justify-center rounded-full">
            <Trophy className={`w-8 h-8 ${winner === 'player' ? 'text-amber-500' : 'text-zinc-650 text-zinc-500'}`} />
          </div>
          
          <div className="space-y-1.5">
            <h3 className="text-xl italic font-serif text-white">
              {winner === 'player' ? 'BATTLE VICTORY' : 'BATTLE DEFEAT'}
            </h3>
            <p className="text-xs text-zinc-400">
              {winner === 'player' 
                ? 'Your synced card collection successfully won the combat!'
                : 'Your opponent won the battle. Custom card combat logs are updated. Keep collecting!'
              }
            </p>
          </div>

          <div className="bg-zinc-950 p-4 border border-zinc-800 rounded text-left space-y-2.5 font-mono text-xs">
            <h4 className="text-[10.5px] text-zinc-400 uppercase tracking-widest font-bold">Battle Reward Summary</h4>
            <div className="flex justify-between">
              <span className="text-zinc-500">Battle Outcome:</span>
              <span className={winner === 'player' ? 'text-emerald-400 font-bold' : 'text-zinc-500 uppercase'}>
                {winner === 'player' ? 'Victory' : 'Defeat'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Opponent Player:</span>
              <span className="text-zinc-300">{opponentName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Total Rounds Fought:</span>
              <span className="text-zinc-300">{turnNumber} Turns</span>
            </div>
          </div>

          <button
            onClick={() => setBattleState('setup')}
            className="w-full py-3 bg-orange-600 hover:bg-orange-500 text-black font-extrabold text-[11px] font-mono tracking-wider uppercase transition-colors"
          >
            Acknowledge & Return to Lobby
          </button>
        </div>
      )}

    </div>
  );
}
