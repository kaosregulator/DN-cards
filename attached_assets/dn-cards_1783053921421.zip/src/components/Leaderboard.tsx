/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Trophy, Medal, ShieldAlert, BarChart, ExternalLink, Filter, Search, Award
} from 'lucide-react';
import { LeaderboardUser } from '../types';

interface LeaderboardProps {
  currentUsername: string;
  currentUserRank: string;
  currentUserRating: number;
  currentUserShards: number;
}

export default function Leaderboard({
  currentUsername,
  currentUserRank,
  currentUserRating,
  currentUserShards
}: LeaderboardProps) {
  // Pre-configured simulated leaderboards to represent actual top players in the global community
  const LEADERS: LeaderboardUser[] = [
    { rank: 1, name: 'Sovereign_Mech_88', title: 'Grandmaster Collector', rating: 2850, winRate: '74%', activeDeck: 'HMS Dreadnought Naval', shards: 4500 },
    { rank: 2, name: 'Col_Ironclad_X', title: 'Elite Collector', rating: 2610, winRate: '68%', activeDeck: 'M1A2 armored assault', shards: 3200 },
    { rank: 3, name: 'Ghost_Operative', title: 'Elite Collector', rating: 2540, winRate: '66%', activeDeck: 'Ghost Camo camo Division', shards: 2900 },
    { rank: 4, name: currentUsername, title: currentUserRank as any, rating: currentUserRating, winRate: '75%', activeDeck: 'Standard Strike Division', shards: currentUserShards }, // Current player mapped dynamically
    { rank: 5, name: 'Major_Striker_88', title: 'Veteran Collector', rating: 2350, winRate: '61%', activeDeck: 'Artillery Suppressor Blast', shards: 2100 },
    { rank: 6, name: 'Vanguard_Ace', title: 'Veteran Collector', rating: 2200, winRate: '59%', activeDeck: 'F-16 Sky Superiority', shards: 1100 },
    { rank: 7, name: 'Apex_Tactics_0', title: 'Adept Collector', rating: 1980, winRate: '57%', activeDeck: 'Plasma Titan Mech Core', shards: 1540 },
    { rank: 8, name: 'Rogue_Operator', title: 'Adept Collector', rating: 1750, winRate: '55%', activeDeck: 'BTR APC Infantry Drop', shards: 980 },
    { rank: 9, name: 'Frontline_Collector', title: 'Novice Collector', rating: 1350, winRate: '51%', activeDeck: 'Basic Humvee Swarm', shards: 450 }
  ];

  // Sort by rating points descending
  const sortedLeaders = [...LEADERS].sort((a, b) => b.rating - a.rating).map((user, idx) => ({
    ...user,
    rank: idx + 1
  }));

  const getRankIndicatorStyles = (pos: number) => {
    switch (pos) {
      case 1: return 'bg-amber-500/10 text-amber-500 border-amber-400 font-bold';
      case 2: return 'bg-zinc-300/10 text-zinc-300 border-zinc-400 font-bold';
      case 3: return 'bg-orange-750/10 text-amber-600 border-amber-700 font-bold';
      default: return 'bg-zinc-950 text-zinc-450 border-zinc-800';
    }
  };

  return (
    <div className="bg-zinc-90 bg-zinc-900/45 border border-zinc-850 rounded-xl p-5" id="leaderboards-main">
      <div className="flex flex-wrap items-center justify-between border-b border-zinc-850 pb-3 mb-4 gap-4">
        <div>
          <h2 className="text-sm font-mono font-bold text-zinc-300 tracking-wider flex items-center gap-2 uppercase">
            <Trophy className="w-4 h-4 text-amber-500" />
            DN GLOBAL COLLECTOR LADDER
          </h2>
          <p className="text-[10px] font-mono text-zinc-450 text-zinc-400 leading-none">Global ranking metrics of elite collection players.</p>
        </div>

        <div className="flex gap-2">
          <span className="text-[10px] font-mono text-zinc-550 text-zinc-500 bg-zinc-950 border border-zinc-900 px-2.5 py-1 rounded">
            UPDATED: HOURLY SYNC
          </span>
        </div>
      </div>

      {/* THREE LEADER MEDAL STANDS FOR VISUAL POLISH */}
      <div className="grid grid-cols-3 gap-4 mb-6 pt-2">
        {/* Silver Rank */}
        <div className="bg-zinc-950 border border-zinc-850 rounded-lg p-3 text-center space-y-2 relative order-1">
          <div className="absolute top-2 left-2 text-[10px] text-zinc-400 font-mono font-bold">#2</div>
          <Medal className="w-10 h-10 text-zinc-300 mx-auto" />
          <div>
            <h4 className="text-xs font-sans font-bold text-zinc-200 truncate">{sortedLeaders[1].name}</h4>
            <p className="text-[8px] font-mono text-zinc-500">{sortedLeaders[1].title}</p>
          </div>
          <p className="text-xs font-mono font-bold text-zinc-300">{sortedLeaders[1].rating} MMR</p>
        </div>

        {/* Gold Rank */}
        <div className="bg-amber-950/10 border border-amber-500/25 rounded-lg p-4 text-center space-y-2 relative -translate-y-1.5 order-2 shadow-lg">
          <div className="absolute top-2 left-3 text-[10px] text-amber-500 font-mono font-bold">#1</div>
          <Trophy className="w-12 h-12 text-amber-400 mx-auto animate-bounce duration-1000" />
          <div>
            <h4 className="text-sm font-sans font-extrabold text-white truncate">{sortedLeaders[0].name}</h4>
            <p className="text-[9px] font-mono text-amber-400 font-bold">{sortedLeaders[0].title}</p>
          </div>
          <p className="text-sm font-mono font-extrabold text-amber-400">{sortedLeaders[0].rating} MMR</p>
        </div>

        {/* Bronze Rank */}
        <div className="bg-zinc-950 border border-zinc-850 rounded-lg p-3 text-center space-y-2 relative order-3">
          <div className="absolute top-2 left-2 text-[10px] text-amber-600 font-mono font-bold">#3</div>
          <Medal className="w-10 h-10 text-amber-650 mx-auto" />
          <div>
            <h4 className="text-xs font-sans font-bold text-zinc-200 truncate">{sortedLeaders[2].name}</h4>
            <p className="text-[8px] font-mono text-zinc-550 text-zinc-500">{sortedLeaders[2].title}</p>
          </div>
          <p className="text-xs font-mono font-bold text-zinc-400">{sortedLeaders[2].rating} MMR</p>
        </div>
      </div>

      {/* FULL DETAILED LADDER TABLE LIST */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs font-mono text-zinc-300 border-collapse">
          <thead>
            <tr className="border-b border-zinc-850 text-zinc-500 uppercase tracking-wider text-[9px]">
              <th className="py-2.5 px-3">Position</th>
              <th className="py-2.5 px-3">Collector Name</th>
              <th className="py-2.5 px-3">Collector Tier</th>
              <th className="py-2.5 px-3 text-right">League MMR</th>
              <th className="py-2.5 px-3 text-right">Win Ratio</th>
              <th className="py-2.5 px-3">Primary Active Deck</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-y-1 divide-zinc-850/35">
            {sortedLeaders.map(user => {
              const isCurrentPlayer = user.name === 'christopherosorio7';
              return (
                <tr 
                  key={user.name}
                  className={`hover:bg-zinc-950 transition-colors ${isCurrentPlayer ? 'bg-amber-950/20 text-amber-300 border-l-2 border-l-amber-500 font-bold' : ''}`}
                >
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] border ${getRankIndicatorStyles(user.rank)}`}>
                      {user.rank}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-sans font-bold text-zinc-150">
                    <div className="flex items-center gap-1.5">
                      {user.name}
                      {isCurrentPlayer && (
                        <span className="text-[8px] font-mono text-stone-900 bg-amber-400 px-1 py-0.2 rounded font-extrabold uppercase">YOU</span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-3 text-[11px] text-zinc-400">{user.title}</td>
                  <td className="py-3 px-3 text-right font-bold text-zinc-200">{user.rating}</td>
                  <td className="py-3 px-3 text-right text-emerald-400">{user.winRate}</td>
                  <td className="py-3 px-3 text-zinc-400">{user.activeDeck}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
