/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Database, RefreshCw, ShoppingCart, Filter, Search, Award, 
  Layers, CreditCard, Flame, MessageSquare, HelpCircle, Share2, Zap, ExternalLink,
  Plane, Ship, Sparkles, User, Shield
} from 'lucide-react';
import { Card, Rarity, CardCategory, DiscordUser } from '../types';
import { CARD_DATABASE } from '../data/cards';

interface ShowcaseProps {
  ownedCardIds: string[];
  discordUser?: DiscordUser;
  onConnectDiscord?: (username: string) => void;
  onDisconnectDiscord?: () => void;
}

export default function Showcase({ 
  ownedCardIds,
  discordUser,
  onConnectDiscord,
  onDisconnectDiscord
}: ShowcaseProps) {
  // Sync State
  const [syncState, setSyncState] = useState<'idle' | 'linking' | 'syncing' | 'completed'>('idle');
  const [usernameInput, setUsernameInput] = useState(discordUser?.username || 'christopherosorio7');
  const [syncLogs, setSyncLogs] = useState<string[]>([]);

  const startSimulatedSync = () => {
    setSyncState('syncing');
    setSyncLogs([]);
    
    const logs = [
      'Establishing SECURE TLS tunnel with Gateway...',
      'Opening authenticated WebSocket frame stream...',
      `Searching Discord DB for user: @${usernameInput}...`,
      'Loading collection inventory schemas...',
      'Cryptographically verifying bot signatures...',
      'Collection imported successfully! Placed 52 collectibles in catalog.'
    ];

    let currentLogIndex = 0;
    
    const interval = setInterval(() => {
      if (currentLogIndex < logs.length) {
        setSyncLogs(prev => [...prev, logs[currentLogIndex]]);
        currentLogIndex++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          if (onConnectDiscord) {
            onConnectDiscord(usernameInput);
          }
          setSyncState('completed');
          setTimeout(() => {
            setSyncState('idle');
          }, 1200);
        }, 500);
      }
    }, 300);
  };

  // Filter variables
  const [activeTab, setActiveTab ] = useState<'Database' | 'TradeIndex'>('Database');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<CardCategory | 'All'>('All');
  const [rarityFilter, setRarityFilter] = useState<Rarity | 'All'>('All');
  const [sourceFilter, setSourceFilter] = useState<'All' | 'Owned' | 'Locked'>('All');
  const [setFilter, setSetFilter] = useState<'All' | 'Set 1' | 'Set 2'>('All');

  // Interactive detail overlay
  const [selectedInspectCard, setSelectedInspectCard] = useState<Card | null>(CARD_DATABASE[0]);

  const renderCategoryIcon = (category: CardCategory) => {
    switch (category) {
      case 'Infantry':
        return <User className="w-6 h-6 text-zinc-400" />;
      case 'Vehicles':
        return <CreditCard className="w-6 h-6 text-teal-400" />;
      case 'Aircraft':
        return <Plane className="w-6 h-6 text-cyan-400" />;
      case 'Naval':
        return <Ship className="w-6 h-6 text-blue-400" />;
      case 'Mechs':
        return <Zap className="w-6 h-6 text-yellow-400" />;
      case 'Bosses':
        return <Flame className="w-6 h-6 text-red-500" />;
      case 'Support':
        return <Shield className="w-6 h-6 text-emerald-400" />;
      case 'Event':
        return <Sparkles className="w-6 h-6 text-amber-500 font-bold" />;
      default:
        return <Layers className="w-6 h-6 text-zinc-400" />;
    }
  };

  const getFilteredCollection = () => {
    return CARD_DATABASE.filter(card => {
      const isOwned = card.isStarter || ownedCardIds.includes(card.id) || discordUser?.isSynced;
      
      const matchesSearch = card.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        (card.flavorText && card.flavorText.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesCategory = categoryFilter === 'All' || card.category === categoryFilter;
      const matchesRarity = rarityFilter === 'All' || card.rarity === rarityFilter;
      const matchesSet = setFilter === 'All' || card.set === setFilter;
      
      let matchesSource = true;
      if (sourceFilter === 'Owned') matchesSource = isOwned;
      if (sourceFilter === 'Locked') matchesSource = !isOwned;

      return matchesSearch && matchesCategory && matchesRarity && matchesSource && matchesSet;
    });
  };

  // Get pricing guideline matrix for trade index
  const getSimulatedValuation = (rarity: Rarity) => {
    switch (rarity) {
      case 'Common': return '15 - 25 DN Shards';
      case 'Uncommon': return '35 - 60 DN Shards';
      case 'Gold Legendary': return '150 - 250 DN Shards';
      case 'Exotic': return '400 - 650 DN Shards';
      case 'Limited Edition': return '1,200 - 1,800 DN Shards (High Volatility)';
    }
  };

  // Simulated trade listings from of active players via the Discord secure bot channels
  const SIMULATED_TRADES = [
    { id: 't_1', user: 'Vanguard_Ace', offer: 'M1A2 Abrams Tank (Gold Legendary)', request: 'HMS Dreadnought Legacy (LE)', notes: 'DM on Discord server for negotiations!', date: '6 mins ago' },
    { id: 't_2', user: 'SnipeMaster', offer: 'Ghost operative Sniper (Uncommon)', request: '80 DN Shards', notes: 'Will list on bot instantly. Direct buy.', date: '15 mins ago' },
    { id: 't_3', user: 'Colonel_Ironclad', offer: 'B-2 Spirit Stealth (Gold)', request: 'Mecha ODIN Mark IV (Exotic)', notes: 'Trading 2 lesser legendary gold cards for 1 exotic mech. DM!', date: '1 hour ago' },
    { id: 't_4', user: 'Rogue_Operator', offer: '2x Winter Airdrop Blizzard (Holiday Event)', request: '400 Shards package', notes: 'Limited event assist. High demand for current season ladder cold spells.', date: '3 hours ago' }
  ];

  const getRarityTagStyles = (rarity: Rarity) => {
    switch (rarity) {
      case 'Common': return 'bg-zinc-700 text-zinc-100 border-zinc-500';
      case 'Uncommon': return 'bg-emerald-800 text-emerald-100 border-emerald-600';
      case 'Gold Legendary': return 'bg-amber-600 text-amber-50 border-amber-300';
      case 'Exotic': return 'bg-purple-800 text-purple-100 border-purple-500';
      case 'Limited Edition': return 'bg-rose-750 text-red-50 border-rose-450 animate-pulse';
    }
  };

  return (
    <div className="space-y-6" id="showcase-view-main">
      {/* SECTION SELECTOR HEADER BARS */}
      <div className="flex flex-wrap items-center justify-between bg-zinc-90 w-full bg-zinc-900 border border-zinc-850 p-3 rounded-lg gap-3">
        <div className="flex items-center gap-2">
          <button 
            type="button"
            onClick={() => setActiveTab('Database')}
            className={`px-4 py-2 rounded text-xs font-mono font-bold tracking-wider transition-all flex items-center gap-1.5 ${activeTab === 'Database' ? 'bg-amber-500 text-black font-extrabold' : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-805 border-zinc-800'}`}
          >
            <Layers className="w-3.5 h-3.5" />
            CARDS CATALOGUE
          </button>
          
          <button 
            type="button"
            onClick={() => setActiveTab('TradeIndex')}
            className={`px-4 py-2 rounded text-xs font-mono font-bold tracking-wider transition-all flex items-center gap-1.5 ${activeTab === 'TradeIndex' ? 'bg-amber-500 text-black font-extrabold' : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-805 border-zinc-800'}`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            COMMUNITY TRADING MATRIX
          </button>
        </div>

        {discordUser?.isSynced ? (
          <div className="text-[10px] font-mono text-emerald-400 bg-emerald-950/25 border border-emerald-900/60 px-3 py-1.5 rounded flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>
            <span className="tracking-wide">BOT SYNC VERIFIED: @{discordUser.username.toUpperCase()} (100% LIVE INVENTORY)</span>
            {onDisconnectDiscord && (
              <button 
                type="button"
                onClick={onDisconnectDiscord}
                className="ml-2 underline text-red-405 text-red-400 hover:text-red-300 transition-colors uppercase cursor-pointer"
              >
                [Disconnect]
              </button>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setSyncState('linking')}
              className="text-[10px] font-mono font-bold tracking-wider bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-black px-3.5 py-1.5 rounded uppercase flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '4s' }} />
              Sync Discord Collection
            </button>
          </div>
        )}
      </div>

      {/* INTEGRATED DISCORD COLLECTION SYNC PANEL */}
      {syncState !== 'idle' && (
        <div className="bg-gradient-to-r from-[#1c130c] to-zinc-950 border border-orange-900/40 p-5 rounded-xl space-y-4 shadow-lg animate-fadeIn">
          <div className="flex items-center justify-between border-b border-zinc-850 pb-3">
            <div className="flex items-center gap-2">
              <RefreshCw className="w-5 h-5 text-orange-400 animate-spin" />
              <div>
                <h3 className="text-sm font-sans font-bold text-white tracking-wider uppercase">Discord Bot Sync Portal</h3>
                <p className="text-[10px] font-mono text-zinc-400">Secure card stock integration protocol</p>
              </div>
            </div>
            <button 
              type="button" 
              onClick={() => setSyncState('idle')}
              className="text-[10px] font-mono text-zinc-550 text-zinc-500 hover:text-white uppercase transition-colors"
            >
              [Cancel Sync]
            </button>
          </div>

          {syncState === 'linking' && (
            <div className="space-y-4">
              <p className="text-xs text-zinc-300 max-w-2xl leading-relaxed">
                Connect your Discord account to instantly synchronise cards captured or bought through the live Discord bot. Entering your account username creates a secure cryptographically verified handshake, keeping both your web client and bot databases perfectly aligned.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 max-w-md">
                <input 
                  type="text" 
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  placeholder="Discord Username (e.g. christopherosorio7)"
                  className="flex-1 bg-zinc-950 text-xs font-mono text-zinc-200 border border-zinc-800 px-3.5 py-2.5 rounded-lg outline-none focus:border-orange-500"
                />
                <button 
                  type="button"
                  onClick={startSimulatedSync}
                  className="bg-orange-600 hover:bg-orange-500 text-black text-xs font-mono font-bold tracking-wider uppercase px-5 py-2.5 rounded-lg transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2"
                >
                  Confirm Handshake
                </button>
              </div>
            </div>
          )}

          {syncState === 'syncing' && (
            <div className="space-y-3">
              <div className="bg-[#030712] rounded-lg p-4 font-mono text-xs border border-zinc-900 text-teal-400/90 space-y-1.5 h-[140px] overflow-y-auto">
                {syncLogs.map((log, idx) => (
                  <div key={idx} className="flex gap-2 animate-fadeIn">
                    <span className="text-zinc-600 select-none">&gt;</span>
                    <span>{log}</span>
                  </div>
                ))}
                <div className="w-2 h-4 bg-teal-400 animate-pulse inline-block" />
              </div>
              <div className="w-full bg-zinc-950 h-1.5 rounded-full overflow-hidden border border-zinc-900">
                <div className="bg-orange-500 h-full transition-all duration-300" style={{ width: `${(syncLogs.length / 6) * 100}%` }} />
              </div>
            </div>
          )}

          {syncState === 'completed' && (
            <div className="flex flex-col items-center justify-center py-6 space-y-2 bg-[#022c22]/10 border border-emerald-900/30 rounded-lg">
              <div className="w-10 h-10 bg-emerald-500/10 border border-emerald-500 rounded-full flex items-center justify-center font-bold text-emerald-400 text-xl animate-bounce">
                ✓
              </div>
              <h4 className="text-sm font-sans font-bold text-emerald-400 uppercase tracking-widest leading-none">Synchronization Secure</h4>
              <p className="text-[10px] font-mono text-zinc-455 text-zinc-400 select-none">Welcome back, @{usernameInput.toUpperCase()}! Full live card database unlocked.</p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'Database' ? (
        /* DATABASE SHOWCASE EXPLORATION GRID */
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

          {/* TWO COLUMNS: FILTERED BROWSABLE GRID COMPONENTS */}
          <div className="xl:col-span-2 bg-zinc-900/40 border border-zinc-850 rounded-xl p-4 lg:p-5 flex flex-col gap-4">
            
            {/* Filter toolbars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 bg-zinc-950/60 p-3 rounded border border-zinc-850">
              {/* Text search */}
              <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-2 rounded col-span-1">
                <Search className="w-3.5 h-3.5 text-zinc-500" />
                <input 
                  type="text"
                  placeholder="Query names, flavor..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-transparent text-[11px] text-zinc-150 outline-none p-1.5 w-full font-mono"
                />
              </div>

              {/* Set Selection */}
              <select
                value={setFilter}
                onChange={(e) => setSetFilter(e.target.value as any)}
                className="bg-zinc-900 border border-zinc-800 text-[10px] font-mono text-zinc-300 p-1.5 rounded outline-none cursor-pointer w-full"
              >
                <option value="All">All Card Sets</option>
                <option value="Set 1">Set 1: Vanguard Core</option>
                <option value="Set 2">Set 2: Nebula Rift</option>
              </select>

              {/* Category */}
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value as any)}
                className="bg-zinc-900 border border-zinc-800 text-[10px] font-mono text-zinc-300 p-1.5 rounded outline-none cursor-pointer"
              >
                <option value="All">All Categories</option>
                <option value="Infantry">Infantry</option>
                <option value="Vehicles">Vehicles</option>
                <option value="Aircraft">Aircraft</option>
                <option value="Naval">Naval</option>
                <option value="Support">Support</option>
                <option value="Mechs">Mechs</option>
                <option value="Bosses">Bosses</option>
                <option value="Event">Event Assist</option>
              </select>

              {/* Rarity */}
              <select
                value={rarityFilter}
                onChange={(e) => setRarityFilter(e.target.value as any)}
                className="bg-zinc-900 border border-zinc-800 text-[10px] font-mono text-zinc-300 p-1.5 rounded outline-none cursor-pointer"
              >
                <option value="All">All Rarities</option>
                <option value="Common">Common</option>
                <option value="Uncommon">Uncommon</option>
                <option value="Gold Legendary">Gold Legendary</option>
                <option value="Exotic">Exotic</option>
                <option value="Limited Edition">Limited Edition</option>
              </select>

              {/* Ownership Status filter */}
              <select
                value={sourceFilter}
                onChange={(e) => setSourceFilter(e.target.value as any)}
                className="bg-zinc-900 border border-zinc-800 text-[10px] font-mono text-zinc-300 p-1.5 rounded outline-none cursor-pointer"
              >
                <option value="All">All Collections (Discord)</option>
                <option value="Owned">Unlocked / Collected</option>
                <option value="Locked">Locked / Standard Pool</option>
              </select>
            </div>

            {/* Main scroll items */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 overflow-y-auto max-h-[580px] pr-1.5" id="showcase-card-grid">
              {getFilteredCollection().map(card => {
                const isOwned = card.isStarter || ownedCardIds.includes(card.id) || discordUser?.isSynced;
                const tagColor = getRarityTagStyles(card.rarity);
                const isInspected = selectedInspectCard?.id === card.id;

                // Category energy type definition for Pokemon TCG theme
                const getEnergyTypeBadge = (category: CardCategory) => {
                  switch (category) {
                    case 'Vehicles': return { label: '⚙️ METAL', color: 'from-gray-500 to-slate-700', badgeBg: 'bg-zinc-800 text-zinc-300' };
                    case 'Infantry': return { label: '✊ FIGHTING', color: 'from-amber-700 to-orange-850', badgeBg: 'bg-amber-950 text-amber-300' };
                    case 'Aircraft': return { label: '💨 WIND', color: 'from-sky-700 to-blue-500', badgeBg: 'bg-sky-950 text-sky-300' };
                    case 'Naval': return { label: '💧 WATER', color: 'from-blue-700 to-teal-500', badgeBg: 'bg-blue-950 text-blue-300' };
                    case 'Mechs': return { label: '🔮 PSYCHIC', color: 'from-purple-800 to-indigo-950', badgeBg: 'bg-purple-950 text-purple-300' };
                    case 'Bosses': return { label: '🔥 FIRE', color: 'from-red-700 to-orange-600', badgeBg: 'bg-red-950 text-red-300' };
                    case 'Support': return { label: '🛡️ SUPPORT', color: 'from-teal-800 to-emerald-950', badgeBg: 'bg-emerald-950 text-emerald-300' };
                    default: return { label: '⭐ NORMAL', color: 'from-zinc-700 to-slate-800', badgeBg: 'bg-zinc-900 text-zinc-300' };
                  }
                };

                const energy = getEnergyTypeBadge(card.category);
                const isHolo = ['Gold Legendary', 'Exotic', 'Limited Edition'].includes(card.rarity);

                return (
                  <div 
                    key={`showcase_${card.id}`}
                    onClick={() => setSelectedInspectCard(card)}
                    className={`pokecard-tilt holo-shine relative cursor-pointer select-none transition-all duration-300 ${
                      isInspected ? 'scale-103 z-10 ring-4 ring-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.6)]' : ''
                    } ${isOwned ? 'opacity-100' : 'opacity-40 hover:opacity-75'} rounded-2xl flex flex-col p-1.5 ${
                      card.rarity === 'Gold Legendary' ? 'bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-600 shadow-[0_0_10px_rgba(234,179,8,0.2)]' :
                      card.rarity === 'Exotic' ? 'bg-gradient-to-r from-purple-600 via-fuchsia-400 to-indigo-700 shadow-[0_0_10px_rgba(168,85,247,0.25)]' :
                      card.rarity === 'Limited Edition' ? 'bg-gradient-to-r from-rose-600 via-pink-400 to-red-700 shadow-[0_0_12px_rgba(244,63,94,0.3)] animate-pulse' :
                      'bg-slate-700 border-2 border-slate-600'
                    }`}
                    style={{ height: '320px' }}
                  >
                    {/* Real Physical Card Inner Body */}
                    <div className="flex-1 rounded-xl bg-gradient-to-b from-[#090d22] to-[#12183c] p-2 flex flex-col justify-between overflow-hidden relative">
                      
                      {/* Holographic sparkle texture for legendaries */}
                      {isHolo && (
                        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent opacity-40 pointer-events-none mix-blend-overlay"></div>
                      )}

                      {/* Header row: Category / Name & Cost HP */}
                      <div className="flex justify-between items-center z-10 border-b border-blue-900/40 pb-1">
                        <div className="flex flex-col">
                          <span className="text-[7px] font-mono tracking-widest text-slate-400 uppercase font-extrabold">{card.rarity}</span>
                          <h4 className="text-[12px] font-sans font-black text-white tracking-tight truncate max-w-[90px]">{card.name}</h4>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <span className="text-[7px] font-mono text-orange-400 font-black px-1 border border-orange-900/30 rounded bg-black/50 shrink-0">LV.{card.level ?? 1}</span>
                          {card.category !== 'Event' && (
                            <span className="text-[10px] font-sans font-extrabold text-blue-400 shrink-0">
                              {card.maxHealth * 10} HP
                            </span>
                          )}
                          <div className="w-5 h-5 rounded-full bg-yellow-500 text-black text-[9px] font-black flex items-center justify-center shadow-inner shrink-0" title={`Energy Cost: ${card.cost}`}>
                            {card.cost}
                          </div>
                        </div>
                      </div>

                      {/* Card Illustration Window */}
                      <div className="my-1.5 h-32 rounded-lg bg-[#04081c] border border-blue-950/80 overflow-hidden relative group">
                        {card.imageUrl ? (
                          <img 
                            src={card.imageUrl} 
                            alt={card.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover select-none pointer-events-none transition-transform duration-500 group-hover:scale-110"
                            loading="lazy"
                            onError={(e) => {
                              // If image fails, replace with vector background
                              e.currentTarget.style.display = 'none';
                            }}
                          />
                        ) : null}

                        {/* Cyber Reticle Retainer details if image is slow or missing */}
                        <div className="absolute inset-0 bg-transparent flex items-center justify-center pointer-events-none">
                          <div className="w-8 h-8 rounded-full border border-dashed border-blue-500/20 animate-spin"></div>
                          <div className="absolute text-[8px] font-mono text-blue-550/40 opacity-30 select-none uppercase tracking-widest bg-black/40 px-1.5 py-0.5 rounded">T-SYSTEM ACTIVE</div>
                        </div>

                        {/* Element overlay tag */}
                        <span className="absolute bottom-1 right-1 text-[7px] font-mono px-1.5 py-0.2 bg-black/70 border border-blue-900/60 text-blue-300 rounded uppercase font-bold select-none">
                          {card.set}
                        </span>
                      </div>

                      {/* Content Section: Energy Type and Attacks */}
                      <div className="flex-1 flex flex-col justify-between pt-1 text-slate-200">
                        {/* Energy category details */}
                        <div className="flex justify-between items-center bg-blue-950/40 px-2 py-0.5 rounded-md border border-blue-900/20 text-[8px] font-mono uppercase tracking-wide">
                          <span className="text-slate-400">Class Type</span>
                          <span className="text-yellow-400 font-extrabold">{energy.label}</span>
                        </div>

                        {/* Attacks row mappings matching Pokedex metrics */}
                        <div className="space-y-1 my-1">
                          {card.abilityName ? (
                            <div className="flex justify-between items-start text-left">
                              <div className="flex-1">
                                <h5 className="text-[10px] font-sans font-black text-white leading-none tracking-tight flex items-center gap-1">
                                  <span className="text-[7.5px]">⚡</span> {card.abilityName}
                                </h5>
                                <p className="text-[7.5px] font-mono text-zinc-400 line-clamp-2 leading-tight mt-0.5" title={card.abilityDescription}>
                                  {card.abilityDescription}
                                </p>
                              </div>
                              <span className="text-[10px] font-sans font-black text-yellow-400 ml-1">
                                {card.attack > 0 ? card.attack * 10 : ''}
                              </span>
                            </div>
                          ) : (
                            <div className="flex justify-between items-center">
                              <h5 className="text-[10px] font-sans font-black text-zinc-300 leading-none flex items-center gap-1">
                                <span>⚔️</span> Heavy Cannon Strike
                              </h5>
                              <span className="text-[10px] font-sans font-black text-yellow-400">
                                {card.attack * 10}
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Footer indicators inside card */}
                        <div className="border-t border-blue-950 pt-1 flex justify-between items-center text-[7px] font-mono text-slate-400">
                          <span>Set: {card.set === 'Set 1' ? 'VCR-01' : 'NEB-02'}</span>
                          {card.isStarter ? (
                            <span className="text-[6.5px] font-sans font-bold text-emerald-400 bg-emerald-950/60 px-1 py-0.2 rounded border border-emerald-900/30">STARTER</span>
                          ) : (
                            <span className="text-[6.5px] text-yellow-400 bg-yellow-950/60 px-1 py-0.2 rounded border border-yellow-900/30 font-bold uppercase">PRO CARD</span>
                          )}
                        </div>

                      </div>
                    </div>
                  </div>
                );
              })}

              {getFilteredCollection().length === 0 && (
                <div className="col-span-full py-16 text-center text-zinc-500 font-mono text-xs italic">
                  No cards matched your designated search query. Try modifying your filter attributes.
                </div>
              )}
            </div>
          </div>

          {/* ONE COLUMN: DEEP COMPONENT PHYSICAL INSPECTOR DISPLAY PANEL */}
          <div className="xl:col-span-1 bg-gradient-to-b from-[#090d24] to-[#040614] border border-blue-900/30 rounded-2xl p-5 flex flex-col justify-between min-h-[520px] shadow-2xl">
            {selectedInspectCard ? (
              <div className="space-y-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="border-b border-blue-900/30 pb-3 text-center">
                    <span className="text-[9px] font-mono uppercase tracking-widest text-blue-400 font-bold animate-pulse"> holographic inspect portal</span>
                    <h3 className="text-xl font-sans font-black text-slate-100 mt-1">{selectedInspectCard.name}</h3>
                    <div className="flex justify-center gap-2 mt-1.5 flex-wrap">
                      <span className={`text-[9px] font-mono px-2 py-0.5 border rounded ${getRarityTagStyles(selectedInspectCard.rarity)}`}>
                        {selectedInspectCard.rarity}
                      </span>
                      <span className="text-[9px] font-mono px-2 py-0.5 border border-blue-900/30 bg-[#0e172e] text-blue-300 rounded font-bold uppercase tracking-wider">
                        {selectedInspectCard.category}
                      </span>
                      <span className="text-[9px] font-mono px-2 py-0.5 border border-yellow-600/30 bg-yellow-950/20 text-yellow-400 rounded font-bold uppercase tracking-wider">
                        {selectedInspectCard.set}
                      </span>
                    </div>
                  </div>

                  {/* VISUAL HOLOGRAM CARD ENGINE DISCORD SIMULATION */}
                  <div className="mt-6 flex justify-center">
                    <div className={`pokecard-tilt holo-shine relative w-56 h-80 rounded-2xl flex flex-col p-2.5 transition-all duration-500 shadow-2xl select-none ${
                      selectedInspectCard.rarity === 'Gold Legendary' ? 'bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-600 shadow-[0_0_25px_rgba(234,179,8,0.4)]' :
                      selectedInspectCard.rarity === 'Exotic' ? 'bg-gradient-to-r from-purple-600 via-fuchsia-400 to-indigo-700 shadow-[0_0_25px_rgba(168,85,247,0.4)]' :
                      selectedInspectCard.rarity === 'Limited Edition' ? 'bg-gradient-to-r from-rose-600 via-pink-400 to-red-700 shadow-[0_0_30px_rgba(244,63,94,0.4)] animate-pulse' :
                      'bg-slate-700 border-2 border-slate-600'
                    }`}>
                      
                      {/* Detailed inspection body */}
                      <div className="flex-1 rounded-xl bg-gradient-to-b from-[#090d22] to-[#12183c] p-2.5 flex flex-col justify-between overflow-hidden relative">
                        {/* Header bar */}
                        <div className="flex justify-between items-center z-10 border-b border-blue-900/40 pb-1.5">
                          <div className="flex flex-col">
                            <span className="text-[8px] font-mono tracking-widest text-slate-400 uppercase font-black">{selectedInspectCard.rarity}</span>
                            <h4 className="text-sm font-sans font-black text-white leading-none tracking-tight">{selectedInspectCard.name}</h4>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-[8px] font-mono text-orange-400 font-extrabold px-1.5 py-0.5 rounded border border-orange-900/40 bg-black/60 shrink-0">LV.{selectedInspectCard.level ?? 1}</span>
                            {selectedInspectCard.category !== 'Event' && (
                              <span className="text-[11px] font-sans font-extrabold text-blue-400">
                                {selectedInspectCard.maxHealth * 10} HP
                              </span>
                            )}
                            <div className="w-6 h-6 rounded-full bg-yellow-500 text-black text-xs font-black flex items-center justify-center shadow-md">
                              {selectedInspectCard.cost}
                            </div>
                          </div>
                        </div>

                        {/* Centered Large artwork container */}
                        <div className="my-2 h-36 rounded-lg bg-[#04081c] border border-blue-950/80 overflow-hidden relative">
                          {selectedInspectCard.imageUrl ? (
                            <img 
                              src={selectedInspectCard.imageUrl} 
                              alt="Inspected card artwork" 
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.currentTarget.style.display = 'none';
                              }}
                            />
                          ) : null}

                          <div className="absolute inset-0 bg-transparent flex items-center justify-center pointer-events-none">
                            <div className="w-10 h-10 rounded-full border border-dashed border-blue-500/10 animate-spin"></div>
                          </div>
                        </div>

                        {/* Interactive dynamic element metrics */}
                        <div className="flex-1 flex flex-col justify-between pt-1">
                          <div className="flex justify-between items-center bg-blue-950/50 px-2 py-0.5 rounded-md border border-blue-900/30 text-[9px] font-mono">
                            <span className="text-slate-400">Type Category</span>
                            <span className="text-yellow-400 font-extrabold uppercase">{selectedInspectCard.category} UNIT</span>
                          </div>

                          <div className="space-y-1.5 my-1.5">
                            {selectedInspectCard.abilityName ? (
                              <div>
                                <h5 className="text-[11px] font-sans font-black text-white leading-none flex items-center gap-1">
                                  <span className="text-yellow-400">⚡</span> {selectedInspectCard.abilityName}
                                </h5>
                                <p className="text-[8px] font-mono text-zinc-400 leading-tight mt-1">
                                  {selectedInspectCard.abilityDescription}
                                </p>
                              </div>
                            ) : (
                              <div className="flex justify-between items-center text-xs">
                                <span className="font-sans font-black text-zinc-300">⚔️ Cannon Salvo</span>
                                <span className="font-sans font-black text-yellow-400">{selectedInspectCard.attack * 10}</span>
                              </div>
                            )}
                          </div>

                          {/* Footer parameters */}
                          <div className="border-t border-blue-950 pt-1 flex justify-between items-center text-[8px] font-mono text-slate-400">
                            <span>SERIAL #{selectedInspectCard.id}092</span>
                            <span className="text-blue-400 font-bold uppercase">{selectedInspectCard.set} EDITION</span>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>

                  {/* PROGRESS ROADMAP AND EVOLUTION PANEL CARD */}
                  <div className="bg-[#121635]/60 border border-blue-900/40 p-4 rounded-xl space-y-2.5 mt-4">
                    <div className="flex justify-between items-center text-[10px] font-mono">
                      <span className="text-zinc-400 font-bold uppercase">CARD PROGRESS LEVEL</span>
                      <span className="text-orange-400 font-extrabold font-mono">Lv. {selectedInspectCard.level ?? 1} / 10</span>
                    </div>
                    <div className="w-full bg-zinc-950 h-1.5 rounded-full overflow-hidden border border-zinc-900">
                      <div 
                        className="bg-orange-500 h-full transition-all duration-300" 
                        style={{ width: `${((selectedInspectCard.level ?? 1) / 10) * 100}%` }} 
                      />
                    </div>
                    <div className="flex justify-between items-center bg-[#07091e] px-2.5 py-1.5 rounded-lg border border-blue-950 text-[10px] font-mono">
                      <span className="text-zinc-400">Evolution Stage Form:</span>
                      <span className="font-extrabold text-indigo-400 uppercase flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                        Stage {selectedInspectCard.stage ?? 1} / 3
                      </span>
                    </div>
                  </div>

                  {/* FLAVOR TEXT AND ABILITY PANEL CARD */}
                  <div className="space-y-3 pt-4">
                    <div className="bg-[#0b102b] border border-blue-900/30 p-3.5 rounded-xl text-center space-y-1 relative overflow-hidden">
                      <div className="absolute top-1 right-2 uppercase font-mono text-[8px] text-blue-500 font-bold">Flavor Archives</div>
                      <p className="text-xs font-mono text-slate-350 leading-relaxed italic">
                        "{selectedInspectCard.flavorText || 'No secondary intelligence parameters recorded.'}"
                      </p>
                    </div>

                    <div className="bg-[#0b0c16] border border-blue-900/40 p-4 rounded-xl space-y-2">
                      <div className="flex justify-between items-center border-b border-blue-950 pb-1.5">
                        <span className="text-[10px] font-mono text-yellow-400 font-bold uppercase tracking-wider">Digital Skill triggers</span>
                        <span className="text-[10px] font-mono text-slate-400">Requires {selectedInspectCard.cost} ENERGY</span>
                      </div>
                      
                      {selectedInspectCard.abilityName ? (
                        <>
                          <h4 className="text-xs font-sans font-extrabold text-blue-400">{selectedInspectCard.abilityName}</h4>
                          <p className="text-[11px] font-mono text-zinc-300 leading-relaxed">
                            {selectedInspectCard.abilityDescription}
                          </p>
                        </>
                      ) : (
                        <p className="text-xs font-mono text-zinc-500 italic">No complex mechanical parameters documented. Relies on heavy direct firepower.</p>
                      )}
                    </div>
                  </div>

                  {/* COMBAT ATTACK OR DEFENSE HIGHLIGHTS */}
                  {selectedInspectCard.category !== 'Event' && (
                    <div className="grid grid-cols-2 gap-3 pt-4">
                      <div className="bg-slate-900/80 border border-blue-950/60 p-3 rounded-lg text-center">
                        <p className="text-[9px] font-mono text-slate-400 font-bold uppercase tracking-wide">ATTACK FORCE</p>
                        <h4 className="text-2xl font-sans font-black text-yellow-400">{selectedInspectCard.attack * 10}</h4>
                      </div>
                      <div className="bg-slate-900/80 border border-blue-950/60 p-3 rounded-lg text-center">
                        <p className="text-[9px] font-mono text-slate-400 font-bold uppercase tracking-wide">DEFENSE POWER</p>
                        <h4 className="text-2xl font-sans font-black text-emerald-400">{selectedInspectCard.maxHealth * 10}</h4>
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-blue-950/40 flex gap-2">
                  <a
                    href="https://discord.gg/dn-cards-bot"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 bg-blue-950/50 hover:bg-blue-900 text-blue-300 font-mono text-xs rounded-xl border border-blue-800/40 text-center flex items-center justify-center gap-1.5 transition-colors font-bold"
                  >
                    <MessageSquare className="w-4 h-4 text-blue-400" />
                    DISCORD TRADE CHANNELS
                  </a>
                </div>
              </div>
            ) : (
              <p className="text-xs font-mono text-blue-400 italic text-center my-auto">Select any collectible card to load spec details.</p>
            )}
          </div>

        </div>
      ) : (
        /* TRADING REGISTER MARKET INDEX */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* LEFT 2 COLUMNS: DISCORD COMMUNTIY LISTINGS */}
          <div className="lg:col-span-2 bg-zinc-900/40 border border-zinc-850 rounded-xl p-4 lg:p-5 flex flex-col gap-4">
            <div>
              <h3 className="text-xs font-mono font-bold text-zinc-300 tracking-wider uppercase mb-1">LIVE BOT AUCTION CHANNELS</h3>
              <p className="text-[10px] font-mono text-zinc-500">Simulating real trade offer notices scraped from Discord server channels.</p>
            </div>

            <div className="space-y-3">
              {SIMULATED_TRADES.map(trade => (
                <div 
                  key={trade.id}
                  className="bg-zinc-955 bg-zinc-950/90 border border-zinc-850 p-4 rounded-lg flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center hover:border-zinc-700 transition-all"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-sans font-bold text-zinc-300">Trader: {trade.user}</span>
                      <span className="text-[8px] font-mono text-zinc-550 text-[10px] text-zinc-500">{trade.date}</span>
                    </div>

                    <div className="text-xs">
                      <span className="text-zinc-400 font-mono">OFFERS:</span> <span className="text-zinc-200 font-sans font-semibold">{trade.offer}</span>
                    </div>
                    <div className="text-xs">
                      <span className="text-zinc-400 font-mono">REQUESTS:</span> <span className="text-amber-400 font-sans font-semibold">{trade.request}</span>
                    </div>

                    <p className="text-[10.5px] font-mono text-zinc-500 italic mt-1 font-mono">"{trade.notes}"</p>
                  </div>

                  <a 
                    href="https://discord.gg/dn-cards-bot"
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-850 text-[11px] font-mono text-zinc-300 rounded border border-zinc-800 flex items-center gap-1 flex-shrink-0 transition-colors"
                  >
                    RESOLVE VIA BOT
                    <ExternalLink className="w-3 h-3 text-zinc-400" />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* ONE COLUMN: VALUATION INDEX GUIDELINE */}
          <div className="lg:col-span-1 bg-zinc-90 w-full bg-zinc-900 border border-zinc-850 rounded-xl p-5 flex flex-col justify-between">
            <div className="space-y-4">
              <div>
                <h3 className="text-xs font-mono font-bold text-zinc-300 tracking-wider uppercase mb-1">MARKET PRICE CALCULATOR</h3>
                <p className="text-[10px] font-mono text-zinc-500">Estimates standard exchange prices of Discord collectible cards in Shard indices.</p>
              </div>

              <div className="space-y-2 pt-2">
                {(['Common', 'Uncommon', 'Gold Legendary', 'Exotic', 'Limited Edition'] as Rarity[]).map(rarity => (
                  <div 
                    key={rarity}
                    className="bg-zinc-950 p-3 rounded border border-zinc-855 border-zinc-850 flex items-center justify-between text-xs"
                  >
                    <span className={`text-[9px] font-mono px-2 py-0.5 border rounded ${getRarityTagStyles(rarity)}`}>
                      {rarity}
                    </span>
                    <span className="text-zinc-200 font-mono">{getSimulatedValuation(rarity)}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 bg-zinc-955 bg-zinc-950 border border-zinc-850 rounded text-center text-[10px] font-mono text-zinc-550 text-zinc-500 leading-relaxed mt-6">
              <HelpCircle className="w-4 h-4 text-zinc-400 mx-auto mb-1.5" />
              This trading indices metric acts purely as an analytical showcase platform. All trade executions, bot auctions, and transfers must be finalized via the Discord bot interface rules.
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
