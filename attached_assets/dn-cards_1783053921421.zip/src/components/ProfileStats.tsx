/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Award, Target, BarChart2, Shield, Calendar, MapPin, 
  Database, RefreshCw, Star, Info, CheckCircle2, Circle
} from 'lucide-react';
import { GameRank, MatchHistoryEntry, Achievement, DiscordUser, Card, Rarity } from '../types';
import { CARD_DATABASE } from '../data/cards';
import { useState } from 'react';

interface ProfileStatsProps {
  dnShards: number;
  level: number;
  xp: number;
  xpToNextLevel: number;
  rank: GameRank;
  rankXp: number;
  matchHistory: MatchHistoryEntry[];
  achievements: Achievement[];
  claimAchievementReward: (achievementId: string) => void;
  discordUser: DiscordUser | null;
  onConnectDiscord: (username: string) => void;
  onDisconnectDiscord: () => void;
  ownedCardIds?: string[];
}

export default function ProfileStats({
  dnShards,
  level,
  xp,
  xpToNextLevel,
  rank,
  rankXp,
  matchHistory,
  achievements,
  claimAchievementReward,
  discordUser,
  onConnectDiscord,
  onDisconnectDiscord,
  ownedCardIds = []
}: ProfileStatsProps) {
  const [inputUsername, setInputUsername] = useState('');
  const [isLinking, setIsLinking] = useState(false);
  const [showSetupHelp, setShowSetupHelp] = useState(false);
  const [selectedRarityTab, setSelectedRarityTab] = useState<Rarity>('Limited Edition');

  const handleDiscordOAuth = async () => {
    try {
      const response = await fetch(`/api/auth/discord/url?origin=${encodeURIComponent(window.location.origin)}`);
      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || errJson.message || 'Failed to construct Discord OAuth URL.');
      }
      const { url } = await response.json();
      
      const authWindow = window.open(
        url,
        'discord_oauth',
        'width=580,height=720'
      );
      if (!authWindow) {
        alert('Popup Blocked! Please white-list or allow browser popups for this viewport to authenticate.');
      }
    } catch (err: any) {
      console.error(err);
      alert(`OAuth Error Details:\n${err.message || err}\n\nTo use Live Discord Sign-In, ensure you have declared the Client ID under your Environment Secrets in AI Studio. You can also use the "Simulated Sandbox Sign-In" option to test the UI instantly!`);
    }
  };
  const [hoveredCard, setHoveredCard] = useState<Card | null>(() => {
    const leCards = CARD_DATABASE.filter(c => c.rarity === 'Limited Edition');
    return leCards.length > 0 ? leCards[0] : CARD_DATABASE[0];
  });

  // Calculate generic statistics
  const totalMatches = matchHistory.length;
  const victories = matchHistory.filter(m => m.result === 'Victory').length;
  const defeats = totalMatches - victories;
  const winPercentage = totalMatches > 0 ? Math.round((victories / totalMatches) * 100) : 0;

  // XP Progress percents
  const levelProgressPercent = Math.min(100, Math.round((xp / xpToNextLevel) * 100));

  // Determine current Rank Shield image/style coloring
  const getRankBadgeStyles = (cRank: GameRank) => {
    switch (cRank) {
      case 'Recruit': return 'border-zinc-700 bg-zinc-800/10 text-zinc-400';
      case 'Corporal': return 'border-emerald-700 bg-emerald-900/10 text-emerald-400';
      case 'Sergeant': return 'border-cyan-700 bg-cyan-900/10 text-cyan-450';
      case 'Lieutenant': return 'border-indigo-700 bg-indigo-900/10 text-indigo-400';
      case 'Captain': return 'border-blue-700 bg-blue-900/10 text-blue-400';
      case 'Major': return 'border-purple-700 bg-purple-900/10 text-purple-400';
      case 'Colonel': return 'border-rose-750 bg-red-950/20 text-rose-450 text-rose-400';
      case 'General of the Army': return 'border-amber-500 bg-amber-950/30 text-amber-500 animate-pulse font-bold';
    }
  };

  const handleLinkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUsername.trim()) return;
    onConnectDiscord(inputUsername.trim());
    setIsLinking(false);
  };

  return (
    <div className="space-y-6" id="profile-stats-main">
      {/* OVERALL COLLECTOR PROFILE SUMMARY CONTAINER */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* PROFILE CARD */}
        <div className="lg:col-span-1 bg-gradient-to-b from-zinc-900 to-zinc-950 border border-zinc-850 rounded-xl p-5 relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
          
          <div className="space-y-4">
            <span className="text-[9px] font-mono tracking-widest text-zinc-500 bg-zinc-950 border border-zinc-900 px-2.5 py-1 rounded">
              CARD COLLECTOR PROFILE
            </span>

            {discordUser?.isSynced ? (
              <div className="space-y-3">
                <div className="flex items-center gap-4 pt-2">
                  <div className="w-16 h-16 rounded-full bg-orange-600/10 border border-orange-500/30 flex items-center justify-center font-serif font-bold text-orange-500 italic text-xl">
                    {discordUser.username.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-xs font-mono text-zinc-500">DISCORD CONNECTED</p>
                    <h3 className="text-lg font-sans font-extrabold text-zinc-100 flex items-center gap-1.5">
                      {discordUser.username}
                    </h3>
                    <p className="text-[10px] font-mono text-emerald-450 text-emerald-400">// INTEGRATED DISCORD COLLECTION</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onDisconnectDiscord}
                  className="text-[9px] font-mono uppercase bg-zinc-950 border border-zinc-900 px-2 py-1 text-zinc-500 hover:text-red-400 hover:border-red-900/30 transition-all cursor-pointer w-full"
                >
                  Disconnect Discord Account
                </button>
              </div>
            ) : (
              <div className="space-y-4 p-4 bg-zinc-950 border border-zinc-900 rounded-lg">
                <div className="space-y-1">
                  <p className="text-[9px] font-mono text-orange-400 font-bold uppercase select-none">// OFFLINE PLAYER</p>
                  <p className="text-xs text-zinc-400 leading-tight">Currently loaded in a local offline sandbox session. Link your Discord handler to synchronize your DN Cards collection database.</p>
                </div>
                
                <div className="space-y-2 pt-2">
                  {/* Option 1: Live OAuth Trigger */}
                  <button
                    type="button"
                    onClick={handleDiscordOAuth}
                    className="w-full flex items-center justify-center gap-2 py-2.5 text-xs font-mono font-bold tracking-wider bg-[#5865F2] hover:bg-[#4752C4] text-white uppercase transition-all duration-300 rounded inline-flex cursor-pointer"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.873-.894.077.077 0 0 1-.008-.128c.126-.093.252-.19.372-.287a.075.075 0 0 1 .077-.011c3.92 1.793 8.18 1.793 12.061 0a.073.073 0 0 1 .078.009c.12.099.246.195.373.289a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.156-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.156 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.156-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.156 2.418z"/>
                    </svg>
                    Sign In with Discord
                  </button>

                  <div className="flex items-center gap-2 text-[9px] font-mono text-zinc-500 my-1.5 justify-center">
                    <span className="h-[1px] bg-zinc-900 flex-1"></span>
                    <span>OR USE SIMULATED SAFE BYPASS</span>
                    <span className="h-[1px] bg-zinc-900 flex-1"></span>
                  </div>

                  {/* Option 2: Mock/Simulation Trigger */}
                  {isLinking ? (
                    <form onSubmit={handleLinkSubmit} className="space-y-2">
                      <input 
                        type="text"
                        required
                        placeholder="Discord Handle (e.g. christopherosorio7)"
                        value={inputUsername}
                        onChange={(e) => setInputUsername(e.target.value)}
                        className="w-full text-xs font-mono bg-zinc-900 border border-zinc-800 px-2 py-1.5 text-zinc-150 outline-none focus:border-orange-500 rounded"
                      />
                      <div className="flex gap-2">
                        <button 
                          type="submit"
                          className="flex-1 text-[9px] font-mono uppercase bg-orange-600 text-black font-bold py-1.5 cursor-pointer rounded"
                        >
                          Confirm Handle
                        </button>
                        <button 
                          type="button"
                          onClick={() => setIsLinking(false)}
                          className="text-[9px] font-mono uppercase bg-zinc-800 text-zinc-300 px-2 cursor-pointer rounded"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setIsLinking(true)}
                      className="w-full text-center py-2 text-xs font-mono font-bold tracking-wider bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white uppercase transition-all rounded cursor-pointer"
                    >
                      🎮 Simulated Sandbox Sync
                    </button>
                  )}

                  {/* Option 3: Integration configuration instructions toggle */}
                  <div className="pt-2 border-t border-zinc-900/60 mt-2">
                    <button
                      type="button"
                      onClick={() => setShowSetupHelp(!showSetupHelp)}
                      className="w-full text-left text-[9px] font-mono text-zinc-500 hover:text-orange-400 uppercase flex items-center justify-between cursor-pointer"
                    >
                      <span>{showSetupHelp ? '▼ Hide Setup Config steps' : '► Run Discord OAuth Setup?'}</span>
                      <Info className="w-3.5 h-3.5 text-zinc-650" />
                    </button>

                    {showSetupHelp && (
                      <div className="mt-2 text-[9.5px] text-zinc-400 font-sans leading-relaxed space-y-1.5 bg-zinc-950 p-2.5 border border-zinc-900 rounded select-text">
                        <p><b className="text-zinc-200">OAuth Connection setup:</b></p>
                        <ol className="list-decimal pl-3.5 space-y-1">
                          <li>Go to the <a href="https://discord.com/developers/applications" target="_blank" rel="noopener noreferrer" className="text-orange-400 hover:underline">Discord Developer Portal</a> and create an App.</li>
                          <li>In the <b className="text-zinc-200">OAuth2</b> tab, click <b className="text-zinc-200">Add Redirect</b> and input:
                            <code className="block text-zinc-100 font-mono text-[8.5px] bg-zinc-900 px-2 py-1 rounded my-1 border border-zinc-800">{window.location.origin}/auth/callback</code>
                          </li>
                          <li>Copy your <b className="text-zinc-200">Client ID</b> and <b className="text-zinc-200">Client Secret</b>.</li>
                          <li>Open the <b className="text-zinc-200">Settings</b> menu in AI Studio (Secrets panel).</li>
                          <li>Add <code className="text-zinc-150 bg-zinc-900 px-1">DISCORD_CLIENT_ID</code> and <code className="text-zinc-150 bg-zinc-900 px-1">DISCORD_CLIENT_SECRET</code>.</li>
                        </ol>
                      </div>
                    )}
                  </div>

                </div>
              </div>
            )}

            {/* LEVEL METER PROGRESS */}
            <div className="space-y-1.5 border-t border-zinc-850 pt-4">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-zinc-400">Level Progression</span>
                <span className="text-zinc-200">LVL {level} ({levelProgressPercent}%)</span>
              </div>
              <div className="w-full bg-zinc-950 h-2 rounded-full overflow-hidden border border-zinc-900">
                <div 
                  className="bg-amber-500 h-full transition-all duration-550"
                  style={{ width: `${levelProgressPercent}%` }}
                />
              </div>
              <p className="text-[9px] font-mono text-zinc-550 text-zinc-500 text-right">{xp} / {xpToNextLevel} XP SECURE</p>
            </div>

            {/* CURRENT COMPETITIVE LEAGUE BRANDING */}
            <div className={`p-4 rounded-lg border border-dashed flex items-center justify-between mt-2 ${getRankBadgeStyles(rank)}`}>
              <div className="space-y-0.5">
                <p className="text-[8px] font-mono uppercase text-zinc-400">SEASON V LEADERBOARD RANK</p>
                <h4 className="text-sm font-sans font-extrabold">{rank.toUpperCase()}</h4>
                <p className="text-[10px] font-mono">Rating Metric: {rankXp} MMR</p>
              </div>
              <Award className="w-10 h-10 flex-shrink-0 opacity-80" />
            </div>
          </div>

          <div className="text-[10px] text-zinc-550 text-zinc-500 font-mono mt-6 pt-2 border-t border-zinc-850/40">
            METRICS SYNCHRONIZED VIA SECURE COLLECTION DATABASE
          </div>
        </div>

        {/* COLLECTOR PERFORMANCE SUMMARY */}
        <div className="lg:col-span-2 bg-zinc-90 w-full bg-zinc-900/40 border border-zinc-850 rounded-xl p-5">
          <span className="text-[9px] font-mono tracking-widest text-[#7C7C7C] block mb-4 uppercase">BATTLE MODE PERFORMANCE STATISTICS</span>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            
            <div className="bg-zinc-950 p-4 border border-zinc-850 rounded text-center space-y-1">
              <Target className="w-5 h-5 text-amber-500 mx-auto" />
              <p className="text-[9px] font-mono text-zinc-500">TOTAL BATTLES PLAYED</p>
              <h4 className="text-2xl font-bold font-sans text-zinc-200">{totalMatches}</h4>
            </div>

            <div className="bg-zinc-950 p-4 border border-zinc-850 rounded text-center space-y-1">
              <Award className="w-5 h-5 text-emerald-400 mx-auto" />
              <p className="text-[9px] font-mono text-zinc-500">BATTLES WON</p>
              <h4 className="text-2xl font-bold font-sans text-emerald-400">{victories}</h4>
            </div>

            <div className="bg-zinc-950 p-4 border border-zinc-850 rounded text-center space-y-1">
              <Shield className="w-5 h-5 text-red-500 mx-auto" />
              <p className="text-[9px] font-mono text-zinc-500">BATTLES LOST</p>
              <h4 className="text-2xl font-bold font-sans text-red-400">{defeats}</h4>
            </div>

            <div className="bg-zinc-950 p-4 border border-zinc-850 rounded text-center space-y-1">
              <BarChart2 className="w-5 h-5 text-blue-400 mx-auto" />
              <p className="text-[9px] font-mono text-zinc-500">AVERAGE WIN RATE</p>
              <h4 className="text-2xl font-bold font-sans text-zinc-200">{winPercentage}%</h4>
            </div>

          </div>

          {/* HISTORICAL MATCH EVENTS LOG */}
          <div className="mt-6">
            <h4 className="text-xs font-mono font-bold text-zinc-300 tracking-wider uppercase mb-2">BATTLE HISTORY LOGS</h4>
            
            <div className="space-y-1.5 max-h-[190px] overflow-y-auto pr-1">
              {matchHistory.length === 0 ? (
                <div className="text-center py-8 border border-dashed border-zinc-850 rounded text-xs font-mono text-zinc-550 text-zinc-500 italic">
                  Battle logs currently vacant. Duel in the Battle Arena to record combat history.
                </div>
              ) : (
                matchHistory.map((match, idx) => (
                  <div 
                    key={match.id}
                    className="bg-zinc-950/80 hover:bg-zinc-950 p-3 rounded border border-zinc-850 flex items-center justify-between text-xs text-zinc-300 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-bold leading-none ${match.result === 'Victory' ? 'bg-emerald-950 text-emerald-450 border border-emerald-900' : 'bg-red-950 text-red-450 border border-red-900'}`}>
                        {match.result}
                      </span>
                      <div>
                        <p className="font-sans font-bold text-zinc-150">vs Opponent {match.opponentName}</p>
                        <p className="text-[8px] font-mono text-zinc-550 text-zinc-500 uppercase">{match.mode} Arena • {match.date}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-right font-mono text-[11px]">
                      <div>
                        <p className="text-amber-400">+{match.shardsEarned} Shards</p>
                        <p className="text-zinc-500">+{match.xpEarned} XP</p>
                      </div>
                      <span className="text-[9px] text-zinc-650 text-zinc-600">({match.turnsPlayed} turns)</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

      </div>

      {/* EXQUISITE DISCORD SYNCED INVENTORY MODULE */}
      <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-xl space-y-4" id="discord-inventory-module">
        <div className="border-b border-zinc-850 pb-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-sans font-bold text-zinc-100 tracking-wider uppercase flex items-center gap-2">
              <Database className="w-4 h-4 text-amber-500" />
              DISCORD BOT INTEGRATED CARDS
            </h3>
            <p className="text-[10px] font-mono text-zinc-400">
              {discordUser?.isSynced 
                ? `Sync verified for active cards database: ${discordUser.username}. Displaying full live collection.`
                : 'Showing sandbox baseline inventory. Sync your Discord account credentials to map your true live capture.'
              }
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 border rounded ${
              discordUser?.isSynced 
                ? 'bg-emerald-950/40 text-emerald-400 border-emerald-900/60 animate-pulse' 
                : 'bg-zinc-950 text-zinc-500 border-zinc-850'
            }`}>
              {discordUser?.isSynced ? '● BOT SYNC ACTIVE' : '○ SANDBOX SIMULATOR'}
            </span>
          </div>
        </div>

        {/* Sync call to action if offline */}
        {!discordUser?.isSynced && (
          <div className="bg-amber-950/20 border border-amber-900/30 p-3.5 rounded-lg flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-zinc-300">
            <div className="space-y-0.5">
              <p className="font-bold text-amber-400 font-sans">Have custom cards captured in the Discord bot?</p>
              <p className="text-[10.5px] font-mono text-zinc-400">Syncing your credentials securely maps your exact collection and makes them viewable on-screen.</p>
            </div>
            <button 
              type="button"
              onClick={() => setIsLinking(true)}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-[10px] font-mono rounded tracking-wider uppercase transition-colors shrink-0 cursor-pointer"
            >
              Sync Discord Bot Now
            </button>
          </div>
        )}

        {/* Rarity Navigation Tabs */}
        <div className="flex flex-wrap gap-1.5 border-b border-zinc-950 pb-3">
          {(['Common', 'Uncommon', 'Gold Legendary', 'Exotic', 'Limited Edition'] as Rarity[]).map((rarity) => {
            const isActive = selectedRarityTab === rarity;
            const totalRarityCards = CARD_DATABASE.filter(c => c.rarity === rarity);
            const ownedRarityCards = totalRarityCards.filter(c => c.isStarter || ownedCardIds.includes(c.id) || discordUser?.isSynced);
            
            return (
              <button
                key={rarity}
                type="button"
                onClick={() => {
                  setSelectedRarityTab(rarity);
                  const rarityFiltered = CARD_DATABASE.filter(c => c.rarity === rarity);
                  if (rarityFiltered.length > 0) {
                    setHoveredCard(rarityFiltered[0]);
                  }
                }}
                className={`px-3 py-1.5 rounded text-[10px] font-mono font-bold uppercase transition-all border flex items-center gap-1.5 cursor-pointer ${
                  isActive 
                    ? 'bg-amber-500 text-black border-amber-400 font-extrabold' 
                    : 'bg-zinc-950 text-zinc-400 border-zinc-850 hover:text-white hover:border-zinc-750'
                }`}
              >
                <span>{rarity.toUpperCase()}</span>
                <span className={`text-[9px] px-1.5 py-0.2 rounded font-sans font-extrabold ${
                  isActive ? 'bg-black/20 text-black' : 'bg-zinc-900 text-zinc-450'
                }`}>
                  {ownedRarityCards.length}/{totalRarityCards.length}
                </span>
              </button>
            );
          })}
        </div>

        {/* Tab content grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Card list columns */}
          <div className="lg:col-span-2 space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
            {CARD_DATABASE.filter(c => c.rarity === selectedRarityTab).map(card => {
              const isOwned = card.isStarter || ownedCardIds.includes(card.id) || discordUser?.isSynced;
              const isHovered = hoveredCard?.id === card.id;

              return (
                <div 
                  key={card.id}
                  onMouseEnter={() => setHoveredCard(card)}
                  onClick={() => setHoveredCard(card)}
                  className={`p-3.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between gap-4 ${
                    isOwned 
                      ? isHovered 
                        ? 'bg-zinc-950 border-amber-500/80 shadow-lg shadow-amber-950/5' 
                        : 'bg-zinc-950/80 border-zinc-850 hover:border-zinc-750'
                      : 'bg-zinc-950/40 border-zinc-900 opacity-40 hover:opacity-50'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[8px] font-mono px-1.5 py-0.2 rounded border ${
                        card.rarity === 'Common' ? 'bg-zinc-800 text-zinc-300 border-zinc-700' : 
                        card.rarity === 'Uncommon' ? 'bg-emerald-950 text-emerald-400 border-emerald-900' : 
                        card.rarity === 'Gold Legendary' ? 'bg-amber-950 text-amber-400 border-amber-900' : 
                        card.rarity === 'Exotic' ? 'bg-purple-950 text-purple-400 border-purple-900' : 
                        'bg-red-950 text-red-50 text-red-400 border-red-900'
                      }`}>
                        {card.category}
                      </span>
                      <h4 className="text-xs font-sans font-extrabold text-zinc-250 text-zinc-200">{card.name}</h4>
                    </div>
                    <p className="text-[10px] font-mono text-zinc-400 line-clamp-1 leading-relaxed">
                      {card.abilityDescription || card.flavorText || 'Standard DN Cards item specifications.'}
                    </p>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                    {card.category !== 'Event' && (
                      <div className="flex gap-2 font-mono text-[10px] text-zinc-550 text-zinc-500">
                        <span>ATK: <b className="text-amber-500 font-sans font-extrabold">{card.attack}</b></span>
                        <span>HP: <b className="text-emerald-400 font-sans font-extrabold">{card.maxHealth}</b></span>
                      </div>
                    )}
                    <div className="text-right text-[10px] font-mono">
                      <span className="text-zinc-500">Cost: {card.cost}</span>
                      {isOwned ? (
                        <p className="text-[8.5px] text-emerald-400 font-bold tracking-wide uppercase">✓ OWNED</p>
                      ) : (
                        <p className="text-[8.5px] text-zinc-650 text-zinc-600 font-bold uppercase">LOCKED</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Card visual rendering preview */}
          <div className="lg:col-span-1 bg-zinc-950 border border-zinc-850 p-4 rounded-xl flex flex-col justify-between min-h-[300px]">
            {hoveredCard ? (
              <div className="space-y-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-center pb-2 border-b border-zinc-900">
                    <span className="text-[8px] font-mono text-zinc-500 uppercase tracking-widest block">CARD DATA VIEW</span>
                    <h4 className="text-sm font-sans font-extrabold text-zinc-100">{hoveredCard.name}</h4>
                  </div>

                  {/* Card Visual Preview */}
                  <div className="my-4 flex justify-center">
                    <div className={`relative w-40 h-54 rounded-lg border-2 overflow-hidden shadow-2xl bg-gradient-to-b from-zinc-900 to-black flex flex-col justify-between p-3.5 transition-all duration-300 ${
                      hoveredCard.rarity === 'Common' ? 'border-zinc-750 shadow-zinc-950/50' : 
                      hoveredCard.rarity === 'Uncommon' ? 'border-emerald-500 shadow-emerald-950/20' : 
                      hoveredCard.rarity === 'Gold Legendary' ? 'border-amber-400 shadow-amber-500/10' : 
                      hoveredCard.rarity === 'Exotic' ? 'border-purple-500 shadow-purple-500/15' : 
                      'border-red-500 shadow-red-500/15 animate-pulse'
                    }`}>
                      <div className="absolute inset-x-0 h-0.5 bg-white/5 opacity-10 top-0 animate-[scanline_3s_infinite_linear]" style={{ backgroundImage: 'linear-gradient(to bottom, rgba(255,255,255,0) 0%, rgba(255,255,255,0.8) 50%, rgba(255,255,255,0) 100%)' }}></div>
                      
                      {/* Header */}
                      <div className="flex justify-between items-center z-10 text-[6.5px]">
                        <span className="text-zinc-400 font-mono font-bold uppercase">{hoveredCard.category}</span>
                        <div className="bg-zinc-950/90 border border-zinc-800 rounded px-1.5 py-0.2">
                          <span className="text-zinc-500 font-mono">SPL </span>
                          <span className="font-sans font-extrabold text-amber-500 text-[8px]">{hoveredCard.cost}</span>
                        </div>
                      </div>

                      {/* Image frame */}
                      <div className="flex-1 my-2 bg-zinc-950/95 border border-zinc-850 rounded flex items-center justify-center relative overflow-hidden">
                        <div className={`absolute w-10 h-10 rounded-full blur-xl opacity-20 ${
                          hoveredCard.rarity === 'Common' ? 'bg-zinc-500' : 
                          hoveredCard.rarity === 'Uncommon' ? 'bg-emerald-500' : 
                          hoveredCard.rarity === 'Gold Legendary' ? 'bg-amber-400' : 
                          hoveredCard.rarity === 'Exotic' ? 'bg-purple-500' : 'bg-red-500'
                        }`}></div>

                        <div className="absolute h-[1.5px] w-full bg-zinc-900"></div>
                        <div className="absolute w-[1.5px] h-full bg-zinc-900"></div>
                        <div className="absolute w-5 h-5 rounded-full border border-zinc-900"></div>
                      </div>

                      {/* Footer */}
                      <div className="flex justify-between items-end z-10 pt-1 border-t border-zinc-900">
                        <div className="text-left font-sans">
                          <p className="text-[8px] font-sans font-extrabold text-zinc-100 truncate w-20 leading-none mb-1">{hoveredCard.name}</p>
                          <span className={`text-[5px] font-mono font-bold tracking-wide uppercase px-1 rounded ${
                            hoveredCard.rarity === 'Common' ? 'bg-zinc-850 text-zinc-450 text-zinc-400' : 
                            hoveredCard.rarity === 'Uncommon' ? 'bg-emerald-950 text-emerald-450 text-emerald-450 border border-emerald-900/30' : 
                            hoveredCard.rarity === 'Gold Legendary' ? 'bg-amber-950 text-amber-450 text-amber-400 border border-amber-900/30' : 
                            hoveredCard.rarity === 'Exotic' ? 'bg-purple-950 text-purple-450 text-purple-450 border border-purple-900/30' : 
                            'bg-red-950 text-red-450 border border-red-900/10'
                          }`}>
                            {hoveredCard.rarity.replace(' Legendary', '')}
                          </span>
                        </div>

                        {hoveredCard.category !== 'Event' ? (
                          <div className="flex gap-0.5 font-mono text-[6px]">
                            <div className="bg-zinc-950 border border-zinc-805 border-zinc-800 text-center rounded px-1 py-0.2">
                              <span className="font-sans font-extrabold text-amber-500">{hoveredCard.attack}</span>
                            </div>
                            <div className="bg-zinc-950 border border-zinc-808 border-zinc-800 text-center rounded px-1 py-0.2">
                              <span className="font-sans font-extrabold text-emerald-400">{hoveredCard.maxHealth}</span>
                            </div>
                          </div>
                        ) : (
                          <span className="text-[5.5px] font-bold text-emerald-450 text-emerald-450 font-mono">EVENT</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Description / Flavor */}
                  <div className="space-y-2 text-[11px] font-mono bg-zinc-900/60 p-2.5 rounded border border-zinc-900/50">
                    <p className="text-[10px] text-zinc-400 italic">"{hoveredCard.flavorText || 'Collectible card item.'}"</p>
                    {hoveredCard.abilityName && (
                      <div className="border-t border-zinc-900/60 pt-1.5 mt-1.5">
                        <p className="text-[10.5px] font-sans font-extrabold text-zinc-200">{hoveredCard.abilityName}</p>
                        <p className="text-[9.5px] text-zinc-500 leading-relaxed">{hoveredCard.abilityDescription}</p>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="pt-2 text-[9px] font-mono text-zinc-500 text-center uppercase tracking-wide">
                  CARD UNIQUE ID: {hoveredCard.id}
                </div>
              </div>
            ) : (
              <div className="text-center my-auto py-12 text-zinc-500 font-mono text-[10.5px] italic">
                Select any custom card to load live physical specifications.
              </div>
            )}
          </div>

        </div>
      </div>

      {/* LOWER SECTION: ACHIVEMENT RECORDS (FULL WIDTH CARD) */}
      <div className="bg-zinc-90 w-full bg-zinc-900/40 border border-zinc-850 p-5 rounded-xl">
        <div className="border-b border-zinc-850 pb-2 mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-sans font-bold text-zinc-200 tracking-wider uppercase">COLLECTOR CHALLENGES & MILESTONES</h3>
            <p className="text-[10px] font-mono text-zinc-450 text-zinc-400">Complete challenges to secure bonus Progress Shards.</p>
          </div>
          <span className="text-xs font-mono text-amber-500 bg-amber-950/30 border border-amber-900/45 px-2.5 py-1 rounded">
            {achievements.filter(a => a.unlocked).length} / {achievements.length} COMPLETED
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {achievements.map(achievement => (
            <div 
              key={achievement.id}
              className={`bg-zinc-950/90 border rounded p-4 flex gap-4 items-center justify-between transition-all ${achievement.unlocked ? 'border-amber-500/25 bg-amber-950/3' : 'border-zinc-850'}`}
            >
              <div className="flex items-center gap-3.5">
                <div className={`p-2 rounded-lg border ${achievement.unlocked ? 'border-amber-500 text-amber-400 bg-amber-900/10' : 'border-zinc-800 text-zinc-500'}`}>
                  <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                </div>
                <div>
                  <h4 className="text-xs font-sans font-bold text-zinc-150 leading-tight">{achievement.title}</h4>
                  <p className="text-[10.5px] font-mono text-zinc-450 text-zinc-400 mt-1">{achievement.description}</p>
                  
                  {/* Progress ratio indicator */}
                  <div className="flex items-center gap-2 mt-2">
                    <div className="w-24 bg-zinc-900 h-1.5 rounded-full overflow-hidden border border-zinc-850">
                      <div 
                        className={`h-full transition-all ${achievement.unlocked ? 'bg-amber-500' : 'bg-zinc-600'}`}
                        style={{ width: `${(achievement.progressCurrent / achievement.progressMax) * 100}%` }}
                      />
                    </div>
                    <span className="text-[9px] font-mono text-zinc-500">({achievement.progressCurrent}/{achievement.progressMax})</span>
                  </div>
                </div>
              </div>

              {/* CLAIM SHARDS BOUNTY CHIP */}
              <div className="text-right flex-shrink-0">
                <span className="text-[10px] font-mono text-amber-500 bg-amber-950/40 border border-amber-900 px-2 py-1 rounded block mb-2 font-bold">
                  +{achievement.rewardShards} SHARDS
                </span>
                
                {achievement.unlocked ? (
                  <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 justify-end font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ACQUIRED
                  </span>
                ) : (
                  <span className="text-[9px] text-zinc-500 font-mono tracking-wider italic block">IN PROGRESS</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
