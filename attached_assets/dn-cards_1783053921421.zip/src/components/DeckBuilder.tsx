/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, Minus, Check, Save, Sparkles, Filter, Search, Award, Info, Trash2, Fuel, RefreshCw, Zap
} from 'lucide-react';
import { Card, Rarity, CardCategory } from '../types';
import { CARD_DATABASE } from '../data/cards';

interface DeckBuilderProps {
  ownedCardIds: string[];
  dnShards: number;
  customDecks: { [deckId: string]: string[] };
  activeDeckId: string;
  saveDeck: (deckId: string, cardIds: string[]) => void;
  unlockCardWithShards: (cardId: string, costShards: number) => void;
  setActiveDeck: (deckId: string) => void;
}

export default function DeckBuilder({
  ownedCardIds,
  dnShards,
  customDecks,
  activeDeckId,
  saveDeck,
  unlockCardWithShards,
  setActiveDeck
}: DeckBuilderProps) {
  // Navigation
  const [editingDeckId, setEditingDeckId] = useState<string | null>(Object.keys(customDecks)[0] || 'starter_preset');
  
  // Deck Name input (for new or editing deck)
  const [deckName, setDeckName] = useState('My Custom Deck');
  
  // Active custom cards chosen
  const [selectedCardIds, setSelectedCardIds] = useState<string[]>(
    customDecks[editingDeckId || ''] || CARD_DATABASE.filter(c => c.isStarter).map(c => c.id)
  );

  // Filter conditions
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CardCategory | 'All'>('All');
  const [selectedRarity, setSelectedRarity] = useState<Rarity | 'All'>('All');
  const [selectedSet, setSelectedSet] = useState<'All' | 'Set 1' | 'Set 2'>('All');

  // Case Locker loot animations
  const [openingCrate, setOpeningCrate] = useState(false);
  const [revealedCard, setRevealedCard] = useState<Card | null>(null);

  // Deck building stats
  const totalDeckCount = selectedCardIds.length;
  const isDeckComplete = totalDeckCount === 15;

  // Filter original library
  const getFilteredLibrary = () => {
    return CARD_DATABASE.filter(card => {
      // Is card owned? (Starter deck is always owned, others must be in ownedCardIds)
      const isOwned = card.isStarter || ownedCardIds.includes(card.id);
      if (!isOwned) return false;

      const matchesSearch = card.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        (card.abilityName && card.abilityName.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesCategory = selectedCategory === 'All' || card.category === selectedCategory;
      const matchesRarity = selectedRarity === 'All' || card.rarity === selectedRarity;
      const matchesSet = selectedSet === 'All' || card.set === selectedSet;

      return matchesSearch && matchesCategory && matchesRarity && matchesSet;
    });
  };

  // Get full collectible database that are NOT owned yet to show they can unlock them
  const getLockedLibrary = () => {
    return CARD_DATABASE.filter(card => {
      const isOwned = card.isStarter || ownedCardIds.includes(card.id);
      const matchesSet = selectedSet === 'All' || card.set === selectedSet;
      return !isOwned && matchesSet;
    });
  };

  // Click card to add/remove from deck
  const toggleCardInDeck = (cardId: string) => {
    if (selectedCardIds.includes(cardId)) {
      // Remove one instance
      setSelectedCardIds(prev => prev.filter(id => id !== cardId));
    } else {
      if (selectedCardIds.length >= 15) {
        alert('Deck capacity reached! A standard collection deck contains exactly 15 cards.');
        return;
      }
      setSelectedCardIds(prev => [...prev, cardId]);
    }
  };

  const handleSaveDeck = () => {
    if (!editingDeckId) return;
    saveDeck(editingDeckId, selectedCardIds);
    setActiveDeck(editingDeckId);
    alert('Your Custom Deck has been successfully saved!');
  };

  const unlockCrateWithCurrency = () => {
    const cost = 120; // 120 DN shards per crate unlock
    if (dnShards < cost) {
      alert('Insufficient Shards! Win card battles to earn progress shards.');
      return;
    }

    const locked = getLockedLibrary();
    if (locked.length === 0) {
      alert('All legendary high-grade cards are already unlocked in your card library!');
      return;
    }

    setOpeningCrate(true);
    setRevealedCard(null);

    // Pick a random locked card
    const rewardCard = locked[Math.floor(Math.random() * locked.length)];

    setTimeout(() => {
      unlockCardWithShards(rewardCard.id, cost);
      setRevealedCard(rewardCard);
      setOpeningCrate(false);
    }, 2000);
  };

  // Calculates energy deployment cost curves
  const getCostCurveArray = () => {
    const curve = Array(8).fill(0);
    selectedCardIds.forEach(id => {
      const card = CARD_DATABASE.find(c => c.id === id);
      if (card) {
        const cVal = Math.min(7, card.cost);
        curve[cVal] += 1;
      }
    });
    return curve;
  };

  const getRarityBadgeColor = (rarity: Rarity) => {
    switch (rarity) {
      case 'Common': return 'bg-zinc-650 text-zinc-100 border-zinc-500';
      case 'Uncommon': return 'bg-emerald-800 text-emerald-100 border-emerald-600';
      case 'Gold Legendary': return 'bg-amber-600 text-amber-50 border-amber-300 shadow';
      case 'Exotic': return 'bg-purple-800 text-purple-100 border-purple-500';
      case 'Limited Edition': return 'bg-rose-750 text-red-50 border-rose-450 font-bold';
    }
  };

  const costCurves = getCostCurveArray();

  return (
    <div className="flex flex-col gap-6" id="deck-builder-main">
      {/* HEADER SECTION banner */}
      <div className="flex flex-wrap items-center justify-between bg-zinc-910 bg-zinc-900 border border-zinc-800 p-4 rounded-lg shadow gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-zinc-850 rounded text-amber-500 border border-zinc-700">
            <Fuel className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h1 className="text-xl font-sans font-bold text-zinc-100 uppercase tracking-tight flex items-center gap-1.5">
              DN Deck Builder <span className="text-xs font-mono text-zinc-500 bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700">COLLECTION</span>
            </h1>
            <p className="text-xs font-mono text-zinc-400">Curate exactly 15 cards from your collection to battle other players.</p>
          </div>
        </div>

        {/* Currency summary block */}
        <div className="flex items-center gap-4">
          <div className="bg-zinc-950 border border-zinc-850 px-3.5 py-1.5 rounded text-xs font-mono text-amber-400 flex items-center gap-2">
            <Zap className="w-4 h-4" />
            <span>PROGRESS SHARDS: <strong className="font-sans text-sm">{dnShards}</strong></span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: ACTIVE DECK DETAILS (1 COL) */}
        <div className="xl:col-span-1 bg-zinc-900/40 border border-zinc-850 rounded-xl p-4 lg:p-5 flex flex-col gap-4">
          <div className="border-b border-zinc-850 pb-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">ACTIVE DECK DEPLOYMENT</span>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${isDeckComplete ? 'bg-emerald-950 text-emerald-400 border border-emerald-900' : 'bg-red-950 text-red-400 border border-red-900'}`}>
                {isDeckComplete ? 'READY FOR BATTLE' : 'INCOMPLETE DECK'}
              </span>
            </div>
            
            <input 
              type="text"
              value={deckName}
              onChange={(e) => setDeckName(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 hover:border-zinc-750 focus:border-amber-500 p-2 text-zinc-150 font-bold rounded text-xs outline-none focus:ring-1 focus:ring-amber-500/20"
              placeholder="Deck Code Name"
            />
          </div>

          {/* ACTIVE COUNTER */}
          <div className="bg-zinc-950 border border-zinc-850 p-3 rounded flex items-center justify-between">
            <div>
              <p className="text-[10px] font-mono text-zinc-550 text-zinc-500">DECK SIZE CAPACITY</p>
              <h3 className="text-2xl font-vans font-extrabold text-zinc-100 font-sans">{totalDeckCount} / 15</h3>
            </div>
            <div className="text-right">
              <button
                type="button"
                onClick={handleSaveDeck}
                disabled={!isDeckComplete}
                className={`px-4 py-2 text-xs font-sans font-bold tracking-wider rounded transition-all flex items-center gap-1.5 ${isDeckComplete ? 'bg-amber-550 border border-amber-400 hover:bg-amber-450 text-black shadow-md p-2' : 'bg-zinc-800 text-zinc-500 border border-zinc-750 cursor-not-allowed text-center'}`}
              >
                <Save className="w-3.5 h-3.5" />
                SAVE & EQUIP DECK
              </button>
            </div>
          </div>

          {/* COST CURVE GRAPH */}
          <div className="bg-zinc-950/40 border border-zinc-850 p-3 rounded-lg">
            <h5 className="text-[10px] font-mono text-zinc-400 tracking-wider mb-2 uppercase">RESOURCE ENERGY CURVE</h5>
            <div className="h-14 flex items-end justify-between px-2 gap-1.5 pt-2">
              {costCurves.map((count, index) => {
                const heightPercent = count > 0 ? (count / 8) * 100 : 3;
                return (
                  <div key={`curve_${index}`} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full bg-zinc-900 border border-zinc-800/40 rounded-t h-12 flex items-end overflow-hidden">
                      <div 
                        className="bg-amber-500/30 border-t border-amber-400 w-full rounded-t transition-all"
                        style={{ height: `${heightPercent}%` }}
                      />
                    </div>
                    <span className="text-[9px] font-mono text-zinc-500">{index === 7 ? '7+' : index}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* SELECTED CARDS DETAILED LIST */}
          <div className="flex-1 flex flex-col gap-2">
            <h5 className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest border-b border-zinc-850 pb-1.5">DECK ROSTER COMPOSITION</h5>
            
            <div className="space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
              {selectedCardIds.length === 0 ? (
                <div className="text-center py-8 text-xs font-mono text-zinc-500 italic">
                  Choose from your collection library on the right to start drafting components.
                </div>
              ) : (
                selectedCardIds.map((cardId, index) => {
                  const card = CARD_DATABASE.find(c => c.id === cardId);
                  if (!card) return null;
                  return (
                    <div 
                      key={`${cardId}_sel_${index}`}
                      className="bg-zinc-950/80 hover:bg-zinc-950 border border-zinc-850 p-2 rounded flex items-center justify-between group transition-all"
                    >
                      <div className="flex items-center gap-2">
                        {/* COST EMBLEM */}
                        <div className="w-5 h-5 rounded-full bg-zinc-900 border border-zinc-700 flex items-center justify-center font-sans font-extrabold text-[10px] text-amber-500">
                          {card.cost}
                        </div>
                        <div>
                          <p className="text-[11px] font-sans font-bold text-zinc-200">{card.name}</p>
                          <p className="text-[8px] font-mono text-zinc-550 text-zinc-500 uppercase">{card.rarity} • {card.category}</p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => toggleCardInDeck(cardId)}
                        className="p-1 px-2.5 rounded bg-zinc-900 border border-zinc-800 group-hover:bg-red-950/40 group-hover:border-red-900/50 text-[10px] font-mono text-zinc-400 hover:text-red-400 hover:scale-103 transition-all"
                      >
                        REMOVE
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: OWNED INVENTORY & SEARCH FILTERS (2 COLS) */}
        <div className="xl:col-span-2 bg-zinc-900/20 border border-zinc-850 rounded-xl p-4 lg:p-5 flex flex-col gap-4">
          
          {/* SEARCH FILTERS HEADER BAR */}
          <div className="flex flex-wrap items-center gap-3 bg-zinc-900/50 border border-zinc-850 p-3 rounded-lg justify-between">
            <div className="flex items-center gap-2 w-full sm:w-max max-w-sm bg-zinc-950 border border-zinc-800 px-3 py-1.5 rounded">
              <Search className="w-4 h-4 text-zinc-500" />
              <input
                type="text"
                placeholder="Search card collection..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent text-xs text-zinc-100 outline-none w-full"
              />
            </div>

            {/* SELECTION DROPDOWNS */}
            <div className="flex flex-wrap gap-2">
              {/* Set selector dropdown */}
              <select
                value={selectedSet}
                onChange={(e) => setSelectedSet(e.target.value as any)}
                className="bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-[11px] font-mono text-zinc-300 p-2 rounded outline-none cursor-pointer"
              >
                <option value="All">All Card Sets</option>
                <option value="Set 1">Set 1: Vanguard Core</option>
                <option value="Set 2">Set 2: Nebula Rift</option>
              </select>

              {/* Category Filter */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value as any)}
                className="bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-[11px] font-mono text-zinc-300 p-2 rounded outline-none cursor-pointer"
              >
                <option value="All">All Categories</option>
                <option value="Infantry">Infantry</option>
                <option value="Vehicles">Vehicles</option>
                <option value="Aircraft">Aircraft</option>
                <option value="Naval">Naval</option>
                <option value="Support">Support</option>
                <option value="Mechs">Mechs</option>
                <option value="Bosses">Bosses</option>
                <option value="Event">Event Assist</option>
              </select>

              {/* Rarity Filter */}
              <select
                value={selectedRarity}
                onChange={(e) => setSelectedRarity(e.target.value as any)}
                className="bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-[11px] font-mono text-zinc-300 p-2 rounded outline-none cursor-pointer"
              >
                <option value="All">All Rarities</option>
                <option value="Common">Common</option>
                <option value="Uncommon">Uncommon</option>
                <option value="Gold Legendary">Gold Legendary</option>
                <option value="Exotic">Exotic</option>
                <option value="Limited Edition">Limited Edition</option>
              </select>
            </div>
          </div>

          {/* ACTIVE LIBRARY LISTING */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-3 border-b border-zinc-850 pb-1">
              <h4 className="text-xs font-mono font-bold text-zinc-400">OWNED CARDS LIBRARY ({getFilteredLibrary().length})</h4>
              <span className="text-[10px] font-mono text-zinc-550 text-zinc-500 italic">Starter library is fully completed by default</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 overflow-y-auto max-h-[480px] pr-1" id="deck-builder-grid">
              {getFilteredLibrary().map(card => {
                const countInDeck = selectedCardIds.filter(id => id === card.id).length;
                const isSelected = selectedCardIds.includes(card.id);
                const isHolo = ['Gold Legendary', 'Exotic', 'Limited Edition'].includes(card.rarity);

                // Element badge colors matching Showcase theme
                const getEnergyBadge = (category: CardCategory) => {
                  switch (category) {
                    case 'Vehicles': return '⚙️';
                    case 'Infantry': return '✊';
                    case 'Aircraft': return '💨';
                    case 'Naval': return '💧';
                    case 'Mechs': return '🔮';
                    case 'Bosses': return '🔥';
                    case 'Support': return '🛡️';
                    default: return '⭐';
                  }
                };

                return (
                  <div
                    key={`lib_${card.id}`}
                    onClick={() => toggleCardInDeck(card.id)}
                    className={`pokecard-tilt holo-shine relative cursor-pointer select-none transition-all duration-300 ${
                      isSelected ? 'ring-4 ring-yellow-400 scale-[1.01]' : ''
                    } rounded-2xl flex flex-col p-1 bg-slate-700 ${
                      card.rarity === 'Gold Legendary' ? 'bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-600' :
                      card.rarity === 'Exotic' ? 'bg-gradient-to-r from-purple-600 via-fuchsia-400 to-indigo-700' :
                      card.rarity === 'Limited Edition' ? 'bg-gradient-to-r from-rose-600 via-pink-400 to-red-700' :
                      'border border-slate-600'
                    }`}
                    style={{ height: '220px' }}
                  >
                    {/* Inner TCG container */}
                    <div className="flex-1 rounded-xl bg-gradient-to-b from-[#090d22] to-[#12183c] p-2 flex flex-col justify-between overflow-hidden relative">
                      
                      {/* Tally indicator badge */}
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-5 h-5 bg-yellow-400 rounded-full flex items-center justify-center font-bold text-slate-950 text-[10px] z-20 border border-white shadow animate-bounce">
                          {countInDeck}
                        </div>
                      )}

                      {/* Card mini head */}
                      <div className="flex justify-between items-center z-10 border-b border-blue-900/40 pb-0.5">
                        <div className="flex flex-col">
                          <span className="text-[6px] font-mono tracking-widest text-slate-400 font-bold uppercase">{card.rarity.replace(' Legendary', '')}</span>
                          <h5 className="text-[10px] font-sans font-black text-white truncate max-w-[80px] leading-tight-none">{card.name}</h5>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-[8px] font-sans font-extrabold text-blue-400">{card.maxHealth * 10} HP</span>
                          <span className="text-[7.5px] font-mono">{getEnergyBadge(card.category)}</span>
                        </div>
                      </div>

                      {/* Art Thumbnail */}
                      <div className="my-1 h-20 rounded-md bg-[#04081c] border border-blue-950 overflow-hidden relative">
                        {card.imageUrl ? (
                          <img 
                            src={card.imageUrl} 
                            alt={card.name} 
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover pointer-events-none"
                            loading="lazy"
                            onError={(e) => { e.currentTarget.style.display = 'none'; }}
                          />
                        ) : null}
                      </div>

                      {/* Combat stats strip */}
                      <div className="text-[7.5px] font-mono text-zinc-300 leading-tight">
                        <p className="truncate font-sans font-bold text-white"><span className="text-yellow-400">⚡</span> {card.abilityName || 'Basic Strike'}</p>
                        <p className="text-[7px] text-zinc-400 line-clamp-1 mt-0.5">{card.abilityDescription || card.flavorText}</p>
                      </div>

                      {/* Bottom mini row */}
                      <div className="flex justify-between items-center text-[7px] pt-1 border-t border-blue-950 text-slate-400 font-mono">
                        <span className="text-yellow-400 font-bold flex items-center gap-0.5">COST: {card.cost}</span>
                        <span className="flex gap-1.5 font-bold">
                          <span>ATK: {card.attack * 10}</span>
                        </span>
                      </div>

                    </div>
                  </div>
                );
              })}

              {getFilteredLibrary().length === 0 && (
                <div className="col-span-full text-center py-12 text-zinc-500 font-mono text-xs italic">
                  No unlocked cards matching these filters. Try opening high-grade supply crates!
                </div>
              )}
            </div>
          </div>

          {/* PROGRESSION CRATE REWARD BLOCK */}
          <div className="bg-zinc-950 border border-zinc-850 rounded-lg p-4 mt-2">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="space-y-1">
                <h5 className="text-xs font-sans font-bold text-zinc-100 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                  HIGH-GRADE BOOSTER CRATE PACK
                </h5>
                <p className="text-[10px] font-mono text-zinc-450 text-zinc-400 leading-relaxed max-w-lg">
                  Unlock standard card crates for **120 Shards**. Guaranteed to yield a collectible **Gold Legendary, Exotic, or Limited Edition** card. Zero pay-to-win.
                </p>
              </div>

              <div>
                <button
                  type="button"
                  onClick={unlockCrateWithCurrency}
                  disabled={openingCrate || getLockedLibrary().length === 0}
                  className="px-5 py-2.5 bg-zinc-900 hover:bg-amber-550 hover:border-amber-400 text-zinc-100 hover:text-stone-950 text-xs font-sans font-bold tracking-wider rounded border border-zinc-700 transition-all flex items-center gap-2 relative shadow"
                >
                  {openingCrate ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                      SECURELY UNLOCKING PACK CRATE...
                    </>
                  ) : getLockedLibrary().length === 0 ? (
                    'ALL CARDS SUCCESSFULLY UNLOCKED'
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5 text-amber-400 fill-current group-hover:text-stone-950" />
                      UNLOCK CARD CRATE (120 SHARDS)
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* EXPAND REVEAL CRATE OVERLAY DISPLAY */}
            {revealedCard && (
              <div className="mt-3.5 bg-zinc-900 border border-amber-500/20 rounded p-3 text-center space-y-2 relative overflow-hidden animate-fade-in animate-pulse">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
                <span className="text-[9px] font-mono text-amber-400 tracking-widest uppercase block">CRATE UNLOCKED</span>
                
                <h4 className="text-sm font-sans font-extrabold text-white">{revealedCard.name} Added!</h4>
                <p className="text-xs text-zinc-400 max-w-md mx-auto leading-relaxed">
                  Congratulations! **{revealedCard.name}** ({revealedCard.rarity} - {revealedCard.category}) is now fully unlocked in your collection and playable immediately in your Deck layouts.
                </p>

                <div className="flex justify-center pt-1.5">
                  <button
                    type="button"
                    onClick={() => setRevealedCard(null)}
                    className="px-3 py-1 bg-zinc-950 text-[10px] font-mono text-zinc-400 hover:text-white rounded border border-zinc-800"
                  >
                    CONFIRM
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
