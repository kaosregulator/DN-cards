/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Centralized Card Database with custom Admin configurations,
 * Level progression, and 3-stage Evolution system.
 */

import { Card, Rarity, CardCategory } from '../types';
import { SET1_CARDS } from './set1_data';
import { SET2_CARDS } from './set2_data';

// Definition of Custom Config Map
export interface CustomCardConfig {
  id: string;
  name?: string;
  rarity?: Rarity;
  category?: CardCategory;
  cost?: number;
  baseAttack?: number;
  baseHealth?: number;
  imageUrl?: string;
  flavorText?: string;
  set?: 'Set 1' | 'Set 2';
  isStarter?: boolean;
  
  // Progression fields
  level?: number; // 1 to 10
  xp?: number;    // 0 to 100
  
  // Custom move sets for the 3 stages
  ability1Name?: string;
  ability1Desc?: string;
  ability2Name?: string;
  ability2Desc?: string;
  ability3Name?: string;
  ability3Desc?: string;
}

// Master Static Baseline Cards
const BASE_CARDS: Card[] = [
  ...SET1_CARDS,
  ...SET2_CARDS
];

// Re-usable helper to get multipliers based on level
export function getLevelStatMultiplier(level: number): number {
  switch (level) {
    case 1: return 1.0;
    case 2: return 1.10;
    case 3: return 1.20;
    case 4: return 1.35; // Evolves to Stage 2
    case 5: return 1.50;
    case 6: return 1.60;
    case 7: return 1.70;
    case 8: return 1.85; // Evolves to Stage 3
    case 9: return 2.00;
    case 10: return 2.25; // Maxed stats
    default: return 1.0;
  }
}

// Re-usable helper to compute Stage from level
export function getStageFromLevel(level: number): 1 | 2 | 3 {
  if (level >= 8) return 3;
  if (level >= 4) return 2;
  return 1;
}

// Expose the global CARD_DATABASE reference
export const CARD_DATABASE: Card[] = [];

// Load from LocalStorage and build CARD_DATABASE
export function rebuildCardDatabase() {
  const customConfigsRaw = localStorage.getItem('dn_custom_card_configs');
  const customConfigs: Record<string, CustomCardConfig> = customConfigsRaw 
    ? JSON.parse(customConfigsRaw) 
    : {};

  const tempDatabase: Card[] = [];

  // 1. Process standard cards and merge with override configurations
  BASE_CARDS.forEach((base) => {
    const config: Partial<CustomCardConfig> = customConfigs[base.id] || {};
    
    const level = config.level ?? 1;
    const xp = config.xp ?? 0;
    const stage = getStageFromLevel(level);

    // Baseline ability setup
    const ability1Name = config.ability1Name || base.abilityName || 'Tactical Blitz';
    const ability1Desc = config.ability1Desc || base.abilityDescription || 'Fires primary weapons with tactical efficiency.';
    
    const ability2Name = config.ability2Name || `[Evolved] ${ability1Name}`;
    const ability2Desc = config.ability2Desc || `Enhanced power: ${ability1Desc} Deals bonus damage.`;
    
    const ability3Name = config.ability3Name || `[Ultimate] ${ability1Name}`;
    const ability3Desc = config.ability3Desc || `Ultimate force: ${ability1Desc} Bypasses all active defensive barriers.`;

    // Calculate level augmented stats
    const rawAttack = config.baseAttack ?? base.attack;
    const rawHealth = config.baseHealth ?? base.health;
    const multiplier = getLevelStatMultiplier(level);

    const levelAttack = Math.round(rawAttack * multiplier);
    const levelHealth = Math.round(rawHealth * multiplier);

    // Direct active ability set based on current evolution stage
    let activeAbilityName = ability1Name;
    let activeAbilityDesc = ability1Desc;
    if (stage === 2) {
      activeAbilityName = ability2Name;
      activeAbilityDesc = ability2Desc;
    } else if (stage === 3) {
      activeAbilityName = ability3Name;
      activeAbilityDesc = ability3Desc;
    }

    const decoratedCard: Card = {
      ...base,
      name: config.name || base.name,
      rarity: config.rarity || base.rarity,
      category: config.category || base.category,
      cost: config.cost || base.cost,
      attack: levelAttack,
      health: levelHealth,
      maxHealth: levelHealth,
      imageUrl: config.imageUrl || base.imageUrl,
      flavorText: config.flavorText || base.flavorText,
      set: config.set || base.set,
      isStarter: config.isStarter ?? base.isStarter,
      
      // Evolving Mechanics
      level,
      xp,
      stage,
      ability1Name,
      ability1Desc,
      ability2Name,
      ability2Desc,
      ability3Name,
      ability3Desc,
      
      // Keep real base values saved internally for editing purposes
      abilityName: activeAbilityName,
      abilityDescription: activeAbilityDesc,
    };

    tempDatabase.push(decoratedCard);
  });

  // 2. Process completely newly added cards from admin panels (IDs starting with 'custom_')
  Object.keys(customConfigs).forEach((id) => {
    if (id.startsWith('custom_')) {
      const config = customConfigs[id];
      const level = config.level ?? 1;
      const xp = config.xp ?? 0;
      const stage = getStageFromLevel(level);

      const ability1Name = config.ability1Name || 'Standard Strike';
      const ability1Desc = config.ability1Desc || 'Fires general munition at selected units.';
      const ability2Name = config.ability2Name || `[Evolved] ${ability1Name}`;
      const ability2Desc = config.ability2Desc || `Deals upgraded burst damage.`;
      const ability3Name = config.ability3Name || `[Ultimate] ${ability1Name}`;
      const ability3Desc = config.ability3Desc || `Deals devastating custom impact and clears status shields.`;

      const rawAttack = config.baseAttack ?? 3;
      const rawHealth = config.baseHealth ?? 4;
      const multiplier = getLevelStatMultiplier(level);

      const levelAttack = Math.round(rawAttack * multiplier);
      const levelHealth = Math.round(rawHealth * multiplier);

      let activeAbilityName = ability1Name;
      let activeAbilityDesc = ability1Desc;
      if (stage === 2) {
        activeAbilityName = ability2Name;
        activeAbilityDesc = ability2Desc;
      } else if (stage === 3) {
        activeAbilityName = ability3Name;
        activeAbilityDesc = ability3Desc;
      }

      const newCard: Card = {
        id,
        name: config.name || 'New Custom Card',
        rarity: config.rarity || 'Common',
        category: config.category || 'Infantry',
        cost: config.cost || 3,
        attack: levelAttack,
        health: levelHealth,
        maxHealth: levelHealth,
        imageUrl: config.imageUrl || 'https://misu.nephbox.net/card_image/1363917781355069761/master_reaper_00018112.png',
        flavorText: config.flavorText || 'Custom built tactical combat card.',
        set: config.set || 'Set 2',
        isStarter: config.isStarter ?? false,
        level,
        xp,
        stage,
        ability1Name,
        ability1Desc,
        ability2Name,
        ability2Desc,
        ability3Name,
        ability3Desc,
        abilityName: activeAbilityName,
        abilityDescription: activeAbilityDesc,
      };

      tempDatabase.push(newCard);
    }
  });

  // Hot swap in place to preserve module references!
  CARD_DATABASE.length = 0;
  CARD_DATABASE.push(...tempDatabase);
}

// Function to save overrides
export function saveCardOverrides(id: string, updates: Partial<CustomCardConfig>) {
  const customConfigsRaw = localStorage.getItem('dn_custom_card_configs');
  const customConfigs: Record<string, CustomCardConfig> = customConfigsRaw 
    ? JSON.parse(customConfigsRaw) 
    : {};

  const existingConfig = customConfigs[id] || { id };
  customConfigs[id] = {
    ...existingConfig,
    ...updates,
  };

  localStorage.setItem('dn_custom_card_configs', JSON.stringify(customConfigs));
  rebuildCardDatabase();
}

// Function to gain card XP after playing battles
export function addCardXp(id: string, amount: number): { leveledUp: boolean; newLevel: number } {
  const customConfigsRaw = localStorage.getItem('dn_custom_card_configs');
  const customConfigs: Record<string, CustomCardConfig> = customConfigsRaw 
    ? JSON.parse(customConfigsRaw) 
    : {};

  const existingConfig = customConfigs[id] || { id };
  let currentLevel = existingConfig.level ?? 1;
  let currentXp = existingConfig.xp ?? 0;

  if (currentLevel >= 10) {
    return { leveledUp: false, newLevel: 10 };
  }

  currentXp += amount;
  let leveledUp = false;

  while (currentXp >= 100 && currentLevel < 10) {
    currentXp -= 100;
    currentLevel += 1;
    leveledUp = true;
  }

  customConfigs[id] = {
    ...existingConfig,
    level: currentLevel,
    xp: currentXp
  };

  localStorage.setItem('dn_custom_card_configs', JSON.stringify(customConfigs));
  rebuildCardDatabase();

  return { leveledUp, newLevel: currentLevel };
}

// Get raw baseline card properties before level multiplier is applied
export function getRawBaseStats(id: string): { attack: number; health: number } {
  const foundInBase = BASE_CARDS.find(c => c.id === id);
  if (foundInBase) {
    return { attack: foundInBase.attack, health: foundInBase.health };
  }
  
  // New added cards
  const customConfigsRaw = localStorage.getItem('dn_custom_card_configs');
  const customConfigs: Record<string, CustomCardConfig> = customConfigsRaw 
    ? JSON.parse(customConfigsRaw) 
    : {};
  const config = customConfigs[id];
  return {
    attack: config?.baseAttack ?? 3,
    health: config?.baseHealth ?? 4
  };
}

// Perform initial build of card database on import
rebuildCardDatabase();

export const STARTER_DECK_CARDS = CARD_DATABASE.filter(c => c.isStarter);
export const COLLECTIBLE_CARDS = CARD_DATABASE.filter(c => !c.isStarter);
