/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Sword, Layers, Trophy, Award, User, ShoppingBag, 
  HelpCircle, Shield, MessageSquare, Zap, LogIn, Sparkles, ChevronRight,
  Check, Plus, RefreshCw, FileText, ChevronDown, ChevronUp, Trash2
} from 'lucide-react';

import { Card, PlayerInventory, GameRank, MatchHistoryEntry, Achievement, DiscordUser } from './types';
import { CARD_DATABASE, STARTER_DECK_CARDS } from './data/cards';

// Subcomponents
import BattleHub from './components/BattleHub';
import DeckBuilder from './components/DeckBuilder';
import ProfileStats from './components/ProfileStats';
import Leaderboard from './components/Leaderboard';
import Showcase from './components/Showcase';
import AdminHub from './components/AdminHub';

export default function App() {
  // Navigation Menu Active Tab selection
  const [activeTab, setActiveTab2] = useState<'BattleHub' | 'DeckBuilder' | 'Profile' | 'Leaderboards' | 'Showcase' | 'Admin'>('BattleHub');
  const [dbVersion, setDbVersion] = useState(0);

   // Discord State Management (Allow syncing later, initially offline guest mode)
  const [discordUser, setDiscordUser] = useState<DiscordUser>(() => {
    const saved = localStorage.getItem('dn_discord_user_oauth');
    if (saved) return JSON.parse(saved);
    return { id: 'dsc_offline', username: 'christopherosorio7', isSynced: false };
  });

  const handleConnectDiscord = (username: string) => {
    const freshUser: DiscordUser = {
      id: 'dsc_' + Math.random().toString(36).substring(2, 11),
      username,
      isSynced: true
    };
    setDiscordUser(freshUser);
    localStorage.setItem('dn_discord_user_oauth', JSON.stringify(freshUser));

    // Fully unlock all collectibles from the main master database to simulate Discord collection mapping!
    const allIds = CARD_DATABASE.map(c => c.id);
    setOwnedCardIds(allIds);
    localStorage.setItem('dn_owned_cards', JSON.stringify(allIds));
  };

  const handleDisconnectDiscord = () => {
    const defaultUser = { id: 'dsc_offline', username: 'Guest Player', isSynced: false };
    setDiscordUser(defaultUser);
    localStorage.setItem('dn_discord_user_oauth', JSON.stringify(defaultUser));

    // Reset back to offline standard sandbox baseline (one card of each rarity)
    const baselineIds = ['298', '274', '261', '267', '314'];
    setOwnedCardIds(baselineIds);
    localStorage.setItem('dn_owned_cards', JSON.stringify(baselineIds));
  };

  // Load state from localStorage or initialize with thematic defaults
  const [dnShards, setDnShards] = useState<number>(() => {
    const saved = localStorage.getItem('dn_shards');
    return saved ? parseInt(saved, 10) : 180; // Starts with 180 shards, allowing a crate decrypt on day 1!
  });

  const [ownedCardIds, setOwnedCardIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('dn_owned_cards');
    if (saved) return JSON.parse(saved);
    // Starter cards are always owned, but let's pre-populate 1 of each of the 5 rarities by default!
    return [
      '298', // Common: Marine Soldier
      '274', // Uncommon: Abrams X
      '261', // Gold Legendary: Master Helstorm
      '267', // Exotic: SB21
      '314'  // Limited Edition: LE A-10
    ];
  });

  const [level, setLevel] = useState<number>(() => {
    const saved = localStorage.getItem('dn_level');
    return saved ? parseInt(saved, 10) : 1;
  });

  const [xp, setXp] = useState<number>(() => {
    const saved = localStorage.getItem('dn_xp');
    return saved ? parseInt(saved, 10) : 40;
  });

  const [rank, setRank] = useState<GameRank>(() => {
    const saved = localStorage.getItem('dn_rank');
    return (saved as GameRank) || 'Sergeant';
  });

  const [rankXp, setRankXp] = useState<number>(() => {
    const saved = localStorage.getItem('dn_rank_xp');
    return saved ? parseInt(saved, 10) : 1540;
  });

  const [customDecks, setCustomDecks] = useState<{ [deckId: string]: string[] }>(() => {
    const saved = localStorage.getItem('dn_custom_decks');
    if (saved) return JSON.parse(saved);
    
    // Create a default 15-card starter blueprint containing Starters & unlocked items
    const starterPreset = [
      '292', '292',
      '289', '289',
      '287', '287',
      '286', '286',
      '278', '278',
      '270', '270',
      '290', '285',
      '268'
    ];
    return { 'standard_division': starterPreset };
  });

  const [activeDeckId, setActiveDeckId] = useState<string>('standard_division');

  const [matchHistory, setMatchHistory] = useState<MatchHistoryEntry[]>(() => {
    const saved = localStorage.getItem('dn_match_history');
    if (saved) return JSON.parse(saved);
    
    // Pre-populate with two epic thematic matches
    return [
      {
        id: 'hist_1',
        mode: 'Casual',
        opponentName: 'Ghost_Rider_DN',
        opponentRank: 'Lieutenant',
        result: 'Victory',
        xpEarned: 80,
        shardsEarned: 30,
        date: '2026-06-15',
        turnsPlayed: 11
      },
      {
        id: 'hist_2',
        mode: 'Ranked',
        opponentName: 'Mech_Commander_X',
        opponentRank: 'Captain',
        result: 'Defeat',
        xpEarned: 40,
        shardsEarned: 15,
        date: '2026-06-14',
        turnsPlayed: 14
      }
    ];
  });

  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    const saved = localStorage.getItem('dn_achievements');
    if (saved) return JSON.parse(saved);

    return [
      {
        id: 'ach_1',
        title: 'Frontline Baptism',
        description: 'Conclude a tactical casual or ranked operation.',
        unlocked: false,
        rewardShards: 40,
        progressMax: 1,
        progressCurrent: 0,
        icon: 'sword'
      },
      {
        id: 'ach_2',
        title: 'Armory Tactician',
        description: 'Complete editing a custom 15-card battle squad blueprint.',
        unlocked: false,
        rewardShards: 50,
        progressMax: 1,
        progressCurrent: 1, // Start custom deck is pre-equipped
        icon: 'tool'
      },
      {
        id: 'ach_3',
        title: 'Logistics Operative',
        description: 'Fully decrypt a high-grade military supply crate container.',
        unlocked: false,
        rewardShards: 60,
        progressMax: 1,
        progressCurrent: 0,
        icon: 'package'
      },
      {
        id: 'ach_4',
        title: 'Divisional General',
        description: 'Win 3 skirmish operations against simulated battalions.',
        unlocked: false,
        rewardShards: 100,
        progressMax: 3,
        progressCurrent: 1, // Pre-pop victory counts of 1
        icon: 'award'
      }
    ];
  });

  // Save states to localstorage on edits
  useEffect(() => {
    localStorage.setItem('dn_shards', dnShards.toString());
  }, [dnShards]);

  useEffect(() => {
    localStorage.setItem('dn_owned_cards', JSON.stringify(ownedCardIds));
  }, [ownedCardIds]);

  useEffect(() => {
    localStorage.setItem('dn_level', level.toString());
    localStorage.setItem('dn_xp', xp.toString());
    localStorage.setItem('dn_rank', rank);
    localStorage.setItem('dn_rank_xp', rankXp.toString());
  }, [level, xp, rank, rankXp]);

  useEffect(() => {
    localStorage.setItem('dn_custom_decks', JSON.stringify(customDecks));
  }, [customDecks]);

  useEffect(() => {
    localStorage.setItem('dn_match_history', JSON.stringify(matchHistory));
  }, [matchHistory]);

  useEffect(() => {
    localStorage.setItem('dn_achievements', JSON.stringify(achievements));
  }, [achievements]);

  // Listen for Discord OAuth Callback from Popup Handshake
  useEffect(() => {
    const handleDiscordOAuthMessage = (event: MessageEvent) => {
      // Accept local or Cloud Run secure origin
      const origin = event.origin;
      if (!origin.includes('localhost') && !origin.includes('127.0.0.1') && !origin.endsWith('.run.app')) {
        return;
      }

      if (event.data?.type === 'DISCORD_OAUTH_SUCCESS' && event.data?.user) {
        const oauthUser = event.data.user;
        setDiscordUser(oauthUser);
        localStorage.setItem('dn_discord_user_oauth', JSON.stringify(oauthUser));

        // Unlock all cards in database to simulate Discord community roster!
        const allCardIds = CARD_DATABASE.map(c => c.id);
        setOwnedCardIds(allCardIds);
        localStorage.setItem('dn_owned_cards', JSON.stringify(allCardIds));
        
        alert(`Successfully linked and synchronized with Discord user account: @${oauthUser.username}!`);
      }
    };

    window.addEventListener('message', handleDiscordOAuthMessage);
    return () => window.removeEventListener('message', handleDiscordOAuthMessage);
  }, []);


  // XP Level Up Logic
  const addXp = (amount: number) => {
    setXp(prevXp => {
      let nextXp = prevXp + amount;
      let nextLevel = level;
      const threshold = 250; // XP threshold per level
      
      if (nextXp >= threshold) {
        nextXp -= threshold;
        nextLevel += 1;
        setLevel(nextLevel);
        // Bonus shards reward for leveling up
        setDnShards(s => s + 50);
        setTimeout(() => alert(`LEVEL UP! You are now level ${nextLevel}. Earned +50 Shards promotion!`), 400);
      }
      return nextXp;
    });
  };

  const addShards = (amount: number) => {
    setDnShards(s => s + amount);
  };

  // Add Match History entry + update achievements progress
  const addMatchHistory = (
    opponent: string,
    opponentRank: GameRank,
    mode: 'Ranked' | 'Casual',
    result: 'Victory' | 'Defeat',
    xpEarned: number,
    shardsEarned: number,
    turns: number
  ) => {
    const entry: MatchHistoryEntry = {
      id: 'match_' + Date.now().toString(),
      mode,
      opponentName: opponent,
      opponentRank,
      result,
      xpEarned,
      shardsEarned,
      date: new Date().toISOString().split('T')[0],
      turnsPlayed: turns
    };

    setMatchHistory(prev => [entry, ...prev]);

    // Update Competitive MMR if Ranked match
    if (mode === 'Ranked') {
      setRankXp(prev => {
        let delta = result === 'Victory' ? 24 : -18;
         let nextXp = Math.max(1000, prev + delta);
         
         // Dynamically re-evaluate Military Title Bracket based on MMR
         let nextRank: GameRank = 'Recruit';
         if (nextXp >= 2500) nextRank = 'General of the Army';
         else if (nextXp >= 2200) nextRank = 'Colonel';
         else if (nextXp >= 1900) nextRank = 'Major';
         else if (nextXp >= 1700) nextRank = 'Captain';
         else if (nextXp >= 1500) nextRank = 'Lieutenant';
         else if (nextXp >= 1300) nextRank = 'Sergeant';
         else if (nextXp >= 1100) nextRank = 'Corporal';
         
         if (nextRank !== rank) {
           setRank(nextRank);
         }
         return nextXp;
      });
    }

    // Progress Achievements triggers
    setAchievements(prev => 
      prev.map(ach => {
        let changed = false;
        let pCurrent = ach.progressCurrent;
        let unlocked = ach.unlocked;

        // Ach_1: Baptisms
        if (ach.id === 'ach_1' && !unlocked) {
          pCurrent = Math.min(ach.progressMax, pCurrent + 1);
          changed = true;
        }

        // Ach_4: 3 Victories
        if (ach.id === 'ach_4' && !unlocked && result === 'Victory') {
          pCurrent = Math.min(ach.progressMax, pCurrent + 1);
          changed = true;
        }

        if (changed) {
          const fullyUnlockednow = pCurrent >= ach.progressMax;
          if (fullyUnlockednow && !unlocked) {
            unlocked = true;
            // Immediate payout of shards
            setDnShards(s => s + ach.rewardShards);
            setTimeout(() => alert(`CHALLENGE UNLOCKED! "${ach.title}" has been claimed. Received +${ach.rewardShards} Shards bonus.`), 800);
          }
          return { ...ach, progressCurrent: pCurrent, unlocked };
        }
        return ach;
      })
    );
  };

  // Save changes to custom cards in Deck
  const saveDeck = (deckId: string, cardIds: string[]) => {
    setCustomDecks(prev => ({
      ...prev,
      [deckId]: cardIds
    }));

    // Update achievement triggers
    setAchievements(prev => 
      prev.map(ach => {
        if (ach.id === 'ach_2' && !ach.unlocked) {
          setDnShards(s => s + ach.rewardShards);
          return { ...ach, progressCurrent: 1, unlocked: true };
        }
        return ach;
      })
    );
  };

  // Unlocking crate item drops
  const unlockCardWithShards = (cardId: string, costShards: number) => {
    setDnShards(s => s - costShards);
    setOwnedCardIds(prev => {
      if (prev.includes(cardId)) return prev;
      return [...prev, cardId];
    });

    // Update decrypt achievement triggers
    setAchievements(prev => 
      prev.map(ach => {
        if (ach.id === 'ach_3' && !ach.unlocked) {
          setDnShards(s => s + ach.rewardShards);
          return { ...ach, progressCurrent: 1, unlocked: true };
        }
        return ach;
      })
    );
  };

  const handleSetActiveDeck = (deckId: string) => {
    setActiveDeckId(deckId);
  };

  const currentDeckList = customDecks[activeDeckId] || [];

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F5F5F4] flex font-sans" id="dn-cards-app-root">
      
      {/* LEFT NAVIGATION RAIL (Editorial Aesthetic) */}
      <nav className="w-[72px] border-r border-[#262626] bg-[#0A0A0A] md:flex hidden flex-col items-center py-8 justify-between shrink-0">
        <div className="flex flex-col items-center gap-10">
          <div 
            onClick={() => setActiveTab2('BattleHub')}
            className="text-orange-500 font-extrabold text-2xl tracking-tighter cursor-pointer hover:opacity-85 select-none"
          >
            DN
          </div>
          <div className="flex flex-col gap-6 opacity-40">
            <div className={`w-6 h-6 border-2 flex items-center justify-center cursor-pointer transition-colors ${activeTab === 'BattleHub' ? 'border-orange-500 text-orange-500 opacity-100' : 'border-zinc-500 text-zinc-500 hover:text-zinc-200'}`} onClick={() => setActiveTab2('BattleHub')} title="Battle Arena">
              <div className="w-2.5 h-2.5 bg-current"></div>
            </div>
            <div className={`w-6 h-6 border-2 rounded-full flex items-center justify-center cursor-pointer transition-colors ${activeTab === 'DeckBuilder' ? 'border-orange-500 text-orange-500 opacity-100' : 'border-zinc-500 text-zinc-500 hover:text-zinc-200'}`} onClick={() => setActiveTab2('DeckBuilder')} title="Deck Builder">
              <div className="w-2 h-2 rounded-full bg-current"></div>
            </div>
            <div className={`w-6 h-6 border-2 rotate-45 flex items-center justify-center cursor-pointer transition-colors ${activeTab === 'Showcase' ? 'border-orange-500 text-orange-500 opacity-100' : 'border-zinc-500 text-zinc-500 hover:text-zinc-200'}`} onClick={() => setActiveTab2('Showcase')} title="Card Collection">
              <div className="w-2 h-2 bg-current"></div>
            </div>
            <div className={`w-6 h-6 flex flex-col gap-1 cursor-pointer items-center justify-center transition-colors ${activeTab === 'Profile' ? 'text-orange-500 opacity-100' : 'text-zinc-500 hover:text-zinc-200'}`} onClick={() => setActiveTab2('Profile')} title="Collector Profile">
              <div className="h-1 bg-current w-5"></div>
              <div className="h-1 bg-current w-5"></div>
              <div className="h-1 bg-current w-5"></div>
            </div>
            <div className={`w-6 h-6 flex items-center justify-center cursor-pointer transition-colors ${activeTab === 'Leaderboards' ? 'text-orange-500 opacity-100' : 'text-zinc-500 hover:text-zinc-200'}`} onClick={() => setActiveTab2('Leaderboards')} title="Leaderboard">
              <Trophy className="w-5 h-5" />
            </div>
          </div>
        </div>
        <div className="mt-auto flex flex-col items-center gap-4">
          <div className="w-1 h-12 bg-[#262626]"></div>
          <div className="text-[9px] [writing-mode:vertical-rl] tracking-widest text-[#525252] font-mono font-bold uppercase select-none">v1.1.4-STABLE</div>
        </div>
      </nav>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 flex flex-col min-h-screen overflow-x-hidden">
        {/* TOP HEADER BAR */}
        <header className="h-20 border-b border-[#262626] flex items-center justify-between px-6 md:px-10 bg-[#0A0A0A] sticky top-0 z-40">
          <div className="flex items-center gap-6">
            <h1 className="text-2xl italic font-light font-serif text-white tracking-tight">
              {activeTab === 'BattleHub' && "Battle Arena"}
              {activeTab === 'DeckBuilder' && "Deck Builder"}
              {activeTab === 'Showcase' && "Card Collection"}
              {activeTab === 'Profile' && "Collector Profile"}
              {activeTab === 'Leaderboards' && "Leaderboard"}
              {activeTab === 'Admin' && "Admin Operations Desk"}
            </h1>
            <div className="h-4 w-[1px] bg-[#262626] hidden sm:block"></div>
            <div className="hidden sm:flex gap-4 items-center">
              <span className="text-[10px] uppercase tracking-[0.1em] text-zinc-500 font-mono">Sync Status:</span>
              {discordUser?.isSynced ? (
                <span className="text-[10px] uppercase text-emerald-400 font-mono tracking-wide">// Synced up to DN Cards Bot</span>
              ) : (
                <span className="text-[10px] text-amber-500 font-mono tracking-wide">// Local Sandbox Session</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-6">
            {/* Join Discord CTA */}
            <a
              href="https://discord.gg/rGH2eExu"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden lg:flex items-center gap-2 border border-[#5865F2]/30 hover:border-[#5865F2]/80 hover:bg-[#5865F2]/10 bg-[#5865F2]/5 px-3 py-1.5 rounded-lg text-[10px] font-mono font-bold text-[#7289da] hover:text-white transition-all duration-300"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.873-.894.077.077 0 0 1-.008-.128c.126-.093.252-.19.372-.287a.075.075 0 0 1 .077-.011c3.92 1.793 8.18 1.793 12.061 0a.073.073 0 0 1 .078.009c.12.099.246.195.373.289a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.156-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.156 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.156-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.156 2.418z"/>
              </svg>
              <span>Join Discord</span>
            </a>

            <div className="text-right">
              <div className="text-[10px] uppercase tracking-widest text-[#737373] font-mono">DN Shards</div>
              <div className="font-mono text-orange-400 font-bold text-lg">{dnShards.toLocaleString()}</div>
            </div>
            <div className="w-10 h-10 bg-zinc-900 border border-[#262626] flex items-center justify-center text-orange-500 font-serif italic text-lg font-bold">
              {rank.charAt(0)}
            </div>
          </div>
        </header>

        {/* PRIMARY HORIZONTAL TAB BAR */}
        <nav className="bg-[#0A0A0A] border-b border-[#262626] sticky top-20 z-30 flex items-center justify-start overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab2('BattleHub')}
            className={`px-6 py-3.5 text-xs font-mono tracking-wider transition-all border-r border-[#262626] flex items-center gap-2 shrink-0 ${activeTab === 'BattleHub' ? 'bg-[#ea580c] text-black font-extrabold' : 'text-zinc-400 hover:text-white hover:bg-zinc-900/40'}`}
          >
            <span className={activeTab === 'BattleHub' ? 'text-black' : 'text-orange-500'}>[01]</span>
            BATTLE ARENA
          </button>
          
          <button
            type="button"
            onClick={() => setActiveTab2('DeckBuilder')}
            className={`px-6 py-3.5 text-xs font-mono tracking-wider transition-all border-r border-[#262626] flex items-center gap-2 shrink-0 ${activeTab === 'DeckBuilder' ? 'bg-[#ea580c] text-black font-extrabold' : 'text-zinc-400 hover:text-white hover:bg-zinc-900/40'}`}
          >
            <span className={activeTab === 'DeckBuilder' ? 'text-black' : 'text-orange-500'}>[02]</span>
            DECK BUILDER
          </button>

          <button
            type="button"
            onClick={() => setActiveTab2('Showcase')}
            className={`px-6 py-3.5 text-xs font-mono tracking-wider transition-all border-r border-[#262626] flex items-center gap-2 shrink-0 ${activeTab === 'Showcase' ? 'bg-[#ea580c] text-black font-extrabold' : 'text-zinc-400 hover:text-white hover:bg-zinc-900/40'}`}
          >
            <span className={activeTab === 'Showcase' ? 'text-black' : 'text-orange-500'}>[03]</span>
            CARD COLLECTION
          </button>

          <button
            type="button"
            onClick={() => setActiveTab2('Profile')}
            className={`px-6 py-3.5 text-xs font-mono tracking-wider transition-all border-r border-[#262626] flex items-center gap-2 shrink-0 ${activeTab === 'Profile' ? 'bg-[#ea580c] text-black font-extrabold' : 'text-zinc-400 hover:text-white hover:bg-zinc-900/40'}`}
          >
            <span className={activeTab === 'Profile' ? 'text-black' : 'text-orange-500'}>[04]</span>
            COLLECTOR PROFILE
          </button>

          <button
            type="button"
            onClick={() => setActiveTab2('Leaderboards')}
            className={`px-6 py-3.5 text-xs font-mono tracking-wider transition-all border-r border-[#262626] flex items-center gap-2 shrink-0 ${activeTab === 'Leaderboards' ? 'bg-[#ea580c] text-black font-extrabold' : 'text-zinc-400 hover:text-white hover:bg-zinc-900/40'}`}
          >
            <span className={activeTab === 'Leaderboards' ? 'text-black' : 'text-orange-500'}>[05]</span>
            LEADERBOARD
          </button>

          <button
            type="button"
            onClick={() => setActiveTab2('Admin')}
            className={`px-6 py-3.5 text-xs font-mono tracking-wider transition-all border-r border-[#262626] flex items-center gap-2 shrink-0 ${activeTab === 'Admin' ? 'bg-[#ea580c] text-black font-extrabold' : 'text-zinc-400 hover:text-white hover:bg-zinc-900/40'}`}
          >
            <span className={activeTab === 'Admin' ? 'text-black' : 'text-orange-500'}>[06]</span>
            ADMIN DESK
          </button>
        </nav>

        {/* CORE DISPLAY STAGE */}
        <div className="flex-1 p-6 md:p-10 relative">
          {/* Subtle decoration vector layer */}
          <div className="absolute bottom-[-10px] left-[-10px] text-[180px] font-black text-white/[0.015] leading-none pointer-events-none select-none font-sans uppercase">
            DN CARDS
          </div>

          {activeTab === 'BattleHub' && (
            <BattleHub 
              playerDeckIds={currentDeckList}
              dnShards={dnShards}
              playerRank={rank}
              addXp={addXp}
              addShards={addShards}
              addMatchHistory={addMatchHistory}
              ownedCardIds={ownedCardIds}
            />
          )}

          {activeTab === 'DeckBuilder' && (
            <DeckBuilder 
              ownedCardIds={ownedCardIds}
              dnShards={dnShards}
              customDecks={customDecks}
              activeDeckId={activeDeckId}
              saveDeck={saveDeck}
              unlockCardWithShards={unlockCardWithShards}
              setActiveDeck={handleSetActiveDeck}
            />
          )}

          {activeTab === 'Showcase' && (
            <Showcase 
              ownedCardIds={ownedCardIds}
              discordUser={discordUser}
              onConnectDiscord={handleConnectDiscord}
              onDisconnectDiscord={handleDisconnectDiscord}
            />
          )}

          {activeTab === 'Profile' && (
            <ProfileStats 
              dnShards={dnShards}
              level={level}
              xp={xp}
              xpToNextLevel={250}
              rank={rank}
              rankXp={rankXp}
              matchHistory={matchHistory}
              achievements={achievements}
              claimAchievementReward={() => {}} 
              discordUser={discordUser}
              onConnectDiscord={handleConnectDiscord}
              onDisconnectDiscord={handleDisconnectDiscord}
              ownedCardIds={ownedCardIds}
            />
          )}

          {activeTab === 'Leaderboards' && (
            <Leaderboard 
              currentUsername={discordUser?.isSynced ? discordUser.username : 'Offline Cadet'} 
              currentUserRank={rank}
              currentUserRating={rankXp}
              currentUserShards={dnShards}
            />
          )}

          {activeTab === 'Admin' && (
            <AdminHub 
              onRefreshDatabase={() => setDbVersion(prev => prev + 1)}
              ownedCardIds={ownedCardIds}
              addShards={addShards}
            />
          )}
        </div>

        {/* FOOTER INFO BAR */}
        <footer className="h-12 border-t border-[#262626] px-6 md:px-10 flex items-center justify-between text-[10px] font-mono text-zinc-500 bg-[#0A0A0A]">
          <div className="flex gap-10">
            <span>MATCH HISTORY // {matchHistory?.filter(m => m.result === 'Victory').length} W - {matchHistory?.filter(m => m.result === 'Defeat').length} L</span>
            <span className="hidden sm:inline">LAST OPERATION: {matchHistory[0] ? `${matchHistory[0].date} AGAINST ${matchHistory[0].opponentName.toUpperCase()}` : 'N/A'}</span>
          </div>
          <div className="flex gap-6 uppercase tracking-tighter">
            <span className="hover:text-white cursor-pointer transition-colors" onClick={() => setActiveTab2('Profile')}>Dossier Protocol</span>
            <span className="text-zinc-800 hidden sm:inline">//</span>
            <span className="text-zinc-400 hidden sm:inline">DN Cards Server Synchronized</span>
          </div>
        </footer>
      </main>
    </div>
  );
}
