# DN Cards // Website & Discord Bot Integration Architecture Plan

This architecture plan outlines how the DN Cards web application can securely integrate with the existing Discord bot infrastructure, enforcing a **single source of truth** for all inventories, collections, balances, ranks, and custom deck definitions.

---

## 1. High-Level System Topology

To prevent duplicate accounts, fractured card collections, or simulated inventory states, both the **Discord Bot Application** and the **DN Cards Website** will query the same primary backend database. 

```
                                  +---------------------------+
                                  |     Discord Platform      |
                                  +-------------+-------------+
                                                |
                                    (User Commands & Actions)
                                                v
  +------------------+            +-------------+-------------+
  |    React Client  |            |     Discord Bot Node      |
  | (Battle Platform)|            |   (Claims & Daily Drops)  |
  +--------+---------+            +-------------+-------------+
           |                                    |
     (API Requests)                             | (Direct Access)
           v                                    v
  +--------+---------+            +-------------+-------------+
  |  Express Server  +----------->|   Primary Shared Database |
  | (OAuth Gateway)  |            |  (PostgreSQL/MongoDB)     |
  +------------------+            +---------------------------+
```

---

## 2. Core Storage Models (The Single Source of Truth)

The Discord bot typically persists user state in a relational database like **PostgreSQL** or a document store like **MongoDB**. Below is the database schema specification to align the website client with the existing Discord bot data structures.

### Users Table (`users`)
Stores core profile rankings, levels, and progression currencies. Keyed by the unique **Discord User ID** so that Discord login automatically loads the match.
```sql
CREATE TABLE users (
    discord_id VARCHAR(64) PRIMARY KEY, -- Discord unique ID (e.g., '28394850593028394')
    username VARCHAR(128) NOT NULL,     -- Discord display name (e.g., 'christopherosorio7')
    discriminator VARCHAR(4) NOT NULL,  -- Legacy discriminator or '0000' for modern handles
    avatar_hash VARCHAR(128),           -- For drawing Discord avatars on the board
    dn_shards INT DEFAULT 180,          -- Primary decrypt/craft command currency
    level INT DEFAULT 1,                -- Progression rank rating
    xp INT DEFAULT 0,                   -- Level XP progress
    rank_xp INT DEFAULT 1500,           -- Matchmaking MMR (Competitive Rating)
    military_rank VARCHAR(32) DEFAULT 'Recruit',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Inventories Table (`user_inventories`)
Maps card ownership. Directly resolved against the static card catalog (`src/data/cards.ts`).
```sql
CREATE TABLE user_inventories (
    id SERIAL PRIMARY KEY,
    discord_id VARCHAR(64) REFERENCES users(discord_id) ON DELETE CASCADE,
    card_id VARCHAR(64) NOT NULL,       -- Matches local card.id index (e.g., 'starter_recruit')
    quantity INT DEFAULT 1,             -- Total card instances owned
    acquired_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(discord_id, card_id)         -- Composite constraint
);
```

### Decks Table (`user_decks`)
Syncs card arrangements in real-time. Decks edited on the website are instantly ready for bot combat, and vice-versa.
```sql
CREATE TABLE user_decks (
    deck_id VARCHAR(64) PRIMARY KEY,
    discord_id VARCHAR(64) REFERENCES users(discord_id) ON DELETE CASCADE,
    deck_name VARCHAR(64) DEFAULT 'Standard Strike Division',
    card_ids VARCHAR(64)[] NOT NULL,     -- Array of card_ids matching `/src/data/cards.ts`
    is_active BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Match History Table (`match_history`)
Ensures clean statistics audit. Recorded on combat conclusion whether played on Discord or the web.
```sql
CREATE TABLE match_history (
    id SERIAL PRIMARY KEY,
    discord_id VARCHAR(64) REFERENCES users(discord_id) ON DELETE CASCADE,
    opponent_name VARCHAR(128) NOT NULL,
    opponent_title VARCHAR(32) NOT NULL,
    game_mode VARCHAR(16) DEFAULT 'Casual', -- 'Ranked' or 'Casual'
    result VARCHAR(8) NOT NULL,            -- 'Victory' or 'Defeat'
    xp_earned INT DEFAULT 0,
    shards_earned INT DEFAULT 0,
    turns_played INT DEFAULT 0,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 3. Secure Web Authentication (Discord OAuth2 Pattern)

To avoid creating website-specific accounts, the web platform utilizes popup-based **Discord OAuth2** authentication.

### Flow Step-by-Step

1. **Authorize Request**: The player clicks **"Sync Discord Account"** on the profile page or header.
2. **Retrieve Authorize URL**: The client queries `/api/auth/discord/url` from the Express backend, which responds with the official Discord OAuth URL including parameters:
   - `client_id`: The Discord Bot Application client ID.
   - `redirect_uri`: The container's dynamically loaded redirect callback URL (e.g. `https://your-preview.run.app/auth/discord/callback`).
   - `response_type`: `code`
   - `scope`: `identify` (gives username, user id, and avatar).
3. **Open Auth Box**: The client launches this URL directly inside a standard web popup.
4. **Token Exchange**:
   - The user approves the permissions.
   - Discord redirects the popup to `/auth/discord/callback?code=xxxx`.
   - The Express server intercepts the `code`, trades it with Discord's REST API for an `access_token`, and calls the Discord Profile API to fetch the user's authentic identity (`discord_id`, `username`, etc.).
5. **Session Connection**:
   - The server inspects if `discord_id` already exists in the shared database.
     - If it exists, it retrieves the profile.
     - If it does not exist, it represents a new bot player registree and creates a core row.
   - The server signs an HTTP-Only secure cookie (`SameSite=None; Secure=true`) storing the database session.
   - The popup executes `window.opener.postMessage({ type: 'DISCORD_AUTH_SUCCESS' }, '*')` and terminates itself.
6. **Frontend Reload**: The main page intercepts the event, fetches `/api/user/me`, and refreshes the inventories dynamically!

```
React Client                 Express Backend               Discord OAuth API
     |                              |                             |
     |--- 1. Fetch OAuth URL ------>|                             |
     |<-- 2. Return OAuth URL ------|                             |
     |                              |                             |
     |--- 3. Open Popup Window ---------------------------------->|
     |    (OAuth confirmation)      |                             |
     |                                                            |
     |<================= 4. Code Redirect =======================|
     |                      (To URL /auth/discord/callback)       |
     |                              |                             |
     |                              |--- 5. Code exchange Token ->|
     |                              |<-- 6. Returns user data ----|
     |                              |                             |
     |                              |=== [Database Query User] ===|
     |                              |    (Retrieves profile &     |
     |                              |     inventories)            |
     |                              |                             |
     |<-- 7. Parent.postMessage() --|                             |
     |    (Closes popup window)     |                             |
     v                              v                             v
```

---

## 4. Real-Time Data Synchronization Implementation

To prevent state drifting, the front-end will transition from writing to `localStorage` to issuing authenticated full-stack API payloads that directly execute queries against the shared repository:

### API Endpoints Catalog

* **`GET /api/user/me`**: Fetches current user profile details (Level, XP, Shards, MMR) based on the current valid cookie. Returns unilateral `401 Unauthorized` if no active linkage.
* **`GET /api/user/inventory`**: Returns the list of card IDs and counts owned by the authentic Discord user.
* **`GET /api/user/decks`**: Returns all decks defined by the user.
* **`POST /api/user/decks/save`**: Updates deck name or composition constraints. Validation verifies the player actually owns the cards being committed.
* **`POST /api/battle/resolve`**:
  - When a Battle Hub match completes, the outcome details are sent securely.
  - Server-side verification confirms turn history signature (to prevent client injection exploits), updates MMR/Rank, commits Shards + level up bonuses, and writes `match_history` row.

---

## 5. Development Roadmap: Releasing Battle Hub Synchronicity

To safely deploy this bridge, the following execution steps are performed:

1. **Step 1: Backend Transition**: Update `package.json` dev scripts to launch the Express Server in TypeScript Mode (`tsx server.ts`).
2. **Step 2: Dual Mode State**: Ensure the frontend checks for an active Discord profile. If unavailable, it falls back gracefully to local demo files with clear visual cues so the user can test offline combat safely.
3. **Step 3: Database Connection**: Build the database connector in server endpoints using environment parameters (`DATABASE_URL`, `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`).
4. **Step 4: Authenticated Combat Routing**: Turn on token signatures for battle endings so shard wins are earned directly in the true Discord bot wallet!
