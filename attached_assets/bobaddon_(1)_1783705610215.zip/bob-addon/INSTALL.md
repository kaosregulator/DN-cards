# 🤖 Bob — Drop-in Add-on for DN Cards

Bob is a self-contained entertainment NPC (games, roulette, roasts, tasks,
quests, talk). His **own** currency (🪙 Bob Coins), XP, stats, and tables — he
never touches your cards/economy. This folder is everything you need.

Wiring Bob in is **3 small edits** (plus a DB push). No changes to your existing
features.

---

## Step 1 — Copy the files (drag & drop in Replit)

Copy these into your project, keeping the same folders:

```
artifacts/api-server/src/bot/bob/      →  (the whole "bob" folder, 16 files)
lib/db/src/schema/bob.ts               →  (one schema file)
```

In Replit's file tree: open `artifacts/api-server/src/bot/`, drag the **`bob`**
folder in. Then open `lib/db/src/schema/` and drag **`bob.ts`** in.

---

## Step 2 — Register the schema (1 line)

Open **`lib/db/src/schema/index.ts`** and add this line with the other exports:

```ts
export * from "./bob";
```

---

## Step 3 — Add Bob's commands (1 line)

Find where you build the array of slash commands you register with Discord
(the array passed to `rest.put(... , { body: commands })`). Add Bob's commands
to it. At the top of that file add the import:

```ts
import { bobCommandsJson } from "./bob/entry.js";
```

Then spread Bob's commands into your array, e.g.:

```ts
const commands = [
  ...yourExistingCommands,
  ...bobCommandsJson(),
];
```

> If your command builder lives in `commands/register.ts`, add
> `...bobCommandsJson()` to the array returned by `buildCommands()`.
> (Import path from there is `../bob/entry.js`.)

---

## Step 4 — Route Bob's interactions (1 line)

Find your **`client.on(Events.InteractionCreate, ...)`** handler (in
`artifacts/api-server/src/bot/index.ts`). At the top of that file add:

```ts
import { routeBobInteraction } from "./bob/entry.js";
```

Then make the **very first thing** inside the handler:

```ts
client.on(Events.InteractionCreate, async (interaction) => {
  if (await routeBobInteraction(interaction)) return;   // ← add this line
  // ... all your existing interaction code stays exactly as-is ...
});
```

That single line handles every Bob command, button, menu, and modal. If it
wasn't a Bob interaction it returns `false` and your normal code runs.

---

## Step 5 — (Optional) Random channel events (1 line)

If you want Bob to occasionally crash into a channel with a mini-event, add this
in your **`ClientReady`** handler (where the bot logs "ready"), in `index.ts`:

```ts
import { startBobEvents } from "./bob/entry.js";   // top of file
// ...inside client.once(Events.ClientReady, ...):
startBobEvents(client);
```

Events only fire in channels you configure (Step 7). Skip this line if you don't
want random appearances.

**Also optional — Bob replies when @mentioned:** find your
`client.on(Events.MessageCreate, ...)` handler and add (top of file:
`import { handleBobMention } from "./bob/entry.js";`):

```ts
void handleBobMention(msg);   // Bob sometimes replies, sometimes ignores you
```

He's rate-limited per channel, sometimes just reacts with an emoji, and is
hardened against abuse — he never follows instructions, never grants anything
(asking him for admin gets you mocked), and always stays in character.

---

## Step 6 — Create the database tables

In the Replit **Shell**:

```bash
pnpm -C lib/db run push
```
(If that command name differs in your project, the equivalent is
`pnpm --filter db push`.)

This creates `bob_settings`, `bob_profiles`, `bob_progress`. It only **adds**
tables — nothing existing is touched.

Then **redeploy / restart** the bot. On boot it re-registers slash commands, so
`/bob` and friends appear.

---

## Step 7 — First-run setup (in Discord, as an admin)

```
/bob                                   → open the hub and play
/bob_admin settings                    → see everything
/bob_admin channels action:add channel:#bot-spam   → enable random events there
/bob_admin avatar form:normal url:<link>           → set Bob's picture (see below)
```

### Set Bob's avatar images (you asked for this)
Discord embeds can't use local files, so host each image once:
1. Upload your Bob picture into any Discord channel.
2. Right-click the image → **Copy Link**.
3. Run: `/bob_admin avatar form:normal url:<paste link>`
   (repeat with `form:blue` and `form:upside`).
The picture shows as the thumbnail on Bob's embeds. Leave `url` empty to clear.

### Scene / reaction images (optional, GIFs welcome)
Beyond the 3 form avatars you can set per-moment images:
`/bob_admin image key:win url:<link>` — shown on wins. Keys:
`win · lose · suspense · jackpot · roulette · blackjack · event`.

---

## Step 8 — (Optional) AI chat with YOUR key

Bob talks with built-in personality by default. To upgrade `/bob_talk` to real
AI, add **one** secret in Replit (Tools → Secrets), then turn it on:

| Provider | Secret to set | Optional extras |
|---|---|---|
| Anthropic (Claude) | `ANTHROPIC_API_KEY` | `BOB_AI_MODEL` (default `claude-haiku-4-5-20251001`) |
| OpenAI / compatible | `OPENAI_API_KEY` | `OPENAI_BASE_URL`, `BOB_AI_MODEL` (default `gpt-4o-mini`) |

Then in Discord: `/bob_admin toggle feature:ai enabled:true`

Bob auto-detects whichever key is present. If the API ever fails he silently
falls back to his built-in lines — he's never mute.

---

## What you get

- `/bob` — interactive hub (Games · Roast · Tasks · Quests · Rewards · Talk · Stats), one message that swaps sections.
- `/bob_roulette` — Bob's signature scene game: random intros, moods, PLAYER CHOICES (Spin Chamber / Pull Trigger / Random / Trust Bob / Walk Away / Raise Risk), and rare special events (Golden Chamber, Rubber Duck, Bob Cheats, Bob Takes The Shot, Mystery Box, Jackpot).
- `/bob_duel @user` — turn-based multiplayer roulette; first BANG loses.
- Mini-games: **Blackjack** (Bob deals — hit/stand/double, animated card flips) · **Rock Paper Scissors** · Coin Flip · Dice · Higher/Lower · Slots · Lucky Wheel · Guess the Emoji — all with intro scenes, animations, and rewards.
- `/bob_roast @user`, `/bob_talk`, @mention chat, daily tasks + quests, random channel events.
- `/bob_stats`, `/bob_leaderboard` (richest, wins, streaks, gamblers, jackpots, level).
- Three forms rolled per interaction: 🟡 Normal, 🔵 Blue (evil, doubles rewards), 🙃 Upside-Down (glitched). Odds tunable via `/bob_admin odds`.

Have fun. — Bob 🟡
